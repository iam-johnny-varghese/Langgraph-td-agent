"""
PromptService

Loads, caches, and renders the plain-text prompt templates in app/prompts/.
Prompt text is stored as .txt files (not inlined in Python) so they can be
reviewed, version-controlled, and edited without touching application code.

Used by:
    - workflows/nodes/generate_response.py (root_cause_prompt.txt)
    - Any future LLM-call integration (system_prompt.txt passed on every
      Anthropic/Ollama API call, ops_diagnosis_prompt.txt / security_audit_prompt.txt
      prepended to the assembled ContextPack before the LLM call).
"""

from __future__ import annotations

import logging
from functools import lru_cache
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_PROMPTS_DIR = Path(__file__).resolve().parent.parent / "prompts"


class PromptService:
    """Loads and renders prompt templates from app/prompts/."""

    def __init__(self, prompts_dir: Path = _PROMPTS_DIR) -> None:
        self._prompts_dir = prompts_dir

    @lru_cache(maxsize=16)
    def _load(self, filename: str) -> str:
        """Load and cache a prompt template by filename.

        Raises:
            FileNotFoundError: if the template file doesn't exist.
        """
        path = self._prompts_dir / filename
        if not path.exists():
            raise FileNotFoundError(f"Prompt template not found: {path}")
        return path.read_text(encoding="utf-8")

    def render(self, filename: str, **variables: Any) -> str:
        """Load a template and substitute {variable} placeholders.

        Uses Python's str.format_map so only named placeholders matching
        supplied variables are substituted; extra braces in SQL/code
        samples within the prompt must be doubled ({{ }}) to escape them.

        Args:
            filename: e.g. "ops_diagnosis_prompt.txt"
            **variables: placeholder values, e.g. entity_name="Finance Dashboard"
        """
        template = self._load(filename)
        try:
            return template.format_map(variables)
        except KeyError as exc:
            logger.warning(
                "PromptService.render: missing variable %s in template %s", exc, filename
            )
            # Return the un-rendered template rather than crashing -- a
            # partially-rendered prompt is better than a failed LLM call.
            return template

    def get_system_prompt(self) -> str:
        """Return the base system prompt sent on every LLM API call."""
        return self._load("system_prompt.txt")

    def get_ops_diagnosis_prompt(self, **variables: Any) -> str:
        """Return the ops-diagnosis prompt, rendered with supplied variables."""
        return self.render("ops_diagnosis_prompt.txt", **variables)

    def get_security_audit_prompt(self, **variables: Any) -> str:
        """Return the security-audit prompt, rendered with supplied variables."""
        return self.render("security_audit_prompt.txt", **variables)

    def get_root_cause_prompt(self, **variables: Any) -> str:
        """Return the root-cause summarization prompt, rendered."""
        return self.render("root_cause_prompt.txt", **variables)
