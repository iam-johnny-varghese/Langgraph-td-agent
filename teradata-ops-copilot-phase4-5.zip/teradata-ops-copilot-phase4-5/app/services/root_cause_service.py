"""
RootCauseService

Thin service wrapper around the deterministic scoring rules in
workflows/nodes/score_root_cause.py.  Its role is to:

    1. Invoke the rule-based scorers and collect ranked candidates.
    2. (Optional, TODO) Apply an LLM narrative summarization pass via
       PromptService to produce a more readable evidence_summary on the
       top candidate without changing the confidence scores.
    3. Return the final ranked candidate list to the workflow node (or to
       any caller that wants root-cause analysis without running the full
       workflow graph).

Separating this service from the node means the scoring + summarization
logic can be called from batch re-analysis pipelines or tests without
needing to instantiate a WorkflowState.
"""

from __future__ import annotations

import logging
from typing import Optional

from app.models.domain import ContextPack, RootCauseCandidate, RootCauseCategory
from app.workflows.nodes.score_root_cause import _RULES

logger = logging.getLogger(__name__)


class RootCauseService:
    """Scores root-cause candidates for a given ContextPack."""

    def score(self, pack: ContextPack) -> list[RootCauseCandidate]:
        """Run all deterministic scoring rules and return ranked candidates.

        Each rule is independently wrapped; a single rule failure does not
        abort the others.  Returns at least one candidate (UNKNOWN at
        confidence 0.0) if no rule produces a match.
        """
        candidates: list[RootCauseCandidate] = []

        for rule in _RULES:
            try:
                result = rule(pack)
                if result is not None:
                    candidates.append(result)
            except Exception as exc:  # noqa: BLE001
                logger.exception("RootCauseService: rule %s failed", rule.__name__)

        if not candidates:
            candidates.append(
                RootCauseCandidate(
                    category=RootCauseCategory.UNKNOWN,
                    confidence=0.0,
                    evidence_summary="No deterministic root-cause pattern matched.",
                    missing_evidence=list(pack.missing_data_flags),
                )
            )

        candidates.sort(key=lambda c: c.confidence, reverse=True)
        return candidates

    def summarize_with_llm(
        self,
        candidates: list[RootCauseCandidate],
        pack: ContextPack,
    ) -> Optional[str]:
        """Optional LLM narrative summary of the top candidate.

        TODO: wire to PromptService.render + Anthropic/Ollama call using
        prompts/root_cause_prompt.txt once that integration is built in
        Phase 5's PromptService.  Returns None until then so callers fall
        back to the deterministic explanation.
        """
        return None
