"""
ContextEngine

Orchestrates the assembly of a ContextPack for a given resolved entity.
Sits between the workflow nodes (retrieve_primary_context,
enrich_with_mcp_tools) and the repository/adapter layer, keeping
retrieval logic out of the nodes themselves.

Used directly by services that need a ContextPack outside the full
workflow graph (e.g. a future batch re-analysis job or a test harness
that wants to build a ContextPack without running all 10 nodes).
"""

from __future__ import annotations

import logging
from typing import Optional

from app.models.domain import (
    ContextPack,
    ResolvedEntity,
)
from app.repositories.teradata_context_repo import TeradataContextRepo
from app.repositories.teradata_ops_repo import TeradataOpsRepo

logger = logging.getLogger(__name__)

_DEFAULT_DEPENDENCY_DEPTH = 3


class ContextEngine:
    """Assembles a ContextPack from repository data for a resolved entity.

    Each data source is fetched independently; a single source failure is
    recorded in ContextPack.missing_data_flags rather than aborting the
    entire assembly.
    """

    def __init__(
        self,
        context_repo: TeradataContextRepo,
        ops_repo: TeradataOpsRepo,
    ) -> None:
        self._context_repo = context_repo
        self._ops_repo = ops_repo

    def build(self, entity: ResolvedEntity) -> ContextPack:
        """Build a ContextPack for the given resolved entity.

        If entity.canonical_id is None (e.g. clarification_required),
        returns an empty ContextPack with a missing_data_flag.
        """
        if not entity.canonical_id:
            return ContextPack(
                primary_entity=entity,
                missing_data_flags=["no_canonical_id_available"],
            )

        target_id = entity.canonical_id
        missing_flags: list[str] = []
        data_product = None
        pipeline_health = []
        dependencies = []

        try:
            data_product = self._context_repo.get_data_product(target_id)
            if data_product is None:
                missing_flags.append("no_data_product_catalog_row_found")
        except Exception as exc:  # noqa: BLE001
            logger.exception("ContextEngine: get_data_product failed for %s", target_id)
            missing_flags.append("data_product_lookup_error")

        try:
            pipeline_health = self._ops_repo.get_latest_pipeline_status(
                data_product_id=target_id
            )
            if not pipeline_health:
                missing_flags.append("no_pipeline_health_rows_found")
        except Exception as exc:  # noqa: BLE001
            logger.exception(
                "ContextEngine: get_latest_pipeline_status failed for %s", target_id
            )
            missing_flags.append("pipeline_health_lookup_error")

        try:
            dependencies = self._context_repo.get_dependency_chain(
                target_id, max_depth=_DEFAULT_DEPENDENCY_DEPTH
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("ContextEngine: get_dependency_chain failed for %s", target_id)
            missing_flags.append("dependency_chain_lookup_error")

        return ContextPack(
            primary_entity=entity,
            data_product=data_product,
            pipeline_health=pipeline_health,
            dependencies=dependencies,
            workload_signals=[],
            missing_data_flags=missing_flags,
        )
