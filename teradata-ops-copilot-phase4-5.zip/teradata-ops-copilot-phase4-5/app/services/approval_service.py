"""
ApprovalService

Manages the lifecycle of ApprovalRequest objects:

    create_approval_request(plan, requesting_user)
        -> persists a new PENDING ApprovalRequest (in-memory today,
           TODO: persist to a durable store / ticketing system)

    get_approval_status(approval_id)
        -> returns current ApprovalStatus for polling by execute_action node

    record_decision(approval_id, approved_by, decision, rejection_reason)
        -> transitions status PENDING -> APPROVED or REJECTED

The approval-required action matrix is also the authoritative source here
(matching request_approval.py's _ACTIONS_REQUIRING_APPROVAL set, which
imports from this module to stay in sync).

In this scaffold approval state is held in an in-process dict, which is
intentionally fragile -- it vanishes on process restart.  TODOs below mark
every point where a durable store (ServiceNow, a dedicated approval DB
table, or context.context_audit extension) should be wired in.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Optional

from app.models.domain import (
    ActionPlan,
    ActionType,
    ApprovalRequest,
    ApprovalStatus,
)

logger = logging.getLogger(__name__)

# Authoritative set of action types that always require approval.
# request_approval.py imports this so the matrix is defined once.
ACTIONS_REQUIRING_APPROVAL: frozenset[ActionType] = frozenset(
    {
        ActionType.RERUN_PIPELINE,
        ActionType.GRANT_OR_REVOKE_ACCESS,
        ActionType.EXECUTE_MACRO,
        # TODO: add ActionType.EXECUTE_FIX_SCRIPT once that enum value
        # is added to models/domain.py
    }
)

# Safe actions that never require approval.
SAFE_ACTIONS: frozenset[ActionType] = frozenset(
    {
        ActionType.NOTIFY_OWNER,
        ActionType.CREATE_INCIDENT_SUMMARY,
        ActionType.GATHER_ADDITIONAL_DIAGNOSTICS,
        ActionType.CREATE_TICKET,
        ActionType.INVESTIGATE_PERMISSIONS,
    }
)


class ApprovalNotFoundError(Exception):
    """Raised when get_approval_status or record_decision is called with
    an approval_id that doesn't exist in the store."""


class ApprovalService:
    """Manages creation and lifecycle of ApprovalRequest objects.

    Thread-safety note: the in-memory store (_store dict) is NOT
    thread-safe.  TODO: replace with a durable, concurrency-safe store
    before production use (e.g. a Teradata table, Redis, or ServiceNow
    integration).
    """

    def __init__(self) -> None:
        # TODO: replace with a repository-backed durable store.
        self._store: dict[str, ApprovalRequest] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def requires_approval(self, action_type: ActionType) -> bool:
        """True if the given action type always requires human approval."""
        return action_type in ACTIONS_REQUIRING_APPROVAL

    def create_approval_request(
        self, plan: ActionPlan, requesting_user: str
    ) -> ApprovalRequest:
        """Create and persist (in-memory) a new PENDING ApprovalRequest.

        Always creates a new record even if an identical request was made
        recently -- deduplication (e.g. "only one pending rerun for this
        pipeline at a time") is a TODO for the durable-store phase.
        """
        approval_id = str(uuid.uuid4())
        status = (
            ApprovalStatus.NOT_REQUIRED
            if plan.action_type not in ACTIONS_REQUIRING_APPROVAL
            else ApprovalStatus.PENDING
        )
        request = ApprovalRequest(
            approval_id=approval_id,
            requested_by=requesting_user,
            action_type=plan.action_type,
            target_object=plan.target_object,
            requested_payload=plan.payload,
            status=status,
        )
        self._store[approval_id] = request
        logger.info(
            "ApprovalService: created approval_id=%s action=%s status=%s",
            approval_id,
            plan.action_type.value,
            status.value,
        )
        return request

    def get_approval_status(self, approval_id: str) -> ApprovalStatus:
        """Fetch the current status for an existing approval request.

        TODO: once the store is durable, this should do a fresh DB/API
        read rather than returning an in-memory snapshot, since approvals
        can be granted asynchronously (e.g. via a ServiceNow workflow or
        Teams approval card) between when the WorkflowState was first
        built and when execute_action runs.

        Raises:
            ApprovalNotFoundError: if approval_id is unknown.
        """
        record = self._store.get(approval_id)
        if record is None:
            raise ApprovalNotFoundError(f"approval_id not found: {approval_id}")
        return record.status

    def get_approval_request(self, approval_id: str) -> Optional[ApprovalRequest]:
        """Fetch the full ApprovalRequest by ID, or None if not found."""
        return self._store.get(approval_id)

    def record_decision(
        self,
        approval_id: str,
        approved_by: str,
        decision: ApprovalStatus,
        rejection_reason: Optional[str] = None,
    ) -> ApprovalRequest:
        """Transition a PENDING request to APPROVED or REJECTED.

        Args:
            approval_id: the request to update.
            approved_by: identity of the human making the decision.
            decision: must be APPROVED or REJECTED.
            rejection_reason: required when decision is REJECTED.

        Raises:
            ApprovalNotFoundError: if approval_id is unknown.
            ValueError: if decision is not APPROVED/REJECTED, or if
                the request is not currently PENDING.
        """
        if decision not in (ApprovalStatus.APPROVED, ApprovalStatus.REJECTED):
            raise ValueError(
                f"decision must be APPROVED or REJECTED, got: {decision}"
            )
        record = self._store.get(approval_id)
        if record is None:
            raise ApprovalNotFoundError(f"approval_id not found: {approval_id}")
        if record.status != ApprovalStatus.PENDING:
            raise ValueError(
                f"approval_id {approval_id} is not PENDING (current: {record.status})"
            )

        updated = record.model_copy(
            update={
                "status": decision,
                "approved_by": approved_by,
                "approved_ts": datetime.utcnow(),
                "rejection_reason": rejection_reason,
            }
        )
        self._store[approval_id] = updated
        logger.info(
            "ApprovalService: decision recorded approval_id=%s decision=%s by=%s",
            approval_id,
            decision.value,
            approved_by,
        )
        return updated

    def expire_pending(self, approval_id: str) -> None:
        """Mark a PENDING request as EXPIRED (e.g. TTL enforcement).

        TODO: wire to a scheduled job or TTL check on the durable store
        rather than calling manually.
        """
        record = self._store.get(approval_id)
        if record and record.status == ApprovalStatus.PENDING:
            self._store[approval_id] = record.model_copy(
                update={"status": ApprovalStatus.EXPIRED}
            )
