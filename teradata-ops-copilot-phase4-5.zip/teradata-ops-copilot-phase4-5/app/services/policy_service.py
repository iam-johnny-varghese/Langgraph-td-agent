"""
PolicyService

Centralises all policy-decision logic above the repository layer.
Consumed by workflows/nodes/policy_check.py, which calls
`evaluate(state)` once per workflow run and stores the returned
PolicyDecision on WorkflowState.

Two independent concerns are handled here:

1. TOOL ELIGIBILITY -- which MCP tools are allowed for the current use
   case, based on context.vw_enabled_tool_registry (pre-fetched into
   AgentToolRegistryEntry rows and passed in at construction time or per
   evaluate() call).  This maps use_case_name -> list[allowed_tool_name]
   using exact membership checks, not fuzzy matching.

2. OBJECT-LEVEL SENSITIVITY -- whether the resolved entity's underlying
   database object is PCI/restricted (from context.access_policy).  This
   determines the execution-mode ceiling (e.g. a PCI-sensitive object may
   cap the ceiling at READ_ONLY regardless of which use case is active).
   Currently a TODO stub because a concrete entity -> object_name mapping
   doesn't exist yet (see inline note).

Fail-closed contract: any exception during evaluation produces
PolicyDecision(status=BLOCKED, allowed_tools=[]).  A service that cannot
determine eligibility must never default to "allow everything".
"""

from __future__ import annotations

import logging
from typing import Optional

from app.models.domain import PolicyDecision, PolicyDecisionStatus
from app.models.policy import AgentToolRegistryEntry
from app.models.workflow import WorkflowState
from app.repositories.teradata_security_repo import TeradataSecurityRepo

logger = logging.getLogger(__name__)

# Sensitivity levels that should cap the execution mode at READ_ONLY
# regardless of which use case is active, until an elevated role is
# confirmed via a security-tools MCP call.
_RESTRICTED_SENSITIVITY_LEVELS = {"pci", "restricted"}


class PolicyService:
    """Evaluates tool eligibility and object-level sensitivity to produce a
    PolicyDecision for the current workflow request."""

    def __init__(
        self,
        security_repo: TeradataSecurityRepo,
        tool_registry_entries: list[AgentToolRegistryEntry],
    ) -> None:
        self._security_repo = security_repo
        self._registry = {e.tool_name: e for e in tool_registry_entries}

    # ------------------------------------------------------------------
    # Primary API
    # ------------------------------------------------------------------

    def evaluate(self, state: WorkflowState) -> PolicyDecision:
        """Produce a PolicyDecision for the current workflow state.

        Always returns a PolicyDecision -- never raises. See module-level
        fail-closed contract above.
        """
        try:
            return self._evaluate_internal(state)
        except Exception as exc:  # noqa: BLE001
            logger.exception(
                "PolicyService.evaluate: failing closed for request_id=%s",
                state.request.request_id,
            )
            return PolicyDecision(
                status=PolicyDecisionStatus.BLOCKED,
                allowed_tools=[],
                denied_tools=list(self._registry.keys()),
                policy_reason=f"policy_evaluation_error: {exc}",
                requires_approval_for_actions=[],
            )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _evaluate_internal(self, state: WorkflowState) -> PolicyDecision:
        use_case = state.use_case_name or "unknown"
        entity = state.resolved_entity

        # --- Entity-resolution ceiling ---
        # No confirmed entity => can never authorise an action.
        if entity is None or entity.clarification_required:
            status_ceiling = PolicyDecisionStatus.READ_ONLY
        else:
            status_ceiling = PolicyDecisionStatus.APPROVED_FOR_SAFE_ACTION

        # --- Object-level sensitivity ceiling ---
        # TODO: map entity.canonical_id to an actual database object_name
        # and call security_repo.get_access_policy(object_name).  Until
        # that mapping exists, sensitivity check is skipped.
        sensitivity_ceiling = self._get_sensitivity_ceiling(entity)
        effective_ceiling = self._min_status(status_ceiling, sensitivity_ceiling)

        # --- Tool eligibility ---
        allowed: list[str] = []
        denied: list[str] = []
        requires_approval_for: list[str] = []

        for tool_name, entry in self._registry.items():
            if self._tool_eligible(entry, use_case):
                allowed.append(tool_name)
                if entry.requires_approval:
                    requires_approval_for.append(tool_name)
            else:
                denied.append(tool_name)

        # --- Derive final status ---
        if use_case == "unknown":
            status = PolicyDecisionStatus.READ_ONLY
            reason = "use_case_unrecognized_defaulting_to_read_only"
            allowed = []
        elif not allowed:
            status = PolicyDecisionStatus.READ_ONLY
            reason = f"no_tools_eligible_for_use_case:{use_case}"
        elif requires_approval_for:
            status = self._min_status(
                effective_ceiling, PolicyDecisionStatus.APPROVAL_REQUIRED
            )
            reason = f"approval_required_for:{','.join(requires_approval_for)}"
        else:
            status = effective_ceiling
            reason = f"tools_eligible_for_use_case:{use_case}"

        return PolicyDecision(
            status=status,
            allowed_tools=allowed,
            denied_tools=denied,
            policy_reason=reason,
            requires_approval_for_actions=requires_approval_for,
        )

    @staticmethod
    def _tool_eligible(entry: AgentToolRegistryEntry, use_case: str) -> bool:
        """Exact membership check -- no fuzzy/partial matching."""
        return entry.is_enabled and use_case in entry.use_case_allowlist

    def _get_sensitivity_ceiling(self, entity: Optional[object]) -> PolicyDecisionStatus:
        """Return the execution-mode ceiling implied by object sensitivity.

        TODO: complete once entity -> object_name mapping exists.
        Returns APPROVED_FOR_SAFE_ACTION (no ceiling reduction) until then.
        """
        return PolicyDecisionStatus.APPROVED_FOR_SAFE_ACTION

    @staticmethod
    def _min_status(
        a: PolicyDecisionStatus, b: PolicyDecisionStatus
    ) -> PolicyDecisionStatus:
        """Return the more restrictive of two PolicyDecisionStatus values.

        Ordering (most to least restrictive):
            BLOCKED > READ_ONLY > APPROVAL_REQUIRED > APPROVED_FOR_SAFE_ACTION
        """
        order = [
            PolicyDecisionStatus.BLOCKED,
            PolicyDecisionStatus.READ_ONLY,
            PolicyDecisionStatus.APPROVAL_REQUIRED,
            PolicyDecisionStatus.APPROVED_FOR_SAFE_ACTION,
        ]
        return a if order.index(a) <= order.index(b) else b
