"""
EntityResolver

Service that wraps alias/catalog repository calls and applies confidence
thresholding to produce a ResolvedEntity.  Used by
workflows/nodes/resolve_entity.py, which delegates entity-resolution logic
here rather than embedding it directly in the node so it can be tested
independently of the workflow graph.

Resolution strategy (in order):
    1. Exact alias lookup via context.data_product_alias (get_alias_matches).
    2. If no alias matches, attempt a direct catalog lookup by treating the
       entity_hint as a potential canonical_id or name fragment
       (TODO: direct catalog search not yet wired -- see _fallback_catalog_search).
    3. If still no match, return clarification_required=True.
"""

from __future__ import annotations

import logging
from typing import Optional

from app.models.domain import EntityCandidate, EntityType, ResolvedEntity
from app.repositories.teradata_context_repo import TeradataContextRepo

logger = logging.getLogger(__name__)

_MIN_AUTO_RESOLVE_CONFIDENCE = 0.85
_AMBIGUITY_MARGIN = 0.05


class EntityResolver:
    """Resolves a free-text entity hint to a canonical ResolvedEntity."""

    def __init__(self, context_repo: TeradataContextRepo) -> None:
        self._repo = context_repo

    def resolve(self, entity_hint: Optional[str]) -> ResolvedEntity:
        """Main entry point.  Always returns a ResolvedEntity -- never raises.

        Args:
            entity_hint: the raw text extracted by intake_and_classify;
                None triggers an immediate clarification_required response.
        """
        if not entity_hint or not entity_hint.strip():
            return ResolvedEntity(
                clarification_required=True,
                clarification_reason="no_entity_hint_extracted",
            )
        hint = entity_hint.strip()

        try:
            candidates = self._repo.get_alias_matches(hint)
        except Exception as exc:  # noqa: BLE001
            logger.exception("EntityResolver: alias lookup failed for hint=%r", hint)
            return ResolvedEntity(
                clarification_required=True,
                clarification_reason="alias_lookup_error",
                raw_entity_hint=hint,
            )

        if not candidates:
            # TODO: wire _fallback_catalog_search here once a direct
            # catalog-name lookup query exists.
            return ResolvedEntity(
                candidates=[],
                clarification_required=True,
                clarification_reason="no_matching_entity",
                raw_entity_hint=hint,
            )

        return self._apply_thresholds(hint, candidates)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _apply_thresholds(
        self, hint: str, candidates: list[EntityCandidate]
    ) -> ResolvedEntity:
        """Apply confidence thresholds and ambiguity detection."""
        sorted_candidates = sorted(candidates, key=lambda c: c.confidence, reverse=True)
        top = sorted_candidates[0]

        is_ambiguous = (
            len(sorted_candidates) > 1
            and (top.confidence - sorted_candidates[1].confidence) < _AMBIGUITY_MARGIN
        )

        if is_ambiguous or top.confidence < _MIN_AUTO_RESOLVE_CONFIDENCE:
            reason = "ambiguous_candidates" if is_ambiguous else "low_confidence_match"
            return ResolvedEntity(
                candidates=sorted_candidates,
                confidence=top.confidence,
                clarification_required=True,
                clarification_reason=reason,
                raw_entity_hint=hint,
            )

        return ResolvedEntity(
            canonical_id=top.canonical_id,
            entity_type=top.entity_type,
            display_name=top.display_name,
            confidence=top.confidence,
            candidates=sorted_candidates,
            clarification_required=False,
            raw_entity_hint=hint,
        )

    def _fallback_catalog_search(self, hint: str) -> list[EntityCandidate]:
        """TODO: implement direct catalog name-fragment lookup when alias
        matching produces no candidates.  This would query
        context.data_product_catalog WHERE name LIKE '%hint%' and return
        EntityCandidate objects.  Left as a stub rather than silently
        omitted so it is visible as a planned enhancement.
        """
        return []
