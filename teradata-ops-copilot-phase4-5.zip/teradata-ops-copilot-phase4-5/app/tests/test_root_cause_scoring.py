"""
tests/test_root_cause_scoring.py

Tests for workflows/nodes/score_root_cause.py scoring rules and
services/root_cause_service.py, covering:
    - Each individual scoring rule fires on the right evidence
    - Each rule returns None when its evidence is absent
    - Candidates are sorted descending by confidence
    - Unknown fallback is returned when no rule matches
    - Missing evidence flags are populated correctly
    - RootCauseService.score() mirrors node behaviour
"""

from __future__ import annotations

import pytest
from datetime import datetime

from app.models.domain import (
    ContextPack,
    DataProductSummary,
    DependencyEdge,
    PipelineHealthSnapshot,
    ResolvedEntity,
    RootCauseCategory,
    WorkloadSignal,
)
from app.models.workflow import WorkflowState, WorkflowStage
from app.models.domain import UserRequest
from app.workflows.nodes.score_root_cause import (
    _score_failed_etl_job,
    _score_upstream_data_delay,
    _score_workload_saturation,
    _score_dashboard_refresh_failure,
    run as score_run,
)
from app.services.root_cause_service import RootCauseService


# ── Fixtures ──────────────────────────────────────────────────────────

def _entity(canonical_id: str = "DP_FIN") -> ResolvedEntity:
    from app.models.domain import EntityType
    return ResolvedEntity(
        canonical_id=canonical_id,
        entity_type=EntityType.DATA_PRODUCT,
        display_name="Finance Dashboard",
        confidence=0.98,
    )


def _pack(
    pipeline_health=None,
    dependencies=None,
    workload_signals=None,
    missing_data_flags=None,
) -> ContextPack:
    return ContextPack(
        primary_entity=_entity(),
        pipeline_health=pipeline_health or [],
        dependencies=dependencies or [],
        workload_signals=workload_signals or [],
        missing_data_flags=missing_data_flags or [],
    )


def _failed_pipeline(**kwargs) -> PipelineHealthSnapshot:
    defaults = dict(
        pipeline_id="PL_01", run_id="run_001",
        status="failed", sla_met=False,
        failure_reason="Lock timeout",
        severity="high", owner="etl-team",
    )
    defaults.update(kwargs)
    return PipelineHealthSnapshot(**defaults)


def _success_pipeline(**kwargs) -> PipelineHealthSnapshot:
    defaults = dict(
        pipeline_id="PL_01", run_id="run_001",
        status="success", sla_met=False,
        severity="low", owner="etl-team",
    )
    defaults.update(kwargs)
    return PipelineHealthSnapshot(**defaults)


def _breached_signal(**kwargs) -> WorkloadSignal:
    defaults = dict(
        signal_id="s1", workload_id="WD_FIN",
        signal_ts=datetime.utcnow(),
        metric_name="spool_pct_used", metric_value=92.0,
        threshold_breached=True,
    )
    defaults.update(kwargs)
    return WorkloadSignal(**defaults)


def _dep_edge(up: str = "DP_UP", down: str = "DP_FIN") -> DependencyEdge:
    return DependencyEdge(upstream_id=up, downstream_id=down)


# ── Individual scoring rules ──────────────────────────────────────────

class TestScoreFailedEtlJob:
    def test_returns_candidate_when_pipeline_failed(self):
        pack = _pack(pipeline_health=[_failed_pipeline()])
        result = _score_failed_etl_job(pack)
        assert result is not None
        assert result.category == RootCauseCategory.FAILED_ETL_JOB
        assert result.confidence >= 0.6

    def test_high_confidence_when_failure_reason_present(self):
        pack = _pack(pipeline_health=[_failed_pipeline(failure_reason="Timeout")])
        result = _score_failed_etl_job(pack)
        assert result.confidence >= 0.85
        assert "failure_reason" not in result.missing_evidence

    def test_lower_confidence_when_no_failure_reason(self):
        pack = _pack(pipeline_health=[_failed_pipeline(failure_reason=None)])
        result = _score_failed_etl_job(pack)
        assert result.confidence < 0.85
        assert "failure_reason" in result.missing_evidence

    def test_returns_none_when_no_failed_pipelines(self):
        pack = _pack(pipeline_health=[_success_pipeline()])
        assert _score_failed_etl_job(pack) is None

    def test_returns_none_when_pipeline_health_empty(self):
        pack = _pack(pipeline_health=[])
        assert _score_failed_etl_job(pack) is None


class TestScoreUpstreamDataDelay:
    def test_returns_candidate_when_sla_missed_and_deps_exist(self):
        pack = _pack(
            pipeline_health=[_success_pipeline(sla_met=False)],
            dependencies=[_dep_edge()],
        )
        result = _score_upstream_data_delay(pack)
        assert result is not None
        assert result.category == RootCauseCategory.UPSTREAM_DATA_DELAY

    def test_higher_confidence_when_entity_is_downstream(self):
        pack = _pack(
            pipeline_health=[_success_pipeline(sla_met=False)],
            dependencies=[_dep_edge(down="DP_FIN")],
        )
        result = _score_upstream_data_delay(pack)
        assert result.confidence >= 0.65

    def test_returns_none_when_no_sla_miss(self):
        pack = _pack(
            pipeline_health=[_success_pipeline(sla_met=True)],
            dependencies=[_dep_edge()],
        )
        assert _score_upstream_data_delay(pack) is None

    def test_returns_none_when_no_dependencies(self):
        pack = _pack(
            pipeline_health=[_success_pipeline(sla_met=False)],
            dependencies=[],
        )
        assert _score_upstream_data_delay(pack) is None


class TestScoreWorkloadSaturation:
    def test_returns_candidate_when_threshold_breached(self):
        pack = _pack(workload_signals=[_breached_signal()])
        result = _score_workload_saturation(pack)
        assert result is not None
        assert result.category == RootCauseCategory.WORKLOAD_SATURATION
        assert result.confidence >= 0.7

    def test_evidence_summary_contains_metric_name(self):
        pack = _pack(workload_signals=[_breached_signal(metric_name="spool_pct_used")])
        result = _score_workload_saturation(pack)
        assert "spool_pct_used" in result.evidence_summary

    def test_returns_none_when_no_breached_signals(self):
        pack = _pack(workload_signals=[
            WorkloadSignal(
                signal_id="s1", workload_id="WD",
                signal_ts=datetime.utcnow(),
                metric_name="spool_pct_used",
                metric_value=30.0,
                threshold_breached=False,
            )
        ])
        assert _score_workload_saturation(pack) is None

    def test_returns_none_when_signals_empty(self):
        assert _score_workload_saturation(_pack()) is None


class TestScoreDashboardRefreshFailure:
    def test_returns_candidate_when_pipeline_ok_but_sla_missed(self):
        pack = _pack(pipeline_health=[_success_pipeline(sla_met=False)])
        result = _score_dashboard_refresh_failure(pack)
        assert result is not None
        assert result.category == RootCauseCategory.DASHBOARD_REFRESH_FAILURE

    def test_missing_evidence_includes_refresh_telemetry(self):
        pack = _pack(pipeline_health=[_success_pipeline(sla_met=False)])
        result = _score_dashboard_refresh_failure(pack)
        assert "dashboard_refresh_telemetry" in result.missing_evidence

    def test_returns_none_when_pipeline_also_failed(self):
        pack = _pack(pipeline_health=[_failed_pipeline(sla_met=False)])
        # All pipelines must be "success" for this candidate to fire
        assert _score_dashboard_refresh_failure(pack) is None

    def test_returns_none_when_sla_was_met(self):
        pack = _pack(pipeline_health=[_success_pipeline(sla_met=True)])
        assert _score_dashboard_refresh_failure(pack) is None


# ── score_run node ────────────────────────────────────────────────────

class TestScoreRootCauseNode:
    def _state_with_pack(self, pack: ContextPack) -> WorkflowState:
        req = UserRequest(
            request_id="r1", requesting_user="u", raw_text="test"
        )
        state = WorkflowState(request=req)
        state.context_pack = pack
        return state

    def test_candidates_sorted_descending_by_confidence(self):
        pack = _pack(
            pipeline_health=[_failed_pipeline()],
            workload_signals=[_breached_signal()],
        )
        state = score_run(self._state_with_pack(pack))
        confidences = [c.confidence for c in state.root_cause_candidates]
        assert confidences == sorted(confidences, reverse=True)

    def test_unknown_fallback_when_no_evidence(self):
        state = score_run(self._state_with_pack(_pack()))
        assert len(state.root_cause_candidates) >= 1
        assert state.root_cause_candidates[-1].category == RootCauseCategory.UNKNOWN

    def test_no_candidates_only_when_some_rule_matches(self):
        pack = _pack(pipeline_health=[_failed_pipeline()])
        state = score_run(self._state_with_pack(pack))
        categories = {c.category for c in state.root_cause_candidates}
        assert RootCauseCategory.FAILED_ETL_JOB in categories

    def test_advances_stage_to_generate_explanation(self):
        state = score_run(self._state_with_pack(_pack()))
        assert state.current_stage == WorkflowStage.GENERATE_EXPLANATION.value

    def test_missing_context_pack_returns_unknown_candidate(self):
        req = UserRequest(request_id="r1", requesting_user="u", raw_text="t")
        state = WorkflowState(request=req)
        state.context_pack = None
        result = score_run(state)
        assert len(result.root_cause_candidates) == 1
        assert result.root_cause_candidates[0].category == RootCauseCategory.UNKNOWN
        assert "context_pack" in result.root_cause_candidates[0].missing_evidence


# ── RootCauseService ──────────────────────────────────────────────────

class TestRootCauseService:
    def test_service_mirrors_node_output_on_failed_pipeline(self):
        pack = _pack(pipeline_health=[_failed_pipeline()])
        svc = RootCauseService()
        candidates = svc.score(pack)
        categories = {c.category for c in candidates}
        assert RootCauseCategory.FAILED_ETL_JOB in categories

    def test_service_returns_unknown_on_empty_pack(self):
        svc = RootCauseService()
        candidates = svc.score(_pack())
        assert candidates[-1].category == RootCauseCategory.UNKNOWN

    def test_service_output_sorted_descending(self):
        pack = _pack(
            pipeline_health=[_failed_pipeline()],
            workload_signals=[_breached_signal()],
        )
        svc = RootCauseService()
        candidates = svc.score(pack)
        confidences = [c.confidence for c in candidates]
        assert confidences == sorted(confidences, reverse=True)

    def test_summarize_with_llm_returns_none_stub(self):
        """LLM path must return None until wired -- callers fall back to template."""
        svc = RootCauseService()
        result = svc.summarize_with_llm([], _pack())
        assert result is None
