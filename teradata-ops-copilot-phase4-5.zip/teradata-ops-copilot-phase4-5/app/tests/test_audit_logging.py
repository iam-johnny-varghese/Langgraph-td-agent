"""
tests/test_audit_logging.py

Tests for the audit layer:
    - AuditRecord construction from WorkflowState
    - JSON serialization of tool_sequence and root_cause fields
    - audit_repo.insert_audit_record stub call
    - persist_audit_record node: runs even on FAILED stage
    - AuditRecord field coverage for all three workflow outcomes
      (clarification, happy-path, blocked)
"""

from __future__ import annotations

import json
from datetime import datetime

import pytest

from app.models.audit import AuditRecord, RootCauseAuditEntry, ToolInvocationAuditEntry
from app.models.domain import (
    ActionType,
    ApprovalStatus,
    EntityType,
    PolicyDecisionStatus,
    ResolvedEntity,
    RootCauseCandidate,
    RootCauseCategory,
    ToolInvocation,
    UserRequest,
)
from app.models.workflow import WorkflowStage, WorkflowState
from app.repositories.audit_repo import AuditRepo
from app.workflows.nodes.audit_result import _build_audit_record, run as audit_run


# ── Helpers ──────────────────────────────────────────────────────────

def _base_state(stage: WorkflowStage = WorkflowStage.COMPLETE) -> WorkflowState:
    req = UserRequest(request_id="test-audit-1", requesting_user="jvarghese", raw_text="test")
    state = WorkflowState(request=req)
    state.use_case_name = "pipeline_incident_diagnosis"
    state.current_stage = stage.value
    state.started_ts = datetime(2026, 6, 28, 8, 0, 0)
    return state


class FakeConn:
    def cursor(self): return None


class RecordingAuditRepo(AuditRepo):
    """Subclass that captures the last inserted record instead of writing SQL."""

    def __init__(self):
        super().__init__(FakeConn())
        self.last_inserted: list[AuditRecord] = []

    def insert_audit_record(self, record: AuditRecord) -> None:
        self.last_inserted.append(record)


# ── AuditRecord construction ──────────────────────────────────────────

class TestBuildAuditRecord:
    def test_minimal_state_produces_valid_record(self):
        state = _base_state()
        record = _build_audit_record(state)
        assert record.request_id == "test-audit-1"
        assert record.user_name == "jvarghese"
        assert record.use_case_name == "pipeline_incident_diagnosis"
        assert record.errors == []

    def test_elapsed_ms_computed_correctly(self):
        state = _base_state()
        state.completed_ts = datetime(2026, 6, 28, 8, 0, 5)  # 5 seconds later
        record = _build_audit_record(state)
        assert record.elapsed_ms == pytest.approx(5000.0, abs=1.0)

    def test_tool_sequence_mapped_correctly(self):
        state = _base_state()
        state.tool_invocations = [
            ToolInvocation(
                tool_name="dba_workloadHealth",
                category="dba",
                status="success",
                latency_ms=123.4,
            )
        ]
        record = _build_audit_record(state)
        assert len(record.tool_sequence) == 1
        entry = record.tool_sequence[0]
        assert entry.tool_name == "dba_workloadHealth"
        assert entry.category == "dba"
        assert entry.status == "success"
        assert entry.latency_ms == pytest.approx(123.4)

    def test_root_causes_mapped_and_capped_at_five(self):
        state = _base_state()
        state.root_cause_candidates = [
            RootCauseCandidate(
                category=RootCauseCategory.FAILED_ETL_JOB,
                confidence=0.9 - i * 0.1,
                evidence_summary="x",
            )
            for i in range(8)
        ]
        record = _build_audit_record(state)
        assert len(record.top_root_causes) == 5

    def test_resolved_entity_fields_extracted(self):
        state = _base_state()
        state.resolved_entity = ResolvedEntity(
            canonical_id="DP_FIN", entity_type=EntityType.DATA_PRODUCT,
            display_name="Finance Dashboard", confidence=0.98,
        )
        record = _build_audit_record(state)
        assert record.resolved_entity_id == "DP_FIN"
        assert record.resolved_entity_type == EntityType.DATA_PRODUCT.value

    def test_errors_propagated(self):
        state = _base_state()
        state.errors = ["something went wrong", "another error"]
        record = _build_audit_record(state)
        assert record.errors == ["something went wrong", "another error"]

    def test_policy_decision_fields_extracted(self):
        from app.models.domain import PolicyDecision
        state = _base_state()
        state.policy_decision = PolicyDecision(
            status=PolicyDecisionStatus.READ_ONLY,
            allowed_tools=[],
            denied_tools=["tool_a"],
            policy_reason="no_tools_eligible",
        )
        record = _build_audit_record(state)
        assert record.policy_decision_status == PolicyDecisionStatus.READ_ONLY
        assert record.policy_reason == "no_tools_eligible"


# ── JSON serialization round-trip ────────────────────────────────────

class TestAuditJsonSerialization:
    def test_tool_sequence_serializes_to_json(self):
        entry = ToolInvocationAuditEntry(
            tool_name="sec_userRoles",
            category="security",
            status="success",
            latency_ms=88.0,
            invoked_ts=datetime(2026, 6, 28, 9, 0, 0),
        )
        serialized = json.dumps([entry.model_dump(mode="json")])
        loaded = json.loads(serialized)
        assert loaded[0]["tool_name"] == "sec_userRoles"

    def test_root_cause_entry_serializes(self):
        entry = RootCauseAuditEntry(
            category=RootCauseCategory.WORKLOAD_SATURATION,
            confidence=0.8,
        )
        serialized = json.dumps(entry.model_dump(mode="json"))
        loaded = json.loads(serialized)
        assert loaded["category"] == "workload_saturation"


# ── persist_audit_record node ─────────────────────────────────────────

class TestPersistAuditNode:
    def test_node_calls_insert_audit_record(self):
        repo = RecordingAuditRepo()
        state = _base_state()
        result_state = audit_run(state, audit_repo=repo)
        assert len(repo.last_inserted) == 1
        assert repo.last_inserted[0].request_id == "test-audit-1"

    def test_node_runs_even_when_stage_is_failed(self):
        """Audit must be persisted even on a FAILED workflow."""
        repo = RecordingAuditRepo()
        state = _base_state(WorkflowStage.FAILED)
        audit_run(state, audit_repo=repo)
        assert len(repo.last_inserted) == 1
        # Stage should remain FAILED (not overwritten to COMPLETE)
        assert state.current_stage == WorkflowStage.FAILED.value

    def test_node_marks_complete_on_success(self):
        repo = RecordingAuditRepo()
        state = _base_state(WorkflowStage.PERSIST_AUDIT)
        audit_run(state, audit_repo=repo)
        assert state.current_stage == WorkflowStage.COMPLETE.value

    def test_audit_write_failure_recorded_in_fallback_paths(self):
        """An audit write failure must not raise -- it records itself."""
        class FailingRepo(AuditRepo):
            def __init__(self): super().__init__(FakeConn())
            def insert_audit_record(self, record): raise RuntimeError("db down")

        state = _base_state()
        result = audit_run(state, audit_repo=FailingRepo())
        assert "audit_write_failed" in result.fallback_paths_taken

    def test_completed_ts_set_by_node(self):
        repo = RecordingAuditRepo()
        state = _base_state()
        assert state.completed_ts is None
        audit_run(state, audit_repo=repo)
        assert state.completed_ts is not None
