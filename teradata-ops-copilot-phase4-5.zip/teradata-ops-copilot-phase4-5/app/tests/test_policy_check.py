"""
tests/test_policy_check.py

Tests for services/policy_service.py and the PolicyDecision it produces
across all four execution-mode combinations.

Also tests the ToolAdapter._safe_invoke allow-list enforcement
(defense-in-depth check in mcp/adapters/base_tools.py) to verify the
second gate independently of the first.
"""

from __future__ import annotations

import pytest

from app.models.domain import PolicyDecisionStatus, UserRequest
from app.models.policy import AgentToolRegistryEntry, ToolCategory
from app.models.workflow import WorkflowState
from app.services.policy_service import PolicyService
from app.mcp.adapters.base_tools import BaseToolsAdapter
from app.mcp.client import MCPClient
from app.mcp.tool_registry import ToolRegistry
from app.models.mcp import MCPToolCategory, MCPToolDefinition, MCPToolResultStatus


# ── Fixtures ─────────────────────────────────────────────────────────

def _make_entry(
    tool_name: str,
    use_cases: list[str],
    requires_approval: bool = False,
    is_enabled: bool = True,
    category: ToolCategory = ToolCategory.BASE,
) -> AgentToolRegistryEntry:
    return AgentToolRegistryEntry(
        tool_name=tool_name,
        category=category,
        use_case_allowlist=use_cases,
        requires_approval=requires_approval,
        is_enabled=is_enabled,
    )


def _make_state(use_case: str, resolved: bool = True) -> WorkflowState:
    from app.models.domain import ResolvedEntity, EntityType
    req = UserRequest(request_id="r1", requesting_user="jvarghese", raw_text="test")
    state = WorkflowState(request=req)
    state.use_case_name = use_case
    if resolved:
        state.resolved_entity = ResolvedEntity(
            canonical_id="DP_FIN", entity_type=EntityType.DATA_PRODUCT,
            display_name="Finance Dashboard", confidence=0.98,
        )
    else:
        state.resolved_entity = ResolvedEntity(
            clarification_required=True, clarification_reason="no_matching_entity"
        )
    state.requires_clarification = not resolved
    return state


class MockSecurityRepo:
    def get_access_policy(self, object_name: str): return []


# ── PolicyService tests ───────────────────────────────────────────────

class TestPolicyServiceBlocked:
    def test_blocked_when_no_tools_and_unknown_use_case(self):
        svc = PolicyService(MockSecurityRepo(), [])
        state = _make_state("unknown")
        decision = svc.evaluate(state)
        assert decision.status == PolicyDecisionStatus.READ_ONLY
        assert decision.allowed_tools == []

    def test_blocked_on_evaluation_error(self):
        """PolicyService must fail CLOSED if something internal raises."""
        class BadRepo:
            def get_access_policy(self, name):
                raise RuntimeError("db down")

        svc = PolicyService(BadRepo(), [_make_entry("tool_a", ["pipeline_incident_diagnosis"])])

        class BrokenState:
            request = UserRequest(request_id="r1", requesting_user="u", raw_text="q")
            use_case_name = None
            @property
            def resolved_entity(self): raise RuntimeError("broken state")
            requires_clarification = False

        # evaluate() must catch the error and return BLOCKED, not raise.
        decision = svc.evaluate(BrokenState())
        assert decision.status == PolicyDecisionStatus.BLOCKED
        assert decision.allowed_tools == []


class TestPolicyServiceReadOnly:
    def test_read_only_when_entity_unresolved(self):
        entries = [_make_entry("tool_a", ["pipeline_incident_diagnosis"])]
        svc = PolicyService(MockSecurityRepo(), entries)
        state = _make_state("pipeline_incident_diagnosis", resolved=False)
        decision = svc.evaluate(state)
        assert decision.status == PolicyDecisionStatus.READ_ONLY

    def test_read_only_when_use_case_unknown(self):
        entries = [_make_entry("tool_a", ["pipeline_incident_diagnosis"])]
        svc = PolicyService(MockSecurityRepo(), entries)
        state = _make_state("unknown", resolved=True)
        decision = svc.evaluate(state)
        assert decision.status == PolicyDecisionStatus.READ_ONLY
        assert "tool_a" not in decision.allowed_tools

    def test_read_only_no_matching_tools_for_use_case(self):
        entries = [_make_entry("tool_a", ["security_audit"])]
        svc = PolicyService(MockSecurityRepo(), entries)
        state = _make_state("pipeline_incident_diagnosis")
        decision = svc.evaluate(state)
        assert decision.status == PolicyDecisionStatus.READ_ONLY
        assert "tool_a" not in decision.allowed_tools
        assert "tool_a" in decision.denied_tools


class TestPolicyServiceApprovalRequired:
    def test_approval_required_when_tool_needs_approval(self):
        entries = [
            _make_entry("tool_safe", ["pipeline_incident_diagnosis"], requires_approval=False),
            _make_entry("tool_risky", ["pipeline_incident_diagnosis"], requires_approval=True),
        ]
        svc = PolicyService(MockSecurityRepo(), entries)
        state = _make_state("pipeline_incident_diagnosis")
        decision = svc.evaluate(state)
        assert decision.status == PolicyDecisionStatus.APPROVAL_REQUIRED
        assert "tool_safe" in decision.allowed_tools
        assert "tool_risky" in decision.allowed_tools
        assert "tool_risky" in decision.requires_approval_for_actions


class TestPolicyServiceApprovedForSafeAction:
    def test_approved_for_safe_action_when_all_tools_safe(self):
        entries = [
            _make_entry("tool_a", ["pipeline_incident_diagnosis"], requires_approval=False),
            _make_entry("tool_b", ["pipeline_incident_diagnosis"], requires_approval=False),
        ]
        svc = PolicyService(MockSecurityRepo(), entries)
        state = _make_state("pipeline_incident_diagnosis")
        decision = svc.evaluate(state)
        assert decision.status == PolicyDecisionStatus.APPROVED_FOR_SAFE_ACTION
        assert set(decision.allowed_tools) == {"tool_a", "tool_b"}
        assert decision.requires_approval_for_actions == []

    def test_disabled_tool_not_in_allowed_list(self):
        entries = [
            _make_entry("tool_on", ["pipeline_incident_diagnosis"], is_enabled=True),
            _make_entry("tool_off", ["pipeline_incident_diagnosis"], is_enabled=False),
        ]
        svc = PolicyService(MockSecurityRepo(), entries)
        state = _make_state("pipeline_incident_diagnosis")
        decision = svc.evaluate(state)
        assert "tool_on" in decision.allowed_tools
        assert "tool_off" not in decision.allowed_tools


class TestPolicyServiceMinStatus:
    def test_min_status_ordering(self):
        """_min_status must return the MORE restrictive of two statuses."""
        from app.services.policy_service import PolicyService as PS
        P = PolicyDecisionStatus
        assert PS._min_status(P.BLOCKED, P.READ_ONLY) == P.BLOCKED
        assert PS._min_status(P.READ_ONLY, P.APPROVED_FOR_SAFE_ACTION) == P.READ_ONLY
        assert PS._min_status(P.APPROVAL_REQUIRED, P.APPROVED_FOR_SAFE_ACTION) == P.APPROVAL_REQUIRED
        assert PS._min_status(P.APPROVED_FOR_SAFE_ACTION, P.APPROVED_FOR_SAFE_ACTION) == P.APPROVED_FOR_SAFE_ACTION


# ── ToolAdapter allow-list enforcement (defense-in-depth) ─────────────

class TestToolAdapterAllowList:
    def _make_client_with_tool(self, tool_name: str) -> MCPClient:
        defn = MCPToolDefinition(
            name=tool_name,
            category=MCPToolCategory.BASE,
            description="test",
            required_params=[],
            optional_params=[],
        )
        registry = ToolRegistry([defn])
        return MCPClient(transport=None, tool_registry=registry)

    def test_tool_not_in_allow_list_returns_rejected(self):
        client = self._make_client_with_tool("meta_objectExists")
        adapter = BaseToolsAdapter(client, allowed_tools=["some_other_tool"])
        result = adapter._safe_invoke("meta_objectExists", {})
        assert result.status == MCPToolResultStatus.REJECTED
        assert "not_in_policy_allowed_tools" in (result.error_message or "")

    def test_tool_in_allow_list_proceeds_to_client(self):
        """When tool is in allow_list, _safe_invoke should reach the client
        (which returns ERROR here since transport=None, not REJECTED)."""
        client = self._make_client_with_tool("meta_objectExists")
        adapter = BaseToolsAdapter(client, allowed_tools=["meta_objectExists"])
        result = adapter._safe_invoke("meta_objectExists", {})
        # transport=None => client returns ERROR, not REJECTED
        assert result.status == MCPToolResultStatus.ERROR
        assert result.status != MCPToolResultStatus.REJECTED

    def test_no_allow_list_bypasses_adapter_filter(self):
        """allowed_tools=None means no adapter-level filtering (test mode)."""
        client = self._make_client_with_tool("meta_objectExists")
        adapter = BaseToolsAdapter(client, allowed_tools=None)
        result = adapter._safe_invoke("meta_objectExists", {})
        assert result.status != MCPToolResultStatus.REJECTED
