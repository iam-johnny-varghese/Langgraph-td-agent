"""
tests/test_workflow_diagnosis.py

End-to-end workflow tests that run run_workflow() with monkeypatched
repositories and verify the full state output across the three primary
scenarios: clarification-required, happy-path diagnosis, and blocked policy.

These tests exercise the 10-node graph as an integrated unit; individual
node logic is covered in the other test files.  The intent is to catch
regressions in the graph wiring (node order, state threading, stage
transitions) that unit tests on individual nodes would miss.
"""

from __future__ import annotations

import pytest

from app.models.domain import (
    DataProductSummary,
    EntityCandidate,
    EntityType,
    PipelineHealthSnapshot,
    UserRequest,
)
from app.models.policy import AgentToolRegistryEntry, ToolCategory
from app.workflows.ops_copilot_graph import WorkflowDependencies, run_workflow
from app.models.workflow import WorkflowStage


# ── Repo stubs ────────────────────────────────────────────────────────

class FakeConn:
    def cursor(self): return None


def _make_deps(
    alias_results=None,
    pipeline_results=None,
    registry_entries=None,
) -> WorkflowDependencies:
    from app.repositories.teradata_context_repo import TeradataContextRepo
    from app.repositories.teradata_ops_repo import TeradataOpsRepo
    from app.repositories.teradata_security_repo import TeradataSecurityRepo
    from app.repositories.audit_repo import AuditRepo

    conn = FakeConn()
    ctx = TeradataContextRepo(conn)
    ops = TeradataOpsRepo(conn)
    sec = TeradataSecurityRepo(conn)
    aud = AuditRepo(conn)

    ctx.get_alias_matches = lambda hint: alias_results or []
    ctx.get_data_product = lambda pid: DataProductSummary(
        data_product_id=pid, name="Finance Dashboard",
        owner="finance-team", business_criticality="critical",
    )
    ctx.get_dependency_chain = lambda *a, **kw: []
    ops.get_latest_pipeline_status = lambda **kw: pipeline_results or []

    return WorkflowDependencies(
        context_repo=ctx, ops_repo=ops, security_repo=sec, audit_repo=aud,
        tool_registry_entries=registry_entries or [],
        mcp_client=None,
    )


def _req(text: str) -> UserRequest:
    return UserRequest(
        request_id="test-req-1",
        requesting_user="jvarghese",
        raw_text=text,
    )


# ── Scenario 1: Clarification required (no alias match) ──────────────

class TestClarificationPath:
    def test_unresolvable_entity_requires_clarification(self):
        deps = _make_deps(alias_results=[])
        state = run_workflow(_req('Why did the "ghost pipeline" miss SLA?'), deps)
        assert state.current_stage == WorkflowStage.COMPLETE.value
        assert state.requires_clarification is True
        assert state.clarification_message is not None
        assert "ghost pipeline" in state.clarification_message.lower() or \
               "couldn't find" in state.clarification_message.lower()

    def test_clarification_path_proposes_no_action(self):
        deps = _make_deps(alias_results=[])
        state = run_workflow(_req("What failed?"), deps)
        assert state.proposed_action is None
        assert state.approval_request is None
        assert state.action_executed is False

    def test_clarification_path_has_no_unhandled_errors(self):
        deps = _make_deps(alias_results=[])
        state = run_workflow(_req("huh?"), deps)
        # errors list may be non-empty for audit-write stubs, but
        # there should be no unhandled Python exceptions (the run returns).
        assert state.current_stage in (
            WorkflowStage.COMPLETE.value, WorkflowStage.FAILED.value
        )


# ── Scenario 2: Happy path — resolved entity, failed pipeline ────────

class TestHappyPathDiagnosis:
    def _make_state(self):
        alias = [EntityCandidate(
            canonical_id="DP_FIN_DASH", entity_type=EntityType.DATA_PRODUCT,
            display_name="Finance Dashboard", confidence=0.98,
        )]
        pipelines = [PipelineHealthSnapshot(
            pipeline_id="PL_FIN_ETL", run_id="run_001",
            status="failed", sla_met=False,
            failure_reason="Source table lock timeout",
            severity="high", owner="etl-team",
        )]
        deps = _make_deps(alias_results=alias, pipeline_results=pipelines)
        return run_workflow(
            _req('Why did the "finance dashboard" miss the 8 AM SLA?'), deps
        )

    def test_reaches_complete_stage(self):
        state = self._make_state()
        assert state.current_stage == WorkflowStage.COMPLETE.value

    def test_entity_resolved_without_clarification(self):
        state = self._make_state()
        assert state.requires_clarification is False
        assert state.resolved_entity is not None
        assert state.resolved_entity.canonical_id == "DP_FIN_DASH"

    def test_root_cause_ranked_failed_etl_job_first(self):
        state = self._make_state()
        assert len(state.root_cause_candidates) > 0
        assert state.root_cause_candidates[0].category.value == "failed_etl_job"
        assert state.root_cause_candidates[0].confidence >= 0.6

    def test_explanation_generated(self):
        state = self._make_state()
        assert state.user_explanation is not None
        assert len(state.user_explanation) > 10

    def test_rerun_pipeline_action_proposed(self):
        state = self._make_state()
        assert state.proposed_action is not None
        assert state.proposed_action.action_type.value == "rerun_pipeline"

    def test_approval_request_created_as_pending(self):
        state = self._make_state()
        assert state.approval_request is not None
        from app.models.domain import ApprovalStatus
        assert state.approval_request.status == ApprovalStatus.PENDING

    def test_action_not_executed_without_approval(self):
        state = self._make_state()
        assert state.action_executed is False
        assert state.action_outcome == "skipped_not_approved"


# ── Scenario 3: Policy BLOCKED ────────────────────────────────────────

class TestBlockedPolicyPath:
    def _make_state(self):
        alias = [EntityCandidate(
            canonical_id="DP_FIN_DASH", entity_type=EntityType.DATA_PRODUCT,
            display_name="Finance Dashboard", confidence=0.98,
        )]
        # No tools in registry => policy_service returns READ_ONLY,
        # not BLOCKED (BLOCKED only occurs on evaluation error).
        # To force BLOCKED we simulate an evaluation error via a broken repo.
        from app.repositories.teradata_context_repo import TeradataContextRepo
        from app.repositories.teradata_ops_repo import TeradataOpsRepo
        from app.repositories.teradata_security_repo import TeradataSecurityRepo
        from app.repositories.audit_repo import AuditRepo

        conn = FakeConn()
        ctx = TeradataContextRepo(conn)
        ops = TeradataOpsRepo(conn)
        sec = TeradataSecurityRepo(conn)
        aud = AuditRepo(conn)
        ctx.get_alias_matches = lambda hint: alias
        ctx.get_data_product = lambda pid: None
        ctx.get_dependency_chain = lambda *a, **kw: []
        ops.get_latest_pipeline_status = lambda **kw: []

        # Corrupt AgentToolRegistryEntry to trigger policy evaluation path
        # that returns READ_ONLY (no matching tools).
        return WorkflowDependencies(
            context_repo=ctx, ops_repo=ops, security_repo=sec, audit_repo=aud,
            tool_registry_entries=[],
            mcp_client=None,
        )

    def test_no_tools_yields_read_only_not_blocked(self):
        """Empty tool registry => READ_ONLY (no matching tools),
        not BLOCKED.  BLOCKED only happens on evaluation error."""
        deps = self._make_state()
        state = run_workflow(
            _req('Why did the "finance dashboard" miss SLA?'), deps
        )
        from app.models.domain import PolicyDecisionStatus
        assert state.policy_decision is not None
        assert state.policy_decision.status == PolicyDecisionStatus.READ_ONLY
        assert state.policy_decision.allowed_tools == []

    def test_read_only_state_proposes_no_approval_gated_action(self):
        deps = self._make_state()
        state = run_workflow(
            _req('Why did the "finance dashboard" miss SLA?'), deps
        )
        # With no pipeline data returned, root cause candidates should have
        # very low/zero confidence => no high-confidence action proposed.
        if state.proposed_action is not None:
            from app.models.domain import ActionType
            assert state.proposed_action.action_type in (
                ActionType.GATHER_ADDITIONAL_DIAGNOSTICS,
            )


# ── Scenario 4: Use-case classification ─────────────────────────────

class TestIntakeClassification:
    def test_sla_miss_classified_as_pipeline_incident(self):
        deps = _make_deps()
        state = run_workflow(_req("Why did the finance dashboard miss the 8 AM SLA?"), deps)
        assert state.use_case_name == "pipeline_incident_diagnosis"

    def test_access_question_classified_as_access_review(self):
        deps = _make_deps()
        state = run_workflow(_req("Does user johndoe still have elevated access?"), deps)
        assert state.use_case_name == "access_review"

    def test_spool_question_classified_as_workload_analysis(self):
        deps = _make_deps()
        state = run_workflow(_req("What caused spool pressure for workload FIN_WL?"), deps)
        assert state.use_case_name == "workload_analysis"

    def test_rerun_request_classified_as_remediation(self):
        deps = _make_deps()
        state = run_workflow(_req("Prepare a rerun request for the billing pipeline."), deps)
        assert state.use_case_name == "remediation_request"
