"""
tests/test_entity_resolution.py

Tests for services/entity_resolver.py and the thresholding logic it
applies on top of TeradataContextRepo.get_alias_matches().

All tests use a mock repository so they run without a live Teradata
connection.  The mock is built with plain Python rather than a mocking
library so the test file is dependency-light.
"""

from __future__ import annotations

import pytest

from app.models.domain import EntityCandidate, EntityType
from app.services.entity_resolver import EntityResolver, _AMBIGUITY_MARGIN, _MIN_AUTO_RESOLVE_CONFIDENCE


# ── Helpers ──────────────────────────────────────────────────────────

def _candidate(id_: str, confidence: float, alias: str = "alias") -> EntityCandidate:
    return EntityCandidate(
        canonical_id=id_,
        entity_type=EntityType.DATA_PRODUCT,
        display_name=id_.replace("_", " ").title(),
        confidence=confidence,
        matched_alias=alias,
    )


class MockContextRepo:
    """Minimal mock for TeradataContextRepo that returns configured candidates."""

    def __init__(self, candidates: list[EntityCandidate], raise_error: bool = False):
        self._candidates = candidates
        self._raise_error = raise_error

    def get_alias_matches(self, hint: str) -> list[EntityCandidate]:
        if self._raise_error:
            raise RuntimeError("simulated db error")
        return self._candidates

    # Other methods not needed for entity resolution tests.
    def get_data_product(self, *a, **kw): return None
    def get_dependency_chain(self, *a, **kw): return []


# ── Test cases ───────────────────────────────────────────────────────

class TestEntityResolverNoHint:
    def test_none_hint_returns_clarification(self):
        repo = MockContextRepo([])
        resolver = EntityResolver(repo)
        result = resolver.resolve(None)
        assert result.clarification_required is True
        assert result.clarification_reason == "no_entity_hint_extracted"
        assert result.canonical_id is None

    def test_empty_string_hint_returns_clarification(self):
        repo = MockContextRepo([])
        resolver = EntityResolver(repo)
        result = resolver.resolve("   ")
        assert result.clarification_required is True
        assert result.clarification_reason == "no_entity_hint_extracted"

    def test_whitespace_only_hint_returns_clarification(self):
        repo = MockContextRepo([])
        resolver = EntityResolver(repo)
        result = resolver.resolve("\t\n ")
        assert result.clarification_required is True


class TestEntityResolverNoCandidates:
    def test_zero_candidates_returns_no_matching_entity(self):
        repo = MockContextRepo([])
        resolver = EntityResolver(repo)
        result = resolver.resolve("finance dashboard")
        assert result.clarification_required is True
        assert result.clarification_reason == "no_matching_entity"
        assert result.candidates == []
        assert result.raw_entity_hint == "finance dashboard"


class TestEntityResolverExactMatch:
    def test_single_high_confidence_candidate_auto_resolves(self):
        repo = MockContextRepo([_candidate("DP_FIN_DASH", 0.98, "finance dashboard")])
        resolver = EntityResolver(repo)
        result = resolver.resolve("finance dashboard")
        assert result.clarification_required is False
        assert result.canonical_id == "DP_FIN_DASH"
        assert result.confidence == 0.98
        assert result.entity_type == EntityType.DATA_PRODUCT

    def test_auto_resolve_exactly_at_threshold(self):
        """Confidence exactly at _MIN_AUTO_RESOLVE_CONFIDENCE should auto-resolve."""
        repo = MockContextRepo([_candidate("DP_A", _MIN_AUTO_RESOLVE_CONFIDENCE)])
        resolver = EntityResolver(repo)
        result = resolver.resolve("a")
        assert result.clarification_required is False
        assert result.canonical_id == "DP_A"


class TestEntityResolverLowConfidence:
    def test_below_threshold_returns_clarification(self):
        repo = MockContextRepo([_candidate("DP_A", _MIN_AUTO_RESOLVE_CONFIDENCE - 0.01)])
        resolver = EntityResolver(repo)
        result = resolver.resolve("a")
        assert result.clarification_required is True
        assert result.clarification_reason == "low_confidence_match"

    def test_confidence_zero_returns_clarification(self):
        repo = MockContextRepo([_candidate("DP_A", 0.0)])
        resolver = EntityResolver(repo)
        result = resolver.resolve("a")
        assert result.clarification_required is True


class TestEntityResolverAmbiguity:
    def test_two_candidates_within_margin_returns_ambiguous(self):
        """Top two candidates too close together -- must not auto-resolve."""
        c1 = _candidate("DP_FIN", 0.92, "fin")
        c2 = _candidate("DP_FIN2", 0.92 - (_AMBIGUITY_MARGIN / 2), "fin2")
        repo = MockContextRepo([c1, c2])
        resolver = EntityResolver(repo)
        result = resolver.resolve("fin")
        assert result.clarification_required is True
        assert result.clarification_reason == "ambiguous_candidates"
        assert len(result.candidates) == 2

    def test_two_candidates_outside_margin_resolves_top(self):
        """Top two clearly separated -- top candidate should auto-resolve."""
        c1 = _candidate("DP_FIN", 0.95, "finance")
        c2 = _candidate("DP_OTHER", 0.95 - (_AMBIGUITY_MARGIN + 0.01), "other")
        repo = MockContextRepo([c1, c2])
        resolver = EntityResolver(repo)
        result = resolver.resolve("finance")
        assert result.clarification_required is False
        assert result.canonical_id == "DP_FIN"

    def test_many_candidates_with_clear_top_resolves(self):
        """Five candidates but top one clearly dominant."""
        candidates = [_candidate(f"DP_{i}", 0.5 - i * 0.05) for i in range(5)]
        candidates[0] = _candidate("DP_BEST", 0.96)
        repo = MockContextRepo(candidates)
        resolver = EntityResolver(repo)
        result = resolver.resolve("best")
        assert result.clarification_required is False
        assert result.canonical_id == "DP_BEST"


class TestEntityResolverErrorHandling:
    def test_repo_error_returns_clarification_not_exception(self):
        """A database error must degrade to clarification, not an unhandled raise."""
        repo = MockContextRepo([], raise_error=True)
        resolver = EntityResolver(repo)
        result = resolver.resolve("finance dashboard")
        assert result.clarification_required is True
        assert result.clarification_reason == "alias_lookup_error"
        assert result.canonical_id is None

    def test_candidates_sorted_by_confidence_descending(self):
        """Candidates list on the returned ResolvedEntity must be sorted."""
        repo = MockContextRepo([
            _candidate("DP_B", 0.70),
            _candidate("DP_A", 0.91),
            _candidate("DP_C", 0.55),
        ])
        resolver = EntityResolver(repo)
        result = resolver.resolve("x")
        # DP_A should be first (0.91 >= threshold); no second candidate
        # within margin since 0.91 - 0.70 = 0.21 >> AMBIGUITY_MARGIN(0.05)
        assert result.clarification_required is False
        assert result.canonical_id == "DP_A"
        # The full candidates list is sorted desc
        confidences = [c.confidence for c in result.candidates]
        assert confidences == sorted(confidences, reverse=True)
