"""
tests/test_approval_logic.py

Tests for services/approval_service.py covering:
    - Approval matrix (which actions require approval)
    - create_approval_request lifecycle
    - record_decision transitions
    - Guard rails (can't approve a non-PENDING request, etc.)
    - expire_pending
"""

from __future__ import annotations

import pytest

from app.models.domain import ActionPlan, ActionType, ApprovalStatus
from app.services.approval_service import (
    ACTIONS_REQUIRING_APPROVAL,
    SAFE_ACTIONS,
    ApprovalNotFoundError,
    ApprovalService,
)


# ── Approval matrix tests ─────────────────────────────────────────────

class TestApprovalMatrix:
    def test_rerun_pipeline_requires_approval(self):
        svc = ApprovalService()
        assert svc.requires_approval(ActionType.RERUN_PIPELINE) is True

    def test_grant_or_revoke_requires_approval(self):
        svc = ApprovalService()
        assert svc.requires_approval(ActionType.GRANT_OR_REVOKE_ACCESS) is True

    def test_execute_macro_requires_approval(self):
        svc = ApprovalService()
        assert svc.requires_approval(ActionType.EXECUTE_MACRO) is True

    def test_notify_owner_does_not_require_approval(self):
        svc = ApprovalService()
        assert svc.requires_approval(ActionType.NOTIFY_OWNER) is False

    def test_create_incident_summary_does_not_require_approval(self):
        svc = ApprovalService()
        assert svc.requires_approval(ActionType.CREATE_INCIDENT_SUMMARY) is False

    def test_gather_additional_diagnostics_does_not_require_approval(self):
        svc = ApprovalService()
        assert svc.requires_approval(ActionType.GATHER_ADDITIONAL_DIAGNOSTICS) is False

    def test_actions_requiring_approval_and_safe_actions_are_disjoint(self):
        overlap = ACTIONS_REQUIRING_APPROVAL & SAFE_ACTIONS
        assert overlap == frozenset(), f"Overlap found: {overlap}"


# ── create_approval_request ───────────────────────────────────────────

class TestCreateApprovalRequest:
    def _plan(self, action_type: ActionType) -> ActionPlan:
        return ActionPlan(
            action_type=action_type,
            target_object="DP_FIN_DASH",
            payload={},
            rationale="test",
            requires_approval=True,
        )

    def test_approval_required_action_creates_pending_request(self):
        svc = ApprovalService()
        req = svc.create_approval_request(self._plan(ActionType.RERUN_PIPELINE), "jvarghese")
        assert req.status == ApprovalStatus.PENDING
        assert req.approval_id is not None
        assert req.requested_by == "jvarghese"
        assert req.action_type == ActionType.RERUN_PIPELINE

    def test_safe_action_creates_not_required_request(self):
        svc = ApprovalService()
        req = svc.create_approval_request(self._plan(ActionType.NOTIFY_OWNER), "jvarghese")
        assert req.status == ApprovalStatus.NOT_REQUIRED

    def test_each_call_produces_unique_approval_id(self):
        svc = ApprovalService()
        ids = {
            svc.create_approval_request(self._plan(ActionType.RERUN_PIPELINE), "u").approval_id
            for _ in range(5)
        }
        assert len(ids) == 5


# ── get_approval_status ───────────────────────────────────────────────

class TestGetApprovalStatus:
    def test_get_status_of_pending_request(self):
        svc = ApprovalService()
        plan = ActionPlan(action_type=ActionType.RERUN_PIPELINE, target_object="X",
                          payload={}, rationale="r", requires_approval=True)
        req = svc.create_approval_request(plan, "u")
        assert svc.get_approval_status(req.approval_id) == ApprovalStatus.PENDING

    def test_get_status_unknown_id_raises(self):
        svc = ApprovalService()
        with pytest.raises(ApprovalNotFoundError):
            svc.get_approval_status("does-not-exist")


# ── record_decision ───────────────────────────────────────────────────

class TestRecordDecision:
    def _pending_request(self):
        svc = ApprovalService()
        plan = ActionPlan(action_type=ActionType.RERUN_PIPELINE, target_object="X",
                          payload={}, rationale="r", requires_approval=True)
        req = svc.create_approval_request(plan, "jvarghese")
        return svc, req

    def test_approve_pending_sets_approved(self):
        svc, req = self._pending_request()
        updated = svc.record_decision(req.approval_id, "manager1", ApprovalStatus.APPROVED)
        assert updated.status == ApprovalStatus.APPROVED
        assert updated.approved_by == "manager1"
        assert updated.approved_ts is not None

    def test_reject_pending_sets_rejected_with_reason(self):
        svc, req = self._pending_request()
        updated = svc.record_decision(
            req.approval_id, "manager1", ApprovalStatus.REJECTED,
            rejection_reason="policy violation"
        )
        assert updated.status == ApprovalStatus.REJECTED
        assert updated.rejection_reason == "policy violation"

    def test_cannot_approve_already_approved_request(self):
        svc, req = self._pending_request()
        svc.record_decision(req.approval_id, "m1", ApprovalStatus.APPROVED)
        with pytest.raises(ValueError, match="not PENDING"):
            svc.record_decision(req.approval_id, "m2", ApprovalStatus.APPROVED)

    def test_cannot_approve_rejected_request(self):
        svc, req = self._pending_request()
        svc.record_decision(req.approval_id, "m1", ApprovalStatus.REJECTED, rejection_reason="x")
        with pytest.raises(ValueError, match="not PENDING"):
            svc.record_decision(req.approval_id, "m2", ApprovalStatus.APPROVED)

    def test_invalid_decision_value_raises(self):
        svc, req = self._pending_request()
        with pytest.raises(ValueError, match="APPROVED or REJECTED"):
            svc.record_decision(req.approval_id, "m1", ApprovalStatus.PENDING)

    def test_unknown_approval_id_raises(self):
        svc, _ = self._pending_request()
        with pytest.raises(ApprovalNotFoundError):
            svc.record_decision("bad-id", "m1", ApprovalStatus.APPROVED)


# ── expire_pending ────────────────────────────────────────────────────

class TestExpirePending:
    def test_expire_pending_sets_expired(self):
        svc = ApprovalService()
        plan = ActionPlan(action_type=ActionType.RERUN_PIPELINE, target_object="X",
                          payload={}, rationale="r", requires_approval=True)
        req = svc.create_approval_request(plan, "u")
        svc.expire_pending(req.approval_id)
        assert svc.get_approval_status(req.approval_id) == ApprovalStatus.EXPIRED

    def test_expire_already_approved_is_no_op(self):
        svc = ApprovalService()
        plan = ActionPlan(action_type=ActionType.RERUN_PIPELINE, target_object="X",
                          payload={}, rationale="r", requires_approval=True)
        req = svc.create_approval_request(plan, "u")
        svc.record_decision(req.approval_id, "m1", ApprovalStatus.APPROVED)
        svc.expire_pending(req.approval_id)  # should not change APPROVED -> EXPIRED
        assert svc.get_approval_status(req.approval_id) == ApprovalStatus.APPROVED
