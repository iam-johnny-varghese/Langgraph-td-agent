"""
app/api/routes.py

FastAPI route handlers.  Each handler:
    1. Extracts the authenticated user identity.
    2. Constructs a UserRequest from the HTTP request body.
    3. Builds WorkflowDependencies from process-level singletons.
    4. Calls run_workflow() and returns a structured response.

No business logic belongs here -- handlers are thin translators between
HTTP and the workflow layer.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from app.core.security import AuthenticatedUser, get_current_user
from app.models.domain import ApprovalStatus, UserRequest
from app.models.workflow import WorkflowState
from app.workflows.ops_copilot_graph import WorkflowDependencies, run_workflow

router = APIRouter(prefix="/api/v1", tags=["ops-copilot"])


# ── Request / Response shapes ────────────────────────────────────────

class DiagnoseRequest(BaseModel):
    """HTTP request body for POST /diagnose."""
    text: str = Field(..., description="Natural-language question or request.")
    session_id: Optional[str] = None
    channel: Optional[str] = Field(default="api")


class DiagnoseResponse(BaseModel):
    """HTTP response body for POST /diagnose."""
    request_id: str
    explanation: Optional[str]
    requires_clarification: bool
    clarification_message: Optional[str]
    top_root_cause: Optional[str]
    top_root_cause_confidence: Optional[float]
    action_recommended: Optional[str]
    approval_required: bool
    approval_id: Optional[str]
    stage: str
    errors: list[str]


class ApprovalDecisionRequest(BaseModel):
    """HTTP request body for POST /approvals/{approval_id}/decide."""
    decision: str = Field(..., description="'approved' or 'rejected'")
    rejection_reason: Optional[str] = None


class ApprovalDecisionResponse(BaseModel):
    approval_id: str
    decision: str
    recorded_by: str
    recorded_ts: datetime


# ── Dependency: workflow deps singleton ──────────────────────────────
# TODO: build a proper FastAPI lifespan/startup hook in main.py that
# constructs WorkflowDependencies once (with a real Teradata connection
# pool) and stores it in app.state.  For now, routes call a placeholder
# factory defined below.

def _get_workflow_deps() -> WorkflowDependencies:
    """Build WorkflowDependencies.  TODO: replace with a real connection
    pool and pre-fetched tool registry from main.py app.state."""
    from app.repositories.teradata_context_repo import TeradataContextRepo
    from app.repositories.teradata_ops_repo import TeradataOpsRepo
    from app.repositories.teradata_security_repo import TeradataSecurityRepo
    from app.repositories.audit_repo import AuditRepo

    class _FakeConn:  # placeholder until real TD connection wired
        def cursor(self): return None

    conn = _FakeConn()
    return WorkflowDependencies(
        context_repo=TeradataContextRepo(conn),
        ops_repo=TeradataOpsRepo(conn),
        security_repo=TeradataSecurityRepo(conn),
        audit_repo=AuditRepo(conn),
        tool_registry_entries=[],
        mcp_client=None,
    )


# ── Route handlers ───────────────────────────────────────────────────

@router.post("/diagnose", response_model=DiagnoseResponse, status_code=status.HTTP_200_OK)
async def diagnose(
    body: DiagnoseRequest,
    user: AuthenticatedUser = Depends(get_current_user),
    deps: WorkflowDependencies = Depends(_get_workflow_deps),
) -> DiagnoseResponse:
    """Submit a natural-language operations question for diagnosis.

    Returns a structured explanation, root-cause ranking, and (if
    applicable) an action plan with its approval status.
    """
    request = UserRequest(
        request_id=str(uuid.uuid4()),
        session_id=body.session_id,
        requesting_user=user.user_id,
        raw_text=body.text,
        channel=body.channel,
    )

    state: WorkflowState = run_workflow(request, deps)

    top_cause = state.root_cause_candidates[0] if state.root_cause_candidates else None

    return DiagnoseResponse(
        request_id=request.request_id,
        explanation=state.user_explanation,
        requires_clarification=state.requires_clarification,
        clarification_message=state.clarification_message,
        top_root_cause=top_cause.category.value if top_cause else None,
        top_root_cause_confidence=top_cause.confidence if top_cause else None,
        action_recommended=(
            state.proposed_action.action_type.value if state.proposed_action else None
        ),
        approval_required=(
            state.approval_request is not None
            and state.approval_request.status == ApprovalStatus.PENDING
        ),
        approval_id=(
            state.approval_request.approval_id if state.approval_request else None
        ),
        stage=state.current_stage,
        errors=state.errors,
    )


@router.post(
    "/approvals/{approval_id}/decide",
    response_model=ApprovalDecisionResponse,
    status_code=status.HTTP_200_OK,
)
async def decide_approval(
    approval_id: str,
    body: ApprovalDecisionRequest,
    user: AuthenticatedUser = Depends(get_current_user),
) -> ApprovalDecisionResponse:
    """Record a human approval/rejection decision for a pending action.

    TODO: wire to ApprovalService singleton (stored in app.state) instead
    of constructing a new one per request.
    """
    from app.services.approval_service import ApprovalService, ApprovalNotFoundError
    from app.models.domain import ApprovalStatus as AS

    svc = ApprovalService()  # TODO: use singleton from app.state

    decision_map = {"approved": AS.APPROVED, "rejected": AS.REJECTED}
    decision = decision_map.get(body.decision.lower())
    if decision is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="decision must be 'approved' or 'rejected'",
        )

    try:
        updated = svc.record_decision(
            approval_id=approval_id,
            approved_by=user.user_id,
            decision=decision,
            rejection_reason=body.rejection_reason,
        )
    except ApprovalNotFoundError:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="approval not found")
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc))

    return ApprovalDecisionResponse(
        approval_id=approval_id,
        decision=body.decision.lower(),
        recorded_by=user.user_id,
        recorded_ts=updated.approved_ts or datetime.utcnow(),
    )


@router.get("/health", include_in_schema=False)
async def health() -> dict:
    """Liveness probe -- no auth required."""
    return {"status": "ok"}
