"""
ToolAdapter (base class) and BaseToolsAdapter.

ToolAdapter is the common interface every category adapter
(DBAToolsAdapter, SecurityToolsAdapter, VectorToolsAdapter, and this
file's BaseToolsAdapter) implements. It owns the shared "build a validated
request, call through MCPClient, and reject if not policy-approved" flow
so each concrete adapter only needs to define WHICH tools it offers and
any category-specific result handling (e.g. redaction).

BaseToolsAdapter covers simple metadata/basic-query tools that don't carry
the elevated sensitivity of DBA/security/vector operations -- e.g. object
existence checks, basic catalog lookups exposed via MCP rather than direct
SQL (useful when the MCP server itself curates/restricts what's visible,
which may differ from what context.* repos expose).
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any, Optional

from app.mcp.client import MCPClient, MCPClientError
from app.models.mcp import MCPToolCategory, MCPToolResult, MCPToolResultStatus

logger = logging.getLogger(__name__)


class ToolAdapter(ABC):
    """Abstract base for all MCP category adapters.

    Concrete adapters must set `category` and implement whatever
    domain-specific public methods make sense for that category (e.g.
    SecurityToolsAdapter.get_user_db_permissions(...)). Every such public
    method should internally call `self._safe_invoke(...)` rather than
    reaching into `self._client` directly, so the allowed-tools policy
    check and error normalization happen in exactly one place.
    """

    category: MCPToolCategory

    def __init__(self, client: MCPClient, allowed_tools: Optional[list[str]] = None) -> None:
        """
        Args:
            client: the shared MCPClient used to actually invoke tools.
            allowed_tools: the CURRENT request's policy-approved tool
                allow-list (PolicyDecision.allowed_tools). If provided,
                this adapter rejects any call to a tool not in this list
                BEFORE forwarding to MCPClient -- this is the second of
                two defense-in-depth checks (the first being
                workflows/nodes/enrich_with_mcp.py's own pre-filter). If
                None, no allow-list filtering happens at this layer (e.g.
                for adapter-level unit tests that want to test tool
                behavior independent of policy) -- production call sites
                MUST always pass the real allow-list.
        """
        self._client = client
        self._allowed_tools = set(allowed_tools) if allowed_tools is not None else None

    def build_request(self, tool_name: str, **kwargs: Any) -> dict[str, Any]:
        """Builds a parameter dict for a tool call, applying the spec's
        parameter hygiene rules at the call SITE (in addition to
        MCPToolRequest's own validator, which is a second independent
        enforcement layer):
            - Omit any kwarg whose value is None.
            - Trim whitespace on string values.
            - Never silently substitute a default for a missing required
              identifier -- if a required value is None, the caller (the
              adapter's own domain method) must decide whether to raise or
              skip the call entirely; this method only cleans what IS
              provided, it does not fill in gaps.
        """
        cleaned: dict[str, Any] = {}
        for key, value in kwargs.items():
            if value is None:
                continue
            if isinstance(value, str):
                trimmed = value.strip()
                if trimmed:
                    cleaned[key] = trimmed
            else:
                cleaned[key] = value
        return cleaned

    def _safe_invoke(self, tool_name: str, parameters: dict[str, Any]) -> MCPToolResult:
        """The single choke point every adapter method must call through.

        Rejects (without calling MCPClient at all) if an allow-list was
        provided and tool_name is not in it. Converts MCPClientError
        (raised by the client for unknown-tool/missing-param programming
        errors) into a rejected MCPToolResult rather than letting it
        propagate, so adapter callers (workflow nodes) have one uniform
        result shape to handle regardless of failure mode.
        """
        if self._allowed_tools is not None and tool_name not in self._allowed_tools:
            logger.warning("ToolAdapter: rejecting tool=%s (not in allowed_tools)", tool_name)
            return MCPToolResult(
                tool_name=tool_name,
                status=MCPToolResultStatus.REJECTED,
                error_message="tool_not_in_policy_allowed_tools",
            )
        try:
            return self._client.call_tool(tool_name, parameters)
        except MCPClientError as exc:
            logger.error("ToolAdapter: client rejected call tool=%s error=%s", tool_name, exc)
            return MCPToolResult(
                tool_name=tool_name,
                status=MCPToolResultStatus.REJECTED,
                error_message=str(exc),
            )


class BaseToolsAdapter(ToolAdapter):
    """Adapter for general-purpose metadata/basic-query MCP tools.

    TODO: confirm exact tool names exposed by Teradata Enterprise MCP for
    this category -- 'meta_objectExists' and 'meta_describeObject' below
    are placeholders following the sec_/dba_/vector_ naming convention
    implied by the spec's example tool names (sec_userDbPermissions, etc.)
    and should be replaced with the real names once known.
    """

    category = MCPToolCategory.BASE

    def object_exists(self, object_name: str) -> MCPToolResult:
        """Check whether a named object is visible/known to MCP.

        Raises:
            ValueError: if object_name is empty -- this adapter does not
            call a metadata tool with a blank identifier.
        """
        if not object_name or not object_name.strip():
            raise ValueError("object_name must not be empty")
        params = self.build_request("meta_objectExists", object_name=object_name)
        return self._safe_invoke("meta_objectExists", params)

    def describe_object(self, object_name: str) -> MCPToolResult:
        """Fetch basic metadata (columns, type, owner) for a named object.

        Raises:
            ValueError: if object_name is empty.
        """
        if not object_name or not object_name.strip():
            raise ValueError("object_name must not be empty")
        params = self.build_request("meta_describeObject", object_name=object_name)
        return self._safe_invoke("meta_describeObject", params)
