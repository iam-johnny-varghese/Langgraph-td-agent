"""
SecurityToolsAdapter

Wraps Teradata Enterprise MCP security inspection tools:
    - sec_userDbPermissions  : what database-level permissions a user holds
    - sec_userRoles          : which roles are granted to a user
    - sec_rolePermissions    : what permissions a given role carries

All tools here are READ-ONLY. This adapter never calls grant/revoke
operations -- those belong to a future remediation adapter that must
carry an explicit approval gate.

CRITICAL redaction rule:
    Raw permission/role results can contain PCI-sensitive object names and
    privilege details. This adapter NEVER forwards raw_result directly into
    ContextPack.mcp_enrichment. Only result_summary (a short, redacted
    description produced by _redact_permissions_result below) is placed
    into the ContextPack. The full raw_result is logged at DEBUG level for
    ops troubleshooting but must not appear in any LLM-facing context or
    user-facing explanation.

Exact tool names (sec_userDbPermissions, sec_userRoles, sec_rolePermissions)
match the names cited in the spec. TODO: verify these exact strings against
the live Teradata Enterprise MCP tool catalog -- if they differ, update
both this file and context.agent_tool_registry seed data.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from app.mcp.adapters.base_tools import ToolAdapter
from app.models.mcp import MCPToolCategory, MCPToolResult, MCPToolResultStatus

logger = logging.getLogger(__name__)


def _redact_permissions_result(raw: dict[str, Any]) -> str:
    """Produce a short, non-sensitive summary of a permissions/roles result.

    Strips individual object names (which may be PCI-sensitive) and
    summarises only the counts and high-level privilege classes present.

    TODO: tune this once the actual raw_result schema from
    sec_userDbPermissions / sec_userRoles is known. The current
    implementation is a conservative placeholder that reports counts only.
    """
    if not raw:
        return "empty_result"

    # Attempt to count entries if result is a list or dict of lists.
    count = None
    if isinstance(raw, list):
        count = len(raw)
    elif isinstance(raw, dict):
        for key in ("permissions", "roles", "grants"):
            if isinstance(raw.get(key), list):
                count = len(raw[key])
                break

    count_str = f"{count} entr{'y' if count == 1 else 'ies'}" if count is not None else "result"
    return f"[REDACTED: {count_str} returned — see raw_result in debug log]"


class SecurityToolsAdapter(ToolAdapter):
    """Adapter for MCP security inspection tools.

    All public methods validate that required identifiers are present
    before calling build_request / _safe_invoke. Per spec: "do not guess
    missing identifiers" -- if the caller cannot supply a non-empty
    user_name or role_name, the call must not proceed at all.
    """

    category = MCPToolCategory.SECURITY

    def get_user_db_permissions(
        self,
        user_name: str,
        database_name: Optional[str] = None,
    ) -> MCPToolResult:
        """Fetch database-level permissions for user_name, optionally
        scoped to a specific database_name.

        Args:
            user_name: exact Teradata username (required).
            database_name: if supplied, scopes the result to that database
                only. Omitted from the MCP call entirely if None (spec:
                "omit null or empty parameters").

        Raises:
            ValueError: if user_name is empty.
        """
        if not user_name or not user_name.strip():
            raise ValueError("user_name must not be empty for sec_userDbPermissions")

        params = self.build_request(
            "sec_userDbPermissions",
            user_name=user_name,
            database_name=database_name,
        )
        result = self._safe_invoke("sec_userDbPermissions", params)
        return self._apply_redaction(result)

    def get_user_roles(self, user_name: str) -> MCPToolResult:
        """Fetch the list of roles granted to user_name.

        Raises:
            ValueError: if user_name is empty.
        """
        if not user_name or not user_name.strip():
            raise ValueError("user_name must not be empty for sec_userRoles")

        params = self.build_request("sec_userRoles", user_name=user_name)
        result = self._safe_invoke("sec_userRoles", params)
        return self._apply_redaction(result)

    def get_role_permissions(self, role_name: str) -> MCPToolResult:
        """Fetch the permissions carried by a named role.

        Raises:
            ValueError: if role_name is empty.
        """
        if not role_name or not role_name.strip():
            raise ValueError("role_name must not be empty for sec_rolePermissions")

        params = self.build_request("sec_rolePermissions", role_name=role_name)
        result = self._safe_invoke("sec_rolePermissions", params)
        return self._apply_redaction(result)

    def _apply_redaction(self, result: MCPToolResult) -> MCPToolResult:
        """Replace result_summary with a redacted version and log the
        raw_result at DEBUG level only. Returns a new MCPToolResult
        instance (does not mutate the input) so the original raw_result
        is preserved for callers that explicitly need it (e.g. a future
        security-regression scorer in root_cause_service.py), but the
        result_summary that flows into ContextPack.mcp_enrichment is
        always the safe/redacted version.
        """
        if result.status != MCPToolResultStatus.SUCCESS or result.raw_result is None:
            return result

        logger.debug(
            "SecurityToolsAdapter raw_result tool=%s: %s",
            result.tool_name,
            result.raw_result,
        )
        redacted_summary = _redact_permissions_result(result.raw_result)
        return MCPToolResult(
            tool_name=result.tool_name,
            status=result.status,
            raw_result=result.raw_result,   # preserved for internal callers
            result_summary=redacted_summary, # safe for ContextPack / LLM
            latency_ms=result.latency_ms,
        )
