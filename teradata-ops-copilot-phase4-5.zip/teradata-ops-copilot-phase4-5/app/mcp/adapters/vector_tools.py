"""
VectorToolsAdapter

Wraps Teradata Enterprise MCP vector/semantic-search tools for runbook,
SOP, and knowledge-base lookups. Used by enrich_with_mcp_tools when
primary context retrieval comes back thin (e.g. no failure_reason on a
failed pipeline) and the agent needs procedural guidance to ground the
"safe next steps" section of the explanation in something concrete.

These tools query Teradata's Enterprise Vector Store (the native EVS, not
the self-built ChromaDB control plane from earlier platform work), if
configured. If the Enterprise Vector Store is not yet populated or the
tool is not registered in context.agent_tool_registry, the enrich_with_mcp
node will either get a REJECTED result (if the tool is not in
allowed_tools) or an ERROR result (if the transport call fails) -- both
of which that node handles gracefully by recording a missing_data_flag
rather than failing the workflow.

TODO: confirm whether Teradata Enterprise MCP exposes a single
vector-search tool (taking a query string + top_k) or separate
tools for different knowledge domains (runbooks vs. SOPs vs. architecture
docs). The current implementation assumes a single 'vector_runbookSearch'
tool as a practical default.
"""

from __future__ import annotations

import logging

from app.mcp.adapters.base_tools import ToolAdapter
from app.models.mcp import MCPToolCategory, MCPToolResult

logger = logging.getLogger(__name__)

# Absolute upper bound on top_k to prevent accidentally requesting
# enormous result sets through the vector tool. Callers that pass a
# top_k above this threshold will have it silently clamped.
_MAX_TOP_K = 10


class VectorToolsAdapter(ToolAdapter):
    """Adapter for Teradata Enterprise MCP vector/semantic-search tools.

    Results from these tools are paraphrased/curated snippets (runbook
    excerpts, SOP steps) intended to populate
    ContextPack.runbook_snippets. Unlike SecurityToolsAdapter, no special
    redaction is applied here -- runbook content is presumed non-sensitive
    by design (it should not contain real usernames, object names with
    PCI data, etc.). TODO: revisit this assumption once the actual EVS
    corpus is defined; if internal SOPs contain sensitive details,
    add a redaction/scrub step analogous to SecurityToolsAdapter.
    """

    category = MCPToolCategory.VECTOR

    def search_runbooks(self, query: str, top_k: int = 3) -> MCPToolResult:
        """Semantic similarity search over the runbook/SOP corpus.

        Args:
            query: the natural-language search query, e.g. the data
                product display name or a description of the incident
                type. Must not be empty.
            top_k: number of top results to return. Clamped to
                _MAX_TOP_K (10); caller should pass a small number (3-5)
                for the ContextPack use case to keep the context window
                from being flooded with runbook text.

        Raises:
            ValueError: if query is empty.
        """
        if not query or not query.strip():
            raise ValueError("query must not be empty for vector_runbookSearch")

        clamped_top_k = min(max(1, top_k), _MAX_TOP_K)
        if clamped_top_k != top_k:
            logger.warning(
                "VectorToolsAdapter: top_k=%s clamped to %s", top_k, clamped_top_k
            )

        params = self.build_request(
            "vector_runbookSearch",
            query=query,
            top_k=clamped_top_k,
        )
        return self._safe_invoke("vector_runbookSearch", params)

    def answer_question(self, question: str, top_k: int = 3) -> MCPToolResult:
        """QA-style lookup: retrieve the most relevant knowledge-base
        passages for a natural-language question.

        TODO: confirm whether this maps to the same MCP tool as
        search_runbooks (with a different query framing) or a distinct
        'vector_qaLookup' tool. Using a separate method now so the
        distinction can be tracked explicitly if tool names diverge.

        Raises:
            ValueError: if question is empty.
        """
        if not question or not question.strip():
            raise ValueError("question must not be empty for vector_qaLookup")

        clamped_top_k = min(max(1, top_k), _MAX_TOP_K)
        params = self.build_request(
            "vector_qaLookup",
            question=question,
            top_k=clamped_top_k,
        )
        return self._safe_invoke("vector_qaLookup", params)
