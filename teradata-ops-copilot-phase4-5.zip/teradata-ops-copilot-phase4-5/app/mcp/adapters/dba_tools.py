"""
DBAToolsAdapter

Wraps Teradata Enterprise MCP's platform/DBA diagnostic tools -- workload
health, spool/CPU pressure, blocked sessions, and similar system-level
signals that complement (but are not a replacement for) the curated
context.workload_signal table. Where context.workload_signal gives
pre-aggregated, curated signals for the agent, this adapter is for
on-demand, live diagnostic pulls when the curated table's lookback window
or grain isn't sufficient (e.g. "what's happening RIGHT NOW on workload Y").

All methods here are read-only diagnostics; none of them write/mutate
anything in Teradata. is_read_only on the underlying MCPToolDefinition
should be True for every tool this adapter calls -- TODO: consider adding
an assertion in _safe_invoke (base class) or here that raises/logs loudly
if a DBA tool is ever registered with is_read_only=False, since this
adapter's whole contract assumes read-only.
"""

from __future__ import annotations

import logging
from typing import Optional

from app.mcp.adapters.base_tools import ToolAdapter
from app.models.mcp import MCPToolCategory, MCPToolResult

logger = logging.getLogger(__name__)


class DBAToolsAdapter(ToolAdapter):
    """Adapter for platform/DBA diagnostic MCP tools.

    TODO: confirm exact tool names against the real Teradata Enterprise
    MCP tool catalog. Names below ('dba_workloadHealth',
    'dba_spoolPressure', 'dba_blockedSessions', 'dba_systemHealth') follow
    the naming convention implied by the spec's sec_userDbPermissions
    example but are placeholders pending confirmation.
    """

    category = MCPToolCategory.DBA

    def get_workload_health(self, workload_id: str) -> MCPToolResult:
        """Live workload health pull for a TASM/TIWM workload_id.

        Raises:
            ValueError: if workload_id is empty.
        """
        if not workload_id or not workload_id.strip():
            raise ValueError("workload_id must not be empty")
        params = self.build_request("dba_workloadHealth", workload_id=workload_id)
        return self._safe_invoke("dba_workloadHealth", params)

    def get_spool_pressure(self, workload_id: str) -> MCPToolResult:
        """Live spool usage/pressure pull for a workload_id.

        Used specifically for "what caused spool pressure for workload Y"
        style questions (spec's example use case) when
        context.workload_signal's curated/24h-windowed view isn't granular
        enough.

        Raises:
            ValueError: if workload_id is empty.
        """
        if not workload_id or not workload_id.strip():
            raise ValueError("workload_id must not be empty")
        params = self.build_request("dba_spoolPressure", workload_id=workload_id)
        return self._safe_invoke("dba_spoolPressure", params)

    def get_blocked_sessions(self, workload_id: Optional[str] = None) -> MCPToolResult:
        """Live blocked-session pull, optionally scoped to a workload_id.

        workload_id is optional here (unlike the other two methods) since
        "show me all blocked sessions system-wide" is a legitimate
        diagnostic question -- but per the spec's "omit unspecified
        parameters" rule, build_request will drop workload_id entirely
        from the call if it's None rather than sending workload_id=null.
        """
        params = self.build_request("dba_blockedSessions", workload_id=workload_id)
        return self._safe_invoke("dba_blockedSessions", params)

    def get_system_health(self) -> MCPToolResult:
        """System-wide health snapshot (no parameters).

        TODO: confirm whether the real MCP tool for this takes any
        optional scoping parameters (e.g. node range, time window) --
        currently called with zero parameters.
        """
        return self._safe_invoke("dba_systemHealth", {})
