"""
MCPClient

The low-level client responsible for actually sending a validated tool
call to Teradata Enterprise MCP and normalizing the response into an
MCPToolResult. This is the ONLY class in the codebase that should hold an
actual MCP transport/session object.

Layering:
    workflows/nodes/enrich_with_mcp.py
        -> mcp/adapters/{base,dba,security,vector}_tools.py (category adapters)
            -> MCPClient.call_tool()  <-- this file
                -> ToolRegistry (validation)
                -> actual MCP transport (TODO: not implemented in this scaffold)

Category adapters exist as a layer ABOVE this client specifically so that
each category can apply its own category-specific safety rules (e.g.
SecurityToolsAdapter redacting raw permission grants before they reach
ContextPack) without this client needing to know about category-specific
semantics. This client's job is purely: validate exact name + params,
send, time, normalize, log.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Optional, Protocol

from app.models.mcp import (
    MCPToolCategory,
    MCPToolRequest,
    MCPToolResult,
    MCPToolResultStatus,
)
from app.mcp.tool_registry import ToolRegistry

logger = logging.getLogger(__name__)


class MCPTransport(Protocol):
    """Structural type for the underlying MCP transport/session.

    TODO: this Protocol describes the minimal shape this scaffold assumes
    Teradata Enterprise MCP's client SDK exposes (a single synchronous
    `invoke(tool_name, parameters) -> dict` call). Replace with the actual
    SDK's session/client type once available, and update MCPClient.call_tool
    below to match its real method name/signature/async-ness.
    """

    def invoke(self, tool_name: str, parameters: dict[str, Any]) -> dict[str, Any]: ...


class MCPClientError(Exception):
    """Raised for client-side validation failures (unknown tool, missing
    required parameter) BEFORE any network call is attempted. Distinct from
    transport-level errors, which are caught and turned into an
    MCPToolResult(status=ERROR) rather than raised, since a transport
    failure is an expected operational condition adapters must handle
    gracefully, not a programming error."""


class MCPClient:
    """Thin, validating wrapper around the Teradata Enterprise MCP transport.

    Every call goes through:
        1. ToolRegistry validation (exact name known + enabled, required
           params present, no unexpected params) -- raises MCPClientError
           if this fails, since an adapter requesting an invalid call is a
           programming error in the adapter/node, not an operational one.
        2. MCPToolRequest construction (which itself strips null/empty
           string parameters and trims whitespace -- see models/mcp.py).
        3. Actual transport invocation, wrapped in try/except so transport
           failures become MCPToolResult(status=ERROR/TIMEOUT), never a
           raised exception out of call_tool.
    """

    def __init__(
        self,
        transport: Optional[MCPTransport],
        tool_registry: ToolRegistry,
        timeout_seconds: float = 30.0,
    ) -> None:
        self._transport = transport
        self._registry = tool_registry
        self._timeout_seconds = timeout_seconds

    def call_tool(self, tool_name: str, parameters: dict[str, Any]) -> MCPToolResult:
        """Validate and invoke a single MCP tool call.

        Raises:
            MCPClientError: if the tool is unknown/disabled or required
            parameters are missing -- this indicates a bug in the calling
            adapter/node (which should only ever request known, eligible
            tools with complete parameters), not an operational failure,
            so it is raised rather than wrapped into an MCPToolResult.
        """
        defn = self._registry.get(tool_name)
        if defn is None or not defn.is_enabled:
            raise MCPClientError(f"tool '{tool_name}' is unknown or disabled")

        validation_errors = self._registry.validate_parameters(tool_name, parameters)
        if validation_errors:
            raise MCPClientError(
                f"tool '{tool_name}' parameter validation failed: {validation_errors}"
            )

        # MCPToolRequest's own validator strips None/empty-string values and
        # trims whitespace -- constructing it here (rather than trusting the
        # caller already did so) guarantees this hygiene step always runs.
        request = MCPToolRequest(
            tool_name=tool_name, category=defn.category, parameters=parameters
        )

        if self._transport is None:
            # No transport configured -- this scaffold has no live MCP
            # connection yet. Return a clearly-marked error result rather
            # than raising, so callers (adapters) exercise their normal
            # error-handling path even before a real transport exists.
            logger.warning("MCPClient.call_tool: no transport configured (STUB) tool=%s", tool_name)
            return MCPToolResult(
                tool_name=tool_name,
                status=MCPToolResultStatus.ERROR,
                error_message="mcp_transport_not_configured",
            )

        started = time.monotonic()
        try:
            # TODO: confirm whether the real Teradata Enterprise MCP SDK
            # call is synchronous or async, and whether timeout enforcement
            # is handled by the SDK itself or needs to be wrapped here
            # (e.g. via a thread/asyncio timeout). self._timeout_seconds is
            # currently unused pending that confirmation.
            raw_result = self._transport.invoke(request.tool_name, request.parameters)
            latency_ms = (time.monotonic() - started) * 1000
            return MCPToolResult(
                tool_name=tool_name,
                status=MCPToolResultStatus.SUCCESS,
                raw_result=raw_result,
                result_summary=self._summarize(raw_result),
                latency_ms=latency_ms,
            )
        except TimeoutError as exc:
            latency_ms = (time.monotonic() - started) * 1000
            logger.warning("MCPClient.call_tool: timeout tool=%s", tool_name)
            return MCPToolResult(
                tool_name=tool_name,
                status=MCPToolResultStatus.TIMEOUT,
                error_message=str(exc),
                latency_ms=latency_ms,
            )
        except Exception as exc:  # noqa: BLE001 -- transport errors must not raise
            latency_ms = (time.monotonic() - started) * 1000
            logger.exception("MCPClient.call_tool: transport error tool=%s", tool_name)
            return MCPToolResult(
                tool_name=tool_name,
                status=MCPToolResultStatus.ERROR,
                error_message=str(exc),
                latency_ms=latency_ms,
            )

    @staticmethod
    def _summarize(raw_result: dict[str, Any]) -> str:
        """Produces a short, log-safe summary of a raw tool result.

        TODO: this is a placeholder summarizer (str() truncated). Category
        adapters (especially SecurityToolsAdapter) should NOT rely on this
        generic summary for redaction purposes -- each adapter is
        responsible for its own category-specific redaction before any
        data from raw_result reaches ContextPack.mcp_enrichment. This
        method exists only to keep MCPToolResult.result_summary
        non-empty/log-friendly at the client level.
        """
        text = str(raw_result)
        return text[:500] + ("..." if len(text) > 500 else "")
