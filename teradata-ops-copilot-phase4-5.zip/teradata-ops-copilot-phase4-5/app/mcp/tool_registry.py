"""
ToolRegistry

Wraps the contents of context.vw_enabled_tool_registry (loaded via
repositories/teradata_security_repo.py-adjacent access -- see TODO below)
into typed MCPToolDefinition objects and exposes lookup/eligibility
helpers used by both:
    - workflows/nodes/policy_check.py (via AgentToolRegistryEntry directly
      today -- see TODO on consolidation)
    - mcp/client.py and the category adapters, which consult this registry
      to validate exact tool names and required/optional parameters BEFORE
      a call is ever sent to Teradata Enterprise MCP.

This class is intentionally the single source of truth for "does this
exact tool name exist, and what does it require" -- adapters must not
hardcode their own copies of required/optional parameter lists.
"""

from __future__ import annotations

import logging
from typing import Optional

from app.models.mcp import MCPToolCategory, MCPToolDefinition

logger = logging.getLogger(__name__)


class ToolRegistry:
    """In-memory registry of MCP tool definitions, keyed by exact tool name.

    Construction: pass in a list of MCPToolDefinition (typically loaded
    once per process/request from context.agent_tool_registry via a
    repository call -- see TODO below on where that load should live).
    This class itself does not query Teradata directly, keeping it
    testable without a live connection.
    """

    def __init__(self, definitions: list[MCPToolDefinition]) -> None:
        self._by_name: dict[str, MCPToolDefinition] = {d.name: d for d in definitions}

    @classmethod
    def from_registry_rows(cls, rows: list[dict]) -> "ToolRegistry":
        """Construct from raw registry rows (e.g. straight from a repo
        query) rather than pre-built MCPToolDefinition objects.

        TODO: this is a convenience constructor stub; the actual row shape
        depends on whether policy_check.py's AgentToolRegistryEntry
        (models/policy.py) or a fresh repo method feeds this. Consider
        consolidating AgentToolRegistryEntry and MCPToolDefinition into a
        single model during review -- they currently overlap significantly
        (both describe a context.agent_tool_registry row) but serve
        slightly different layers (policy decision vs. MCP call
        validation). Left as two distinct models for now since policy.py's
        version is consumed by check_policy_and_tool_eligibility while
        this one is consumed by the MCP layer, and merging them would
        couple those two layers more tightly than may be desired.
        """
        definitions = []
        for row in rows:
            definitions.append(
                MCPToolDefinition(
                    name=row["tool_name"],
                    category=MCPToolCategory(row["category"]),
                    description=row.get("description", ""),
                    required_params=row.get("required_params", []),
                    optional_params=row.get("optional_params", []),
                    param_types=row.get("param_types", {}),
                    is_read_only=bool(row.get("is_read_only", True)),
                    is_enabled=bool(row.get("is_enabled", True)),
                )
            )
        return cls(definitions)

    def get(self, tool_name: str) -> Optional[MCPToolDefinition]:
        """Exact-name lookup. Returns None if the tool is unknown -- callers
        must treat an unknown tool name as a hard rejection, never as
        'assume it's fine and forward the call anyway'."""
        return self._by_name.get(tool_name)

    def is_known(self, tool_name: str) -> bool:
        return tool_name in self._by_name

    def is_enabled(self, tool_name: str) -> bool:
        defn = self._by_name.get(tool_name)
        return defn is not None and defn.is_enabled

    def list_by_category(self, category: MCPToolCategory) -> list[MCPToolDefinition]:
        return [d for d in self._by_name.values() if d.category == category and d.is_enabled]

    def validate_parameters(self, tool_name: str, parameters: dict) -> list[str]:
        """Validates that all required_params are present (post-trim, see
        MCPToolRequest's validator) and that no parameter outside
        required+optional is being passed.

        Returns a list of validation error strings; an empty list means
        the parameters are valid for this tool. Does NOT raise -- callers
        (mcp/client.py) decide whether to raise/reject based on this list.
        """
        defn = self.get(tool_name)
        if defn is None:
            return [f"unknown_tool:{tool_name}"]

        errors: list[str] = []
        known_params = set(defn.required_params) | set(defn.optional_params)
        for required in defn.required_params:
            if required not in parameters:
                errors.append(f"missing_required_param:{required}")
        for supplied in parameters:
            if supplied not in known_params:
                errors.append(f"unexpected_param:{supplied}")
        return errors
