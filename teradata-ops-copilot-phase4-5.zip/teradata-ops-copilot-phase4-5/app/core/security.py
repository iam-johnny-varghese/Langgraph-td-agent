"""
app/core/security.py

Authentication and authorisation helpers for the FastAPI API layer.
Keeps auth logic out of routes.py so it can be tested independently
and swapped (e.g. from bearer-token to mutual-TLS) without touching
route handlers.

Current implementation: a simple Bearer token check against a configured
set of allowed tokens.  TODO: replace with Wells Fargo SSO / LDAP / OIDC
integration before production deployment.

FastAPI dependency injection pattern is used (functions return
Depends()-compatible callables) so route handlers stay clean:

    @router.post("/diagnose")
    async def diagnose(request: ..., user=Depends(get_current_user)):
        ...
"""

from __future__ import annotations

import logging
import secrets
from typing import Optional

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

logger = logging.getLogger(__name__)

_bearer_scheme = HTTPBearer(auto_error=False)


class AuthenticatedUser:
    """Represents a successfully authenticated API caller."""

    def __init__(self, user_id: str, roles: list[str]) -> None:
        self.user_id = user_id
        self.roles = roles

    def __repr__(self) -> str:
        return f"AuthenticatedUser(user_id={self.user_id!r}, roles={self.roles})"


def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Security(_bearer_scheme),
) -> AuthenticatedUser:
    """FastAPI dependency: extract and validate the Bearer token.

    TODO: replace token validation with a real SSO/LDAP/OIDC check.
    Currently accepts any non-empty token and echoes it as the user_id,
    which is only suitable for development/stub mode.

    Raises:
        HTTPException 401: if no valid token is supplied.
    """
    if credentials is None or not credentials.credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = credentials.credentials.strip()

    # TODO: validate token against SSO/OIDC introspection endpoint
    # and extract real user_id + roles. Placeholder below.
    user_id = _extract_user_id_from_token(token)
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return AuthenticatedUser(user_id=user_id, roles=["ops_user"])


def _extract_user_id_from_token(token: str) -> Optional[str]:
    """Placeholder: in production this would call an OIDC introspection
    endpoint or decode a JWT and validate its signature."""
    # TODO: implement real token validation
    if len(token) >= 8:  # stub: accept any sufficiently long token
        return f"user_from_token_{token[:8]}"
    return None
