"""
app/core/config.py

Centralised, environment-driven settings.  All configuration (connection
strings, tunable thresholds, feature flags) is read from environment
variables here and ONLY here -- no other module should call os.getenv()
or read from .env files directly.

Uses Pydantic Settings for automatic env-var binding and type coercion.
TODO: add a .env.example file at the project root documenting every
variable listed here once the variable set stabilises.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings bound from environment variables.

    All variable names are upper-cased in the environment
    (Pydantic Settings convention), e.g. TD_HOST, TD_DATABASE, etc.
    """

    # ── Teradata connection ──────────────────────────────────────────
    td_host: str = Field(default="localhost", description="Teradata server hostname or IP.")
    td_username: str = Field(default="", description="Teradata logon username.")
    td_password: str = Field(default="", description="Teradata logon password.")
    td_database: str = Field(default="context", description="Default database / schema.")
    td_logmech: str = Field(
        default="TD2",
        description="Logon mechanism: TD2 | LDAP | KRB5 | JWT.",
    )
    td_encryptdata: bool = Field(
        default=True,
        description="Enable session-level data encryption (maps to encryptdata teradatasql param).",
    )
    td_connect_timeout: int = Field(default=30, description="Connection timeout in seconds.")

    # ── MCP ─────────────────────────────────────────────────────────
    mcp_endpoint_url: Optional[str] = Field(
        default=None,
        description="Teradata Enterprise MCP server URL. None disables live MCP calls (stub mode).",
    )
    mcp_timeout_seconds: float = Field(default=30.0, description="Per-call MCP tool timeout.")

    # ── Entity resolution ────────────────────────────────────────────
    entity_min_auto_resolve_confidence: float = Field(
        default=0.85,
        ge=0.0,
        le=1.0,
        description="Minimum alias confidence to auto-resolve without clarification.",
    )
    entity_ambiguity_margin: float = Field(
        default=0.05,
        ge=0.0,
        le=1.0,
        description="Max confidence gap between top-2 candidates before treating match as ambiguous.",
    )

    # ── Root cause scoring ───────────────────────────────────────────
    min_action_confidence: float = Field(
        default=0.6,
        ge=0.0,
        le=1.0,
        description="Minimum top-candidate confidence before an action plan is proposed.",
    )
    dependency_chain_max_depth: int = Field(
        default=3,
        ge=1,
        description="Max recursion depth for dependency chain retrieval.",
    )

    # ── LLM / Anthropic ─────────────────────────────────────────────
    anthropic_api_key: Optional[str] = Field(
        default=None,
        description="Anthropic API key for LLM calls. None disables LLM summarization.",
    )
    llm_model: str = Field(
        default="claude-sonnet-4-6",
        description="Model string passed to the Anthropic API.",
    )
    llm_max_tokens: int = Field(default=1024, description="Max tokens per LLM completion.")

    # ── API / App ────────────────────────────────────────────────────
    app_host: str = Field(default="0.0.0.0")
    app_port: int = Field(default=8000)
    debug: bool = Field(default=False)
    log_level: str = Field(default="INFO")

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "case_sensitive": False,
        "extra": "ignore",
    }


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return the cached Settings singleton.

    Use this instead of instantiating Settings() directly so the env
    file is only read once per process.  In tests, call
    get_settings.cache_clear() between test cases that need different
    settings values.
    """
    return Settings()
