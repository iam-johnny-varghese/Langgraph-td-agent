"""
app/core/logging.py

Structured logging configuration for the Teradata Ops Copilot.

Provides JSON-formatted log output (via the `python-json-logger` library)
for production deployments where log ingestion tools (Splunk, CloudWatch,
Datadog) expect structured records, and falls back to a plain human-
readable formatter if the library is not installed.

Call configure_logging() once at application startup (app/main.py) before
any other module emits log records.
"""

from __future__ import annotations

import logging
import sys
from typing import Optional


def configure_logging(
    level: str = "INFO",
    json_format: bool = True,
    service_name: str = "teradata-ops-copilot",
) -> None:
    """Configure root logger with a structured formatter.

    Args:
        level: logging level string, e.g. "INFO", "DEBUG", "WARNING".
        json_format: if True and python-json-logger is installed, emit
            JSON records; otherwise use a readable text formatter.
        service_name: injected into every JSON record as "service".
    """
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    handler = logging.StreamHandler(sys.stdout)

    if json_format:
        formatter = _build_json_formatter(service_name)
    else:
        formatter = None

    if formatter:
        handler.setFormatter(formatter)
    else:
        handler.setFormatter(
            logging.Formatter(
                fmt="%(asctime)s %(levelname)-8s %(name)s %(message)s",
                datefmt="%Y-%m-%dT%H:%M:%S",
            )
        )

    root_logger.handlers.clear()
    root_logger.addHandler(handler)


def _build_json_formatter(service_name: str) -> Optional[logging.Formatter]:
    """Try to build a JSON formatter; return None on ImportError."""
    try:
        from pythonjsonlogger import jsonlogger  # type: ignore[import]

        class _ServiceJsonFormatter(jsonlogger.JsonFormatter):
            def add_fields(self, log_record: dict, record: logging.LogRecord, message_dict: dict) -> None:
                super().add_fields(log_record, record, message_dict)
                log_record.setdefault("service", service_name)
                log_record.setdefault("level", record.levelname)

        return _ServiceJsonFormatter(
            fmt="%(asctime)s %(name)s %(levelname)s %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%SZ",
        )
    except ImportError:
        logging.getLogger(__name__).debug(
            "python-json-logger not installed; using plain text formatter"
        )
        return None
