"""
app/main.py

FastAPI application entrypoint.  Wires together:
    - structured logging
    - settings
    - router registration
    - (TODO) startup/shutdown lifecycle for Teradata connection pool and
      WorkflowDependencies singleton

Run locally:
    uvicorn app.main:app --reload --port 8000

Or via the project's Makefile/Docker entrypoint (TODO: add both).
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI

from app.core.config import get_settings
from app.core.logging import configure_logging
from app.api.routes import router


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """FastAPI lifespan: startup (before yield) and shutdown (after yield).

    TODO: construct the real Teradata connection pool and
    WorkflowDependencies singleton here and store on app.state so
    routes.py can retrieve them via request.app.state rather than
    building a new fake connection on every request.

    Example (pseudocode):
        pool = TeradataConnectionPool(settings)
        deps = build_workflow_dependencies(pool, settings)
        app.state.workflow_deps = deps
        app.state.approval_service = ApprovalService()
        yield
        await pool.close()
    """
    settings = get_settings()
    configure_logging(level=settings.log_level, json_format=not settings.debug)
    yield
    # Teardown: close connection pool, flush any pending buffers, etc.


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title="Teradata Ops Copilot",
        description=(
            "Context-driven agent for diagnosing and remediating Teradata "
            "platform incidents, SLA misses, and access regressions."
        ),
        version="0.1.0",
        debug=settings.debug,
        lifespan=lifespan,
    )
    app.include_router(router)
    return app


app = create_app()
