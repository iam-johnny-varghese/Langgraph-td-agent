--------------------------------------------------------------------------------
-- create_context_views.sql
--
-- Curated views over context.* base tables. Views are the PREFERRED
-- read surface for the repository layer wherever a view exists for the
-- access pattern needed -- repositories should only query base tables
-- directly when no suitable view exists yet (see TODOs in
-- teradata_context_repo.py / teradata_ops_repo.py).
--
-- Run order: requires create_context_tables.sql to have been executed first.
--------------------------------------------------------------------------------

DATABASE context;


--------------------------------------------------------------------------------
-- context.vw_latest_pipeline_status
--
-- One row per pipeline_id: the most recent run by actual_start_ts (falling
-- back to sla_target_ts if actual_start_ts is NULL, e.g. a run that never
-- started). This is the primary view used by retrieve_primary_context for
-- "what's the current state of pipeline X" questions, and is far cheaper
-- than scanning full pipeline_health history for that common case.
--
-- QUALIFY is used (per Teradata SQL conventions) instead of a correlated
-- subquery or window-function-in-WHERE pattern.
--------------------------------------------------------------------------------
REPLACE VIEW context.vw_latest_pipeline_status AS
SELECT
    ph.pipeline_id
    ,ph.run_id
    ,ph.data_product_id
    ,ph.pipeline_name
    ,ph.status
    ,ph.sla_target_ts
    ,ph.actual_start_ts
    ,ph.actual_completion_ts
    ,ph.sla_met
    ,ph.failure_reason
    ,ph.severity
    ,ph.owner
    ,ph.rows_processed
    ,ph.source_system
    ,ph.confidence
    ,ph.updated_ts AS last_status_change_ts
FROM context.pipeline_health ph
QUALIFY ROW_NUMBER() OVER (
            PARTITION BY ph.pipeline_id
            ORDER BY COALESCE(ph.actual_start_ts, ph.sla_target_ts) DESC
         ) = 1
;

COMMENT ON VIEW context.vw_latest_pipeline_status IS
    'One row per pipeline_id: most recent run. Primary read path for "current state" questions; avoids scanning full pipeline_health history.';


--------------------------------------------------------------------------------
-- context.vw_data_product_with_owner
--
-- Convenience view joining data_product_catalog to itself in a stable
-- shape for prompt-facing summaries (DataProductSummary model). Mostly a
-- pass-through today; exists so that if catalog gets split or denormalized
-- later, repository SQL doesn't need to change.
--------------------------------------------------------------------------------
REPLACE VIEW context.vw_data_product_with_owner AS
SELECT
    dpc.data_product_id
    ,dpc.name
    ,dpc.domain
    ,dpc.description
    ,dpc.owner
    ,dpc.owning_team
    ,dpc.business_criticality
    ,dpc.sla_target_time
    ,dpc.status
    ,dpc.confidence
FROM context.data_product_catalog dpc
WHERE dpc.status = 'active'
;

COMMENT ON VIEW context.vw_data_product_with_owner IS
    'Active data products with owner/criticality, in DataProductSummary-aligned shape. Insulates repository SQL from catalog table refactors.';


--------------------------------------------------------------------------------
-- context.vw_active_dependency_edges
--
-- Active-only dependency edges, pre-filtered so get_dependency_chain.sql
-- does not need to repeat the status='active' predicate at every
-- recursive/iterative step.
--------------------------------------------------------------------------------
REPLACE VIEW context.vw_active_dependency_edges AS
SELECT
    dd.dependency_id
    ,dd.upstream_id
    ,dd.downstream_id
    ,dd.relationship_type
    ,dd.criticality
    ,dd.confidence
FROM context.data_dependency dd
WHERE dd.status = 'active'
;

COMMENT ON VIEW context.vw_active_dependency_edges IS
    'Active-only dependency edges. Used as the base relation for dependency-chain traversal queries.';


--------------------------------------------------------------------------------
-- context.vw_breached_workload_signals
--
-- Recent threshold-breaching workload signals only. Used by
-- score_root_cause_candidates for workload_saturation evidence without
-- requiring the caller to pass a threshold predicate every time.
--
-- TODO: the 24-hour lookback window is a practical default; consider making
-- this parameterized (e.g. via a table function or by having the repository
-- query the base table directly with a caller-supplied window) if root
-- cause analysis needs to look further back.
--------------------------------------------------------------------------------
REPLACE VIEW context.vw_breached_workload_signals AS
SELECT
    ws.signal_id
    ,ws.workload_id
    ,ws.signal_ts
    ,ws.metric_name
    ,ws.metric_value
    ,ws.threshold_value
    ,ws.threshold_breached
    ,ws.severity
    ,ws.related_data_product_id
    ,ws.confidence
FROM context.workload_signal ws
WHERE ws.threshold_breached = 1
  AND ws.signal_ts >= CURRENT_TIMESTAMP(0) - INTERVAL '24' HOUR
;

COMMENT ON VIEW context.vw_breached_workload_signals IS
    'Threshold-breached workload signals from the last 24 hours. Default evidence source for workload_saturation root-cause scoring.';


--------------------------------------------------------------------------------
-- context.vw_enabled_tool_registry
--
-- Enabled-only projection of agent_tool_registry, used by policy_service so
-- it never has to remember to filter is_enabled=1 at every call site.
--------------------------------------------------------------------------------
REPLACE VIEW context.vw_enabled_tool_registry AS
SELECT
    atr.tool_name
    ,atr.category
    ,atr.description
    ,atr.requires_approval
    ,atr.is_read_only
    ,atr.min_role_required
    ,atr.use_case_allowlist_csv
FROM context.agent_tool_registry atr
WHERE atr.is_enabled = 1
;

COMMENT ON VIEW context.vw_enabled_tool_registry IS
    'Enabled-only tool registry entries. Primary read path for policy_service tool-eligibility checks.';
