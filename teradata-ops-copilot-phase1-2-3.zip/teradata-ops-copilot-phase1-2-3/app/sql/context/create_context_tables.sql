--------------------------------------------------------------------------------
-- create_context_tables.sql
--
-- Curated "context" schema for the Teradata Ops Copilot.
--
-- Purpose: this schema is the ONLY surface the agent/LLM runtime is allowed
-- to read from directly (via the repository layer). It is deliberately
-- decoupled from production source tables so that:
--   1. PCI Secure Zone objects and other sensitive production tables are
--      never exposed directly to agent tooling.
--   2. The agent-facing contract can stay stable even as underlying
--      production schemas evolve (ETL/Ab Initio jobs, BigQuery QueryGrid
--      objects, etc.).
--   3. Every fact surfaced to the LLM is traceable to a named, governed
--      object for audit purposes.
--
-- Conventions used throughout this file:
--   - PRIMARY INDEX (PI) is used instead of PRIMARY KEY (Teradata has no
--     enforced PK/FK constraints by default; PI determines row distribution
--     and should be chosen for even distribution + common join/access
--     patterns, not just uniqueness).
--   - All tables include audit-style columns (created_ts, updated_ts,
--     created_by/updated_by) plus domain-specific severity/confidence/status
--     columns called for in the spec.
--   - VARCHAR lengths are practical defaults; tune to actual data during
--     implementation (TODO markers below where this is most likely).
--   - CHARACTER SET LATIN is assumed for ASCII-range identifier/status
--     columns; switch to UNICODE if non-Latin text (e.g. free-text
--     descriptions) is expected. TODO: confirm with platform standards.
--
-- Run order: this file must be executed before create_context_views.sql.
--------------------------------------------------------------------------------

-- Adjust to the target database/schema name per environment.
-- TODO: parameterize via deployment tooling rather than hardcoding "context".
DATABASE context;


--------------------------------------------------------------------------------
-- context.data_product_catalog
--
-- Canonical registry of business data products (dashboards, marts, feeds)
-- that the copilot can reason about. This is the resolution target for
-- entity_resolver when a request mentions a data product by business name.
--------------------------------------------------------------------------------
CREATE MULTISET TABLE context.data_product_catalog
(
    data_product_id        VARCHAR(64)     CHARACTER SET LATIN NOT NULL
        ,name                   VARCHAR(256)    CHARACTER SET UNICODE NOT NULL
        ,domain                 VARCHAR(128)    CHARACTER SET LATIN
        ,description            VARCHAR(2000)   CHARACTER SET UNICODE
        ,owner                  VARCHAR(128)    CHARACTER SET LATIN NOT NULL
        ,owning_team            VARCHAR(128)    CHARACTER SET LATIN
        ,business_criticality   VARCHAR(16)     CHARACTER SET LATIN  -- e.g. 'critical','high','medium','low'
        ,sla_target_time        TIME(0)                                -- e.g. 08:00:00 for "8 AM SLA"
        ,status                 VARCHAR(16)     CHARACTER SET LATIN DEFAULT 'active'  -- active|deprecated|retired
        ,confidence             DECIMAL(5,4)    DEFAULT 1.0000          -- catalog curation confidence, 0..1
        ,created_ts             TIMESTAMP(6)    DEFAULT CURRENT_TIMESTAMP(6)
        ,updated_ts             TIMESTAMP(6)    DEFAULT CURRENT_TIMESTAMP(6)
        ,created_by             VARCHAR(64)     CHARACTER SET LATIN
        ,updated_by             VARCHAR(64)     CHARACTER SET LATIN
)
PRIMARY INDEX (data_product_id);

COMMENT ON TABLE context.data_product_catalog IS
    'Canonical registry of business data products (dashboards/marts/feeds). Primary entity-resolution target for data_product entity type.';


--------------------------------------------------------------------------------
-- context.data_product_alias
--
-- Maps informal/business language ("the finance dashboard", "billing feed")
-- to canonical data_product_id values in data_product_catalog. Supports
-- multiple aliases per product and tracks match confidence for cases where
-- an alias is fuzzy/historic rather than an exact synonym.
--------------------------------------------------------------------------------
CREATE MULTISET TABLE context.data_product_alias
(
    alias_id                VARCHAR(64)    CHARACTER SET LATIN NOT NULL
        ,data_product_id        VARCHAR(64)    CHARACTER SET LATIN NOT NULL
        ,alias_text             VARCHAR(256)   CHARACTER SET UNICODE NOT NULL
        ,alias_type             VARCHAR(32)    CHARACTER SET LATIN DEFAULT 'synonym'  -- synonym|abbreviation|historic_name|misspelling
        ,confidence             DECIMAL(5,4)   DEFAULT 1.0000           -- alias match confidence, 0..1
        ,status                 VARCHAR(16)    CHARACTER SET LATIN DEFAULT 'active'
        ,created_ts             TIMESTAMP(6)   DEFAULT CURRENT_TIMESTAMP(6)
        ,updated_ts             TIMESTAMP(6)   DEFAULT CURRENT_TIMESTAMP(6)
        ,created_by             VARCHAR(64)    CHARACTER SET LATIN
)
PRIMARY INDEX (data_product_id);
-- PI matches data_product_catalog's PI to colocate alias lookups with their
-- parent product row for efficient joins (see get_alias_matches.sql).

COMMENT ON TABLE context.data_product_alias IS
    'Alias/synonym table mapping informal business language to canonical data_product_id. Used by entity_resolver before falling back to fuzzy matching.';


--------------------------------------------------------------------------------
-- context.pipeline_health
--
-- Latest and historical run-level health for ETL/Ab Initio pipelines feeding
-- data products. One row per (pipeline_id, run_id). vw_latest_pipeline_status
-- (see create_context_views.sql) exposes only the most recent run per
-- pipeline for the common "what's the current state" query pattern.
--------------------------------------------------------------------------------
CREATE MULTISET TABLE context.pipeline_health
(
    pipeline_id             VARCHAR(64)     CHARACTER SET LATIN NOT NULL
        ,run_id                  VARCHAR(64)     CHARACTER SET LATIN NOT NULL
        ,data_product_id        VARCHAR(64)     CHARACTER SET LATIN
        ,pipeline_name           VARCHAR(256)    CHARACTER SET UNICODE
        ,status                  VARCHAR(32)     CHARACTER SET LATIN NOT NULL  -- success|failed|running|skipped|delayed
        ,sla_target_ts           TIMESTAMP(0)
        ,actual_start_ts         TIMESTAMP(0)
        ,actual_completion_ts    TIMESTAMP(0)
        ,sla_met                 BYTEINT                                       -- 1=met,0=missed,NULL=not yet determined
        ,failure_reason          VARCHAR(2000)   CHARACTER SET UNICODE
        ,severity                VARCHAR(16)     CHARACTER SET LATIN           -- critical|high|medium|low
        ,owner                   VARCHAR(128)    CHARACTER SET LATIN
        ,rows_processed          BIGINT
        ,source_system           VARCHAR(128)    CHARACTER SET LATIN           -- e.g. 'ab_initio','bigquery_querygrid'
        ,confidence              DECIMAL(5,4)    DEFAULT 1.0000                -- confidence in this health record (e.g. partial telemetry)
        ,created_ts              TIMESTAMP(6)    DEFAULT CURRENT_TIMESTAMP(6)
        ,updated_ts              TIMESTAMP(6)    DEFAULT CURRENT_TIMESTAMP(6)
)
PRIMARY INDEX (pipeline_id);

COMMENT ON TABLE context.pipeline_health IS
    'Per-run health/status history for ETL pipelines (Ab Initio, QueryGrid, etc). Source for SLA-miss and failed-job root-cause evidence.';


--------------------------------------------------------------------------------
-- context.data_dependency
--
-- Directed edges describing upstream -> downstream relationships between
-- data products / pipelines, used to build dependency chains for impact
-- analysis ("what upstream delay could have caused this downstream miss?").
--------------------------------------------------------------------------------
CREATE MULTISET TABLE context.data_dependency
(
    dependency_id           VARCHAR(64)    CHARACTER SET LATIN NOT NULL
        ,upstream_id             VARCHAR(64)    CHARACTER SET LATIN NOT NULL  -- data_product_id or pipeline_id
        ,downstream_id           VARCHAR(64)    CHARACTER SET LATIN NOT NULL
        ,relationship_type       VARCHAR(32)    CHARACTER SET LATIN DEFAULT 'feeds'  -- feeds|refreshes|aggregates|triggers
        ,criticality             VARCHAR(16)    CHARACTER SET LATIN            -- how critical this edge is to downstream SLA
        ,status                  VARCHAR(16)    CHARACTER SET LATIN DEFAULT 'active'
        ,confidence              DECIMAL(5,4)   DEFAULT 1.0000
        ,created_ts              TIMESTAMP(6)   DEFAULT CURRENT_TIMESTAMP(6)
        ,updated_ts              TIMESTAMP(6)   DEFAULT CURRENT_TIMESTAMP(6)
)
PRIMARY INDEX (upstream_id);
-- PI on upstream_id favors the common "walk downstream from this failure"
-- traversal direction used in get_dependency_chain.sql. TODO: if reverse
-- traversal (find upstream causes) turns out to dominate query patterns in
-- production, consider a secondary index on downstream_id instead/also.

COMMENT ON TABLE context.data_dependency IS
    'Directed upstream->downstream dependency edges between data products/pipelines. Used for impact and root-cause chain analysis.';


--------------------------------------------------------------------------------
-- context.workload_signal
--
-- Time-series workload/resource signals (spool usage, CPU, skew, blocking)
-- used to diagnose workload saturation root causes. Conceptually similar to
-- ResUsage-derived metrics but pre-aggregated/curated for agent consumption
-- rather than raw DBC system table data.
--------------------------------------------------------------------------------
CREATE MULTISET TABLE context.workload_signal
(
    signal_id                VARCHAR(64)    CHARACTER SET LATIN NOT NULL
        ,workload_id              VARCHAR(64)    CHARACTER SET LATIN NOT NULL  -- TASM/TIWM workload classification name
        ,signal_ts                TIMESTAMP(0)   NOT NULL
        ,metric_name              VARCHAR(64)    CHARACTER SET LATIN NOT NULL  -- e.g. 'spool_pct_used','cpu_skew','blocked_sessions'
        ,metric_value             DECIMAL(18,4)  NOT NULL
        ,threshold_value          DECIMAL(18,4)
        ,threshold_breached       BYTEINT                                       -- 1=breached,0=not breached,NULL=no threshold defined
        ,severity                 VARCHAR(16)    CHARACTER SET LATIN
        ,related_data_product_id VARCHAR(64)    CHARACTER SET LATIN
        ,confidence               DECIMAL(5,4)   DEFAULT 1.0000
        ,created_ts               TIMESTAMP(6)   DEFAULT CURRENT_TIMESTAMP(6)
)
PRIMARY INDEX (workload_id);

COMMENT ON TABLE context.workload_signal IS
    'Curated workload/resource pressure signals (spool, CPU, skew) keyed by TASM/TIWM workload_id. Source for workload_saturation root-cause evidence.';


--------------------------------------------------------------------------------
-- context.access_policy
--
-- Business-object access policy rules (distinct from agent_tool_registry,
-- which governs which copilot TOOLS may be invoked). This table governs
-- which ROLES are required to access which classes of underlying objects,
-- primarily used for access_review / security_audit use cases and PCI
-- Secure Zone sensitivity classification.
--------------------------------------------------------------------------------
CREATE MULTISET TABLE context.access_policy
(
    policy_id                VARCHAR(64)    CHARACTER SET LATIN NOT NULL
        ,object_pattern           VARCHAR(256)   CHARACTER SET LATIN NOT NULL  -- glob/LIKE pattern, e.g. 'FIN_PROD.*'
        ,required_role            VARCHAR(128)   CHARACTER SET LATIN
        ,sensitivity_level        VARCHAR(16)    CHARACTER SET LATIN           -- pci|internal|public|restricted
        ,action_class             VARCHAR(16)    CHARACTER SET LATIN           -- read|write|admin
        ,is_active                BYTEINT        DEFAULT 1
        ,effective_ts             TIMESTAMP(0)
        ,expiry_ts                TIMESTAMP(0)
        ,owner                    VARCHAR(128)   CHARACTER SET LATIN
        ,confidence               DECIMAL(5,4)   DEFAULT 1.0000
        ,created_ts               TIMESTAMP(6)   DEFAULT CURRENT_TIMESTAMP(6)
        ,updated_ts               TIMESTAMP(6)   DEFAULT CURRENT_TIMESTAMP(6)
)
PRIMARY INDEX (policy_id);

COMMENT ON TABLE context.access_policy IS
    'Business-object access policy rules (required role, sensitivity, action class) keyed by object pattern. Consulted for access_review/security_audit use cases. NOT the tool-eligibility registry -- see agent_tool_registry.';


--------------------------------------------------------------------------------
-- context.agent_tool_registry
--
-- Static (slowly-changing) registry of which MCP tools exist, which
-- category they belong to, whether they require approval, and which
-- use cases they are eligible for. This is the primary least-privilege
-- control read by policy_service / check_policy_and_tool_eligibility.
--------------------------------------------------------------------------------
CREATE MULTISET TABLE context.agent_tool_registry
(
    tool_name                 VARCHAR(128)   CHARACTER SET LATIN NOT NULL  -- exact MCP tool name, e.g. 'sec_userDbPermissions'
        ,category                  VARCHAR(16)    CHARACTER SET LATIN NOT NULL  -- base|dba|security|vector
        ,description               VARCHAR(1000)  CHARACTER SET UNICODE
        ,is_enabled                BYTEINT        DEFAULT 1
        ,requires_approval         BYTEINT        DEFAULT 0
        ,is_read_only              BYTEINT        DEFAULT 1
        ,min_role_required         VARCHAR(128)   CHARACTER SET LATIN
        ,use_case_allowlist_csv    VARCHAR(1000)  CHARACTER SET LATIN           -- comma-separated UseCaseName values; TODO: normalize to a child table if list grows large or needs per-value queries
        ,severity_if_misused       VARCHAR(16)    CHARACTER SET LATIN           -- informational tag for review prioritization
        ,last_reviewed_ts          TIMESTAMP(0)
        ,created_ts                TIMESTAMP(6)   DEFAULT CURRENT_TIMESTAMP(6)
        ,updated_ts                TIMESTAMP(6)   DEFAULT CURRENT_TIMESTAMP(6)
)
PRIMARY INDEX (tool_name);

COMMENT ON TABLE context.agent_tool_registry IS
    'Static registry of MCP tools: category, approval requirement, read-only flag, and use-case allowlist. Authoritative source for least-privilege tool filtering.';


--------------------------------------------------------------------------------
-- context.context_audit
--
-- Append-only audit log of workflow executions. Maps closely to
-- app/models/audit.py:AuditRecord. Intentionally denormalized (tool
-- sequence and root causes stored as delimited/JSON text rather than child
-- tables) to keep writes simple and atomic from audit_repo.py.
--
-- TODO: if reporting needs grow (e.g. "tool X used N times last week"
-- across all requests), consider normalizing tool_sequence_json into a
-- child table context.context_audit_tool_invocation. Left denormalized for
-- now per "practical defaults" guidance.
--------------------------------------------------------------------------------
CREATE MULTISET TABLE context.context_audit
(
    request_id                VARCHAR(64)    CHARACTER SET LATIN NOT NULL
        ,user_name                 VARCHAR(128)   CHARACTER SET LATIN NOT NULL
        ,use_case_name             VARCHAR(64)    CHARACTER SET LATIN NOT NULL
        ,resolved_entity_id        VARCHAR(64)    CHARACTER SET LATIN
        ,resolved_entity_type      VARCHAR(32)    CHARACTER SET LATIN
        ,clarification_required    BYTEINT        DEFAULT 0
        ,policy_decision_status    VARCHAR(32)    CHARACTER SET LATIN
        ,policy_reason             VARCHAR(2000)  CHARACTER SET UNICODE
        ,tool_sequence_json        VARCHAR(8000)  CHARACTER SET UNICODE         -- JSON array of ToolInvocationAuditEntry
        ,top_root_causes_json      VARCHAR(4000)  CHARACTER SET UNICODE         -- JSON array of RootCauseAuditEntry
        ,action_recommended        VARCHAR(64)    CHARACTER SET LATIN
        ,approval_status           VARCHAR(32)    CHARACTER SET LATIN
        ,action_outcome            VARCHAR(64)    CHARACTER SET LATIN
        ,started_ts                TIMESTAMP(6)   NOT NULL
        ,completed_ts              TIMESTAMP(6)
        ,elapsed_ms                DECIMAL(18,3)
        ,errors_json               VARCHAR(4000)  CHARACTER SET UNICODE
        ,fallback_paths_json       VARCHAR(2000)  CHARACTER SET UNICODE
        ,extra_json                VARCHAR(4000)  CHARACTER SET UNICODE
        ,created_ts                TIMESTAMP(6)   DEFAULT CURRENT_TIMESTAMP(6)
)
PRIMARY INDEX (request_id);

COMMENT ON TABLE context.context_audit IS
    'Append-only audit log of workflow executions, one row per request_id. Maps to models/audit.py:AuditRecord. JSON text columns hold tool sequence / root causes / errors for replay and reporting.';
