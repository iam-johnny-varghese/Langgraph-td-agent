--------------------------------------------------------------------------------
-- get_alias_matches.sql
--
-- Resolves a free-text entity hint to candidate canonical data products via
-- exact and partial alias matching. Returns ALL matches above a minimal
-- relevance bar -- it is the CALLER's (entity_resolver.py) job to decide
-- whether the result set is unambiguous enough to resolve automatically or
-- whether clarification_required should be set.
--
-- Used by: services/entity_resolver.py:resolve_via_alias()
-- Params : :entity_hint  (str, required) -- raw or lightly normalized text
--
-- Matching strategy (simple, deterministic, no fuzzy/ML matching here):
--   1. Exact match (case-insensitive) on alias_text -- highest confidence.
--   2. Substring match (alias contained in hint, or hint contained in
--      alias) -- lower, alias-specific confidence.
-- TODO: if this proves too brittle in practice (e.g. typos), consider a
-- vector-similarity fallback via VectorToolsAdapter rather than adding
-- fuzzy SQL matching here -- keeps SQL deterministic and auditable.
--------------------------------------------------------------------------------
SELECT
    da.alias_id
    ,da.data_product_id
    ,dpc.name AS data_product_name
    ,da.alias_text
    ,da.alias_type
    ,da.confidence AS alias_confidence
    ,CASE
        WHEN UPPER(TRIM(da.alias_text)) = UPPER(TRIM(:entity_hint)) THEN 1.0000
        ELSE da.confidence * 0.7500
     END AS match_confidence
FROM context.data_product_alias da
INNER JOIN context.data_product_catalog dpc
        ON dpc.data_product_id = da.data_product_id
       AND dpc.status = 'active'
WHERE da.status = 'active'
  AND (
        UPPER(TRIM(da.alias_text)) = UPPER(TRIM(:entity_hint))
        OR UPPER(TRIM(:entity_hint)) LIKE '%' || UPPER(TRIM(da.alias_text)) || '%'
        OR UPPER(TRIM(da.alias_text)) LIKE '%' || UPPER(TRIM(:entity_hint)) || '%'
      )
ORDER BY match_confidence DESC
;
