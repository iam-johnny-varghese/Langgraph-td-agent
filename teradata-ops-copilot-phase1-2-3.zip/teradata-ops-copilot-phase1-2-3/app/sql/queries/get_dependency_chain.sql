--------------------------------------------------------------------------------
-- get_dependency_chain.sql
--
-- Walks the dependency graph downstream from a given root entity, up to a
-- bounded depth, using a recursive query. Used to answer "what downstream
-- things could be affected by this upstream failure" (impact analysis) --
-- the spec's "dependency chain" requirement for retrieve_primary_context.
--
-- Used by: repositories/teradata_context_repo.py:get_dependency_chain()
-- Params : :root_id     (str, required) -- starting upstream_id
--          :max_depth   (int, required) -- recursion depth bound, e.g. 5
--
-- Direction note: this traverses upstream -> downstream (impact analysis).
-- For "what upstream cause could explain this downstream symptom" (root
-- cause analysis), swap the join direction (UNION ALL branch joins on
-- downstream_id = root, walks via upstream_id) -- see TODO at bottom.
--
-- Teradata recursive query syntax: WITH RECURSIVE is supported; depth bound
-- is enforced explicitly via a counter column rather than relying solely on
-- cycle detection, since dependency data could in principle contain a cycle
-- (e.g. a misconfigured circular refresh) that would otherwise loop forever.
--------------------------------------------------------------------------------
WITH RECURSIVE dependency_chain (upstream_id, downstream_id, relationship_type, criticality, depth) AS
(
    -- Anchor: direct children of the root
    SELECT
        ed.upstream_id
        ,ed.downstream_id
        ,ed.relationship_type
        ,ed.criticality
        ,1 AS depth
    FROM context.vw_active_dependency_edges ed
    WHERE ed.upstream_id = :root_id

    UNION ALL

    -- Recursive step: walk further downstream, bounded by :max_depth
    SELECT
        ed.upstream_id
        ,ed.downstream_id
        ,ed.relationship_type
        ,ed.criticality
        ,dc.depth + 1 AS depth
    FROM context.vw_active_dependency_edges ed
    INNER JOIN dependency_chain dc
            ON ed.upstream_id = dc.downstream_id
    WHERE dc.depth < :max_depth
)
SELECT
    upstream_id
    ,downstream_id
    ,relationship_type
    ,criticality
    ,depth
FROM dependency_chain
ORDER BY depth, upstream_id, downstream_id
;

-- TODO (upstream/root-cause direction variant):
-- Anchor:    WHERE ed.downstream_id = :root_id
-- Recursive: INNER JOIN dependency_chain dc ON ed.downstream_id = dc.upstream_id
-- Consider adding as a second file (get_upstream_cause_chain.sql) once a
-- concrete caller for that direction exists, to keep each query file's
-- intent unambiguous from its name.
