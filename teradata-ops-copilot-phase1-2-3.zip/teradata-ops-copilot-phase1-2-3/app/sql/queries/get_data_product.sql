--------------------------------------------------------------------------------
-- get_data_product.sql
--
-- Fetches a single data product by canonical data_product_id.
--
-- Used by: repositories/teradata_context_repo.py:get_data_product()
-- Params : :data_product_id  (str, required)
--
-- TODO: this is a Python string-template-style placeholder file (`:name`
-- bind-style params shown for clarity). Actual parameter binding style
-- (teradatasql qmark vs named) should match whatever driver convention
-- teradata_context_repo.py settles on -- see TODO there.
--------------------------------------------------------------------------------
SELECT
    data_product_id
    ,name
    ,domain
    ,description
    ,owner
    ,owning_team
    ,business_criticality
    ,sla_target_time
    ,status
    ,confidence
FROM context.vw_data_product_with_owner
WHERE data_product_id = :data_product_id
;
