--------------------------------------------------------------------------------
-- get_workload_signals.sql
--
-- Fetches recent breached workload signals for a specific workload_id (e.g.
-- a TASM/TIWM workload classification), used as evidence for the
-- workload_saturation root-cause category.
--
-- Used by: repositories/teradata_ops_repo.py:get_workload_signals()
-- Params : :workload_id  (str, required)
--          :top_n        (int, required) -- e.g. 50; row cap per spec's
--                         "use TOP n instead of LIMIT" rule.
--
-- Reads from vw_breached_workload_signals (already filtered to
-- threshold_breached=1 and last 24h) rather than the base table, so this
-- query stays simple; if a caller needs non-breached signals too (e.g. for
-- a trend chart rather than root-cause evidence), query
-- context.workload_signal directly with an explicit window instead.
--------------------------------------------------------------------------------
SELECT TOP :top_n
    signal_id
    ,workload_id
    ,signal_ts
    ,metric_name
    ,metric_value
    ,threshold_value
    ,threshold_breached
    ,severity
    ,related_data_product_id
    ,confidence
FROM context.vw_breached_workload_signals
WHERE workload_id = :workload_id
ORDER BY signal_ts DESC
;
