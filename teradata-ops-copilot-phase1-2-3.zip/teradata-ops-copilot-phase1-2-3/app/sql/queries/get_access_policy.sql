--------------------------------------------------------------------------------
-- get_access_policy.sql
--
-- Fetches active access policy rules whose object_pattern matches a given
-- canonical object name. Used for access_review / security_audit use cases
-- to determine the required role/sensitivity for a target object before
-- the security tools adapter is invoked to check actual current grants.
--
-- Used by: repositories/teradata_security_repo.py:get_access_policy()
-- Params : :object_name  (str, required) -- fully-qualified canonical
--                         object name to check against stored patterns,
--                         e.g. 'FIN_PROD.GL_SUMMARY'
--
-- Matching note: object_pattern is stored using SQL LIKE wildcard syntax
-- (e.g. 'FIN_PROD.%'), so the match direction is pattern-contains-name,
-- not name-contains-pattern -- this is the opposite direction from
-- get_alias_matches.sql's free-text matching and should not be confused
-- with it.
--------------------------------------------------------------------------------
SELECT
    policy_id
    ,object_pattern
    ,required_role
    ,sensitivity_level
    ,action_class
    ,is_active
    ,effective_ts
    ,expiry_ts
    ,owner
    ,confidence
FROM context.access_policy
WHERE is_active = 1
  AND (effective_ts IS NULL OR effective_ts <= CURRENT_TIMESTAMP(0))
  AND (expiry_ts IS NULL OR expiry_ts > CURRENT_TIMESTAMP(0))
  AND UPPER(:object_name) LIKE UPPER(object_pattern)
ORDER BY
    -- Prefer more specific (longer, fewer wildcards) patterns first so the
    -- caller can take the first row as the "most specific applicable rule"
    -- if multiple patterns match.
    CHARACTER_LENGTH(object_pattern) DESC
;
