--------------------------------------------------------------------------------
-- get_latest_pipeline_status.sql
--
-- Fetches the latest run status for either:
--   (a) a single named pipeline (:pipeline_id), or
--   (b) all pipelines feeding a given data product (:data_product_id)
-- Exactly one of the two parameters should be supplied by the caller;
-- repository code is responsible for choosing which variant to bind
-- (see TODO below) rather than relying on SQL to silently handle both.
--
-- Used by: repositories/teradata_ops_repo.py:get_latest_pipeline_status()
-- Params : :pipeline_id      (str, optional)
--          :data_product_id  (str, optional)
--
-- TODO: Teradata SQL has no clean optional-parameter idiom; the current
-- approach (OR with NULL-coalescing) works but always scans both predicate
-- branches. If this view is queried at high frequency, consider splitting
-- into two separate query files (get_latest_pipeline_status_by_pipeline.sql /
-- _by_data_product.sql) and having the repository pick the file, which also
-- makes "omit unspecified parameters" easier to enforce at the call site.
--------------------------------------------------------------------------------
SELECT
    pipeline_id
    ,run_id
    ,data_product_id
    ,pipeline_name
    ,status
    ,sla_target_ts
    ,actual_start_ts
    ,actual_completion_ts
    ,sla_met
    ,failure_reason
    ,severity
    ,owner
    ,rows_processed
    ,source_system
    ,confidence
    ,last_status_change_ts
FROM context.vw_latest_pipeline_status
WHERE (:pipeline_id IS NOT NULL AND pipeline_id = :pipeline_id)
   OR (:data_product_id IS NOT NULL AND data_product_id = :data_product_id)
ORDER BY last_status_change_ts DESC
;
