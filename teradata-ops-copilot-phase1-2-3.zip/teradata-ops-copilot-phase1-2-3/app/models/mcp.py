"""
MCP integration models for the Teradata Ops Copilot.

These models define the contract between mcp/tool_registry.py,
mcp/client.py, and the category-specific adapters in mcp/adapters/. They
are deliberately separate from models/domain.py's ToolInvocation, which is
the *audit-facing* record of a call; these are the *request/response*
shapes used to actually make the call.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field, field_validator


class MCPToolCategory(str, Enum):
    BASE = "base"
    DBA = "dba"
    SECURITY = "security"
    VECTOR = "vector"


class MCPToolDefinition(BaseModel):
    """Describes a single MCP tool as known to ToolRegistry.

    param_schema is intentionally loose (dict of name -> type string) rather
    than a full JSON Schema object, since the registry's job is exact-name
    validation and required/optional bookkeeping, not full schema
    validation -- that's left to the adapter and/or the MCP server itself.
    """

    name: str = Field(..., description="Exact tool name as exposed by Teradata Enterprise MCP, e.g. 'sec_userDbPermissions'.")
    category: MCPToolCategory
    description: str
    required_params: list[str] = Field(default_factory=list)
    optional_params: list[str] = Field(default_factory=list)
    param_types: dict[str, str] = Field(default_factory=dict, description="Param name -> simple type hint, e.g. {'user_name': 'str'}.")
    is_read_only: bool = True
    is_enabled: bool = True


class MCPToolRequest(BaseModel):
    """A validated, ready-to-send request to a single MCP tool.

    Construction of this object is where 'do not guess missing identifiers'
    and 'omit null/empty parameters' are enforced -- see
    mcp/adapters/base_tools.py:ToolAdapter.build_request for the validation
    path that should always be used instead of constructing this directly.
    """

    tool_name: str
    category: MCPToolCategory
    parameters: dict[str, Any] = Field(default_factory=dict)
    requested_ts: datetime = Field(default_factory=datetime.utcnow)

    @field_validator("parameters")
    @classmethod
    def _no_null_or_empty_values(cls, v: dict[str, Any]) -> dict[str, Any]:
        cleaned = {}
        for key, val in v.items():
            if val is None:
                continue
            if isinstance(val, str):
                trimmed = val.strip()
                if trimmed == "":
                    continue
                cleaned[key] = trimmed
            else:
                cleaned[key] = val
        return cleaned


class MCPToolResultStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"
    REJECTED = "rejected"
    TIMEOUT = "timeout"


class MCPToolResult(BaseModel):
    """Normalized result envelope returned by MCPClient.call_tool.

    raw_result is kept separate from result_summary so adapters can choose
    to forward only the summary into ContextPack.mcp_enrichment, avoiding
    accidental leakage of unredacted sensitive fields (e.g. full permission
    grant lists) into LLM-facing context.
    """

    tool_name: str
    status: MCPToolResultStatus
    raw_result: Optional[dict[str, Any]] = None
    result_summary: Optional[str] = None
    error_message: Optional[str] = None
    latency_ms: Optional[float] = None
