"""
Policy models for the Teradata Ops Copilot.

These models represent the *data* read by policy_service from
context.agent_tool_registry and context.access_policy, as distinct from
the *decision* the service produces (PolicyDecision, in models/domain.py).
Keeping the row-shape models here and the decision model in domain.py
mirrors the repository -> service -> workflow layering used elsewhere.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class ToolCategory(str, Enum):
    BASE = "base"
    DBA = "dba"
    SECURITY = "security"
    VECTOR = "vector"


class AgentToolRegistryEntry(BaseModel):
    """Maps 1:1 to a row in context.agent_tool_registry.

    use_case_allowlist drives least-privilege tool filtering: a tool is only
    eligible for a given request if the request's use_case_name appears in
    this list AND the tool is not in a global deny state.
    """

    tool_name: str
    category: ToolCategory
    description: Optional[str] = None
    is_enabled: bool = True
    requires_approval: bool = False
    use_case_allowlist: list[str] = Field(default_factory=list)
    min_role_required: Optional[str] = None
    last_reviewed_ts: Optional[datetime] = None


class AccessPolicyRule(BaseModel):
    """Maps 1:1 to a row in context.access_policy.

    Distinct from AgentToolRegistryEntry: this governs *business object*
    access (e.g. "production finance objects require elevated role X"),
    not which copilot tool may be invoked. Both are consulted by
    policy_service when forming a PolicyDecision.
    """

    policy_id: str
    object_pattern: str = Field(..., description="Glob/LIKE pattern over canonical object names, e.g. 'FIN_PROD.*'.")
    required_role: Optional[str] = None
    sensitivity_level: Optional[str] = Field(default=None, description="e.g. 'pci', 'internal', 'public'.")
    action_class: Optional[str] = Field(default=None, description="e.g. 'read', 'write', 'admin'.")
    is_active: bool = True
    effective_ts: Optional[datetime] = None
    expiry_ts: Optional[datetime] = None
