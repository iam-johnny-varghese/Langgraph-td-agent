"""
Domain models for the Teradata Ops Copilot.

These models represent business entities resolved and reasoned about during
a workflow run: requests, resolved entities, context packs, root-cause
candidates, and action plans. They are intentionally decoupled from the
workflow state container (see models/workflow.py) so they can be reused by
API responses, audit persistence, and tests without dragging in the full
state graph shape.

All models use Pydantic for validation. Field constraints are deliberately
conservative (e.g. confidence scores bounded 0..1) to fail fast on bad data
rather than let malformed values silently propagate into LLM prompts or SQL.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field, field_validator


class UseCaseName(str, Enum):
    """Supported use cases the intake node can classify a request into.

    TODO: Extend as new copilot capabilities are added. Keep this enum the
    single source of truth for use-case-to-tool-pack mapping in policy_service.
    """

    PIPELINE_INCIDENT_DIAGNOSIS = "pipeline_incident_diagnosis"
    SECURITY_AUDIT = "security_audit"
    WORKLOAD_ANALYSIS = "workload_analysis"
    ACCESS_REVIEW = "access_review"
    REMEDIATION_REQUEST = "remediation_request"
    UNKNOWN = "unknown"


class EntityType(str, Enum):
    """Canonical entity types resolvable via context.data_product_catalog
    and related alias/catalog tables."""

    DATA_PRODUCT = "data_product"
    PIPELINE = "pipeline"
    WORKLOAD = "workload"
    USER = "user"
    INCIDENT = "incident"
    DASHBOARD = "dashboard"
    UNKNOWN = "unknown"


class UserRequest(BaseModel):
    """Raw inbound request captured at intake, before any classification
    or entity resolution has occurred.

    This is the only model that should ever hold truly raw, unvalidated
    user text. Everything downstream operates on derived, structured data.
    """

    request_id: str = Field(..., description="Caller-supplied or generated UUID for this request.")
    session_id: Optional[str] = Field(default=None, description="Session/thread identifier, if applicable.")
    requesting_user: str = Field(..., description="Identity of the user issuing the request (e.g. SSO/LDAP id).")
    raw_text: str = Field(..., description="The verbatim natural-language request text.")
    submitted_ts: datetime = Field(default_factory=datetime.utcnow)
    channel: Optional[str] = Field(default=None, description="Origin channel, e.g. 'teams', 'api', 'cli'.")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Free-form session metadata; not used for policy decisions.")

    @field_validator("raw_text")
    @classmethod
    def _non_empty_text(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("raw_text must not be empty")
        return v.strip()


class EntityCandidate(BaseModel):
    """A single candidate match produced during entity resolution.

    Multiple candidates with comparable confidence should trigger
    clarification_required=True on ResolvedEntity rather than a guess.
    """

    canonical_id: str
    entity_type: EntityType
    display_name: str
    confidence: float = Field(..., ge=0.0, le=1.0)
    matched_alias: Optional[str] = Field(default=None, description="The alias/synonym text that produced this match, if any.")


class ResolvedEntity(BaseModel):
    """Output of resolve_entity node.

    If clarification_required is True, canonical_id/entity_type should be
    treated as advisory only (best guess) and the workflow must not proceed
    to context retrieval or MCP enrichment without user disambiguation.
    """

    canonical_id: Optional[str] = None
    entity_type: EntityType = EntityType.UNKNOWN
    display_name: Optional[str] = None
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    candidates: list[EntityCandidate] = Field(default_factory=list)
    clarification_required: bool = False
    clarification_reason: Optional[str] = None
    raw_entity_hint: Optional[str] = Field(default=None, description="The original text fragment used to attempt resolution.")


class PolicyDecisionStatus(str, Enum):
    BLOCKED = "blocked"
    READ_ONLY = "read_only"
    APPROVAL_REQUIRED = "approval_required"
    APPROVED_FOR_SAFE_ACTION = "approved_for_safe_action"


class PolicyDecision(BaseModel):
    """Output of check_policy_and_tool_eligibility node.

    allowed_tools is the authoritative least-privilege allow-list for the
    remainder of the workflow; mcp adapters must reject any tool call whose
    name is not present in this list regardless of what a node requests.
    """

    status: PolicyDecisionStatus
    allowed_tools: list[str] = Field(default_factory=list)
    denied_tools: list[str] = Field(default_factory=list)
    policy_reason: str
    requires_approval_for_actions: list[str] = Field(default_factory=list)
    evaluated_ts: datetime = Field(default_factory=datetime.utcnow)


class PipelineHealthSnapshot(BaseModel):
    """Subset of context.pipeline_health relevant to a single pipeline run."""

    pipeline_id: str
    run_id: Optional[str] = None
    status: str
    sla_target_ts: Optional[datetime] = None
    actual_completion_ts: Optional[datetime] = None
    sla_met: Optional[bool] = None
    failure_reason: Optional[str] = None
    severity: Optional[str] = None
    owner: Optional[str] = None


class DataProductSummary(BaseModel):
    """Subset of context.data_product_catalog relevant for grounding."""

    data_product_id: str
    name: str
    owner: str
    domain: Optional[str] = None
    description: Optional[str] = None
    business_criticality: Optional[str] = None


class DependencyEdge(BaseModel):
    """A single edge in the dependency chain (upstream -> downstream)."""

    upstream_id: str
    downstream_id: str
    relationship_type: str = Field(default="feeds", description="e.g. 'feeds', 'refreshes', 'aggregates'.")


class WorkloadSignal(BaseModel):
    """Subset of context.workload_signal relevant to spool/CPU pressure analysis."""

    workload_id: str
    signal_ts: datetime
    metric_name: str
    metric_value: float
    threshold_breached: Optional[bool] = None


class ContextPack(BaseModel):
    """Normalized, curated context assembled for the LLM/agent runtime.

    This is the single object that generate_user_explanation and
    score_root_cause_candidates are allowed to read facts from. No node
    downstream of retrieve_primary_context should query raw repositories
    directly; everything must flow through (and be added to) the ContextPack
    so that grounding stays auditable.
    """

    primary_entity: ResolvedEntity
    data_product: Optional[DataProductSummary] = None
    pipeline_health: list[PipelineHealthSnapshot] = Field(default_factory=list)
    dependencies: list[DependencyEdge] = Field(default_factory=list)
    workload_signals: list[WorkloadSignal] = Field(default_factory=list)
    mcp_enrichment: dict[str, Any] = Field(default_factory=dict, description="Keyed by tool name; raw-ish but redacted tool results.")
    runbook_snippets: list[str] = Field(default_factory=list, description="Vector-retrieved SOP/runbook excerpts, paraphrased/curated.")
    assembled_ts: datetime = Field(default_factory=datetime.utcnow)
    missing_data_flags: list[str] = Field(default_factory=list, description="Explicit gaps, e.g. 'no_pipeline_health_rows_found'.")


class ToolInvocation(BaseModel):
    """A single MCP (or internal) tool call record for audit and tracing."""

    tool_name: str
    category: str = Field(..., description="One of: base, dba, security, vector.")
    parameters: dict[str, Any] = Field(default_factory=dict)
    status: str = Field(default="pending", description="pending | success | error | rejected")
    latency_ms: Optional[float] = None
    result_summary: Optional[str] = Field(default=None, description="Short, redacted summary; never raw PII dumps.")
    error_message: Optional[str] = None
    invoked_ts: datetime = Field(default_factory=datetime.utcnow)


class RootCauseCategory(str, Enum):
    UPSTREAM_DATA_DELAY = "upstream_data_delay"
    FAILED_ETL_JOB = "failed_etl_job"
    WORKLOAD_SATURATION = "workload_saturation"
    SECURITY_REGRESSION = "security_regression"
    SCHEMA_DRIFT = "schema_drift"
    DASHBOARD_REFRESH_FAILURE = "dashboard_refresh_failure"
    UNKNOWN = "unknown"


class RootCauseCandidate(BaseModel):
    """A single ranked hypothesis produced by score_root_cause_candidates.

    evidence_refs should point at identifiable fields/rows within the
    ContextPack (e.g. "pipeline_health[0].failure_reason") so explanations
    can be traced back to source data during review or replay.
    """

    category: RootCauseCategory
    confidence: float = Field(..., ge=0.0, le=1.0)
    evidence_summary: str
    evidence_refs: list[str] = Field(default_factory=list)
    missing_evidence: list[str] = Field(default_factory=list)


class ActionType(str, Enum):
    RERUN_PIPELINE = "rerun_pipeline"
    NOTIFY_OWNER = "notify_owner"
    CREATE_TICKET = "create_ticket"
    INVESTIGATE_PERMISSIONS = "investigate_permissions"
    EXECUTE_MACRO = "execute_macro"
    GRANT_OR_REVOKE_ACCESS = "grant_or_revoke_access"
    CREATE_INCIDENT_SUMMARY = "create_incident_summary"
    GATHER_ADDITIONAL_DIAGNOSTICS = "gather_additional_diagnostics"


class ActionPlan(BaseModel):
    """A proposed (not yet executed) action, derived from root cause analysis.

    requires_approval is set by approval_service based on ActionType, not by
    the node proposing the plan, to keep the approval matrix centralized.
    """

    action_type: ActionType
    target_object: str
    payload: dict[str, Any] = Field(default_factory=dict)
    rationale: str
    requires_approval: bool = True


class ApprovalStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    NOT_REQUIRED = "not_required"
    EXPIRED = "expired"


class ApprovalRequest(BaseModel):
    """Tracks human-in-the-loop approval for a proposed ActionPlan."""

    approval_id: str
    requested_by: str
    action_type: ActionType
    target_object: str
    requested_payload: dict[str, Any] = Field(default_factory=dict)
    status: ApprovalStatus = ApprovalStatus.PENDING
    approved_by: Optional[str] = None
    approved_ts: Optional[datetime] = None
    requested_ts: datetime = Field(default_factory=datetime.utcnow)
    rejection_reason: Optional[str] = None
