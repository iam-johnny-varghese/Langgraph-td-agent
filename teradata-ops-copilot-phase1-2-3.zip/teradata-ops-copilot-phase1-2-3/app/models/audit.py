"""
Audit models for the Teradata Ops Copilot.

AuditRecord is the durable, append-only representation of a single
workflow execution, persisted into context.context_audit via
repositories/audit_repo.py. It is intentionally flatter than WorkflowState
(see models/workflow.py) -- it captures *outcomes*, not intermediate
mutation history -- because audit storage should be cheap to query and
report on (e.g. "show me all approval_required decisions last week").

Replay note (TODO): for full replay/evaluation support, consider persisting
a serialized WorkflowState snapshot alongside AuditRecord (e.g. in a
separate JSON/BLOB column or object store) keyed by request_id. AuditRecord
itself should stay structured and query-friendly.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field

from app.models.domain import (
    ActionType,
    ApprovalStatus,
    PolicyDecisionStatus,
    RootCauseCategory,
)


class ToolInvocationAuditEntry(BaseModel):
    """Lightweight projection of ToolInvocation for embedding in AuditRecord.

    Kept separate from the richer ToolInvocation model (models/domain.py)
    so audit rows don't balloon with full raw parameter/result payloads;
    only what's needed for traceability and reporting is retained.
    """

    tool_name: str
    category: str
    status: str
    latency_ms: Optional[float] = None
    invoked_ts: datetime


class RootCauseAuditEntry(BaseModel):
    """Lightweight projection of RootCauseCandidate for embedding in AuditRecord."""

    category: RootCauseCategory
    confidence: float


class AuditRecord(BaseModel):
    """Persisted record of one end-to-end workflow execution.

    Required fields mirror the AUDIT AND OBSERVABILITY section of the spec:
    request_id, user_name, use_case_name, resolved_entity, policy_decision,
    tool sequence, top root cause candidates, action recommended, approval
    status, action outcome, elapsed time, errors or fallback paths.
    """

    request_id: str
    user_name: str
    use_case_name: str
    resolved_entity_id: Optional[str] = None
    resolved_entity_type: Optional[str] = None
    clarification_required: bool = False

    policy_decision_status: Optional[PolicyDecisionStatus] = None
    policy_reason: Optional[str] = None

    tool_sequence: list[ToolInvocationAuditEntry] = Field(default_factory=list)

    top_root_causes: list[RootCauseAuditEntry] = Field(default_factory=list)

    action_recommended: Optional[ActionType] = None
    approval_status: Optional[ApprovalStatus] = None
    action_outcome: Optional[str] = Field(default=None, description="e.g. 'executed', 'skipped_not_approved', 'failed'.")

    started_ts: datetime
    completed_ts: Optional[datetime] = None
    elapsed_ms: Optional[float] = None

    errors: list[str] = Field(default_factory=list)
    fallback_paths_taken: list[str] = Field(default_factory=list)

    extra: dict[str, Any] = Field(default_factory=dict, description="Escape hatch for use-case-specific audit fields.")
