"""
Workflow state model for the Teradata Ops Copilot.

WorkflowState is the single object threaded through every node in
workflows/ops_copilot_graph.py (see WORKFLOW REQUIREMENTS in the spec).
Each node reads the fields it needs and returns a mutated copy (or mutates
in place, depending on the orchestration style chosen in
ops_copilot_graph.py -- see TODO there) with its own outputs populated.

Design note: this model intentionally aggregates *all* domain models
(UserRequest, ResolvedEntity, PolicyDecision, ContextPack, etc.) as
optional fields that get filled in progressively. This mirrors typical
LangGraph state-graph design where state is a superset TypedDict/BaseModel
rather than each node having a bespoke input/output type. Node-level
docstrings in workflows/nodes/*.py specify which fields each node reads
and writes.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field

from app.models.domain import (
    ActionPlan,
    ApprovalRequest,
    ContextPack,
    PolicyDecision,
    ResolvedEntity,
    RootCauseCandidate,
    ToolInvocation,
    UserRequest,
)


class WorkflowStage(str, Enum):
    """Tracks which node last completed, primarily for audit/debugging."""

    INTAKE = "intake_and_classify"
    RESOLVE_ENTITY = "resolve_entity"
    POLICY_CHECK = "check_policy_and_tool_eligibility"
    RETRIEVE_CONTEXT = "retrieve_primary_context"
    ENRICH_MCP = "enrich_with_mcp_tools"
    SCORE_ROOT_CAUSE = "score_root_cause_candidates"
    GENERATE_EXPLANATION = "generate_user_explanation"
    REQUEST_APPROVAL = "request_approval_if_needed"
    EXECUTE_ACTION = "execute_approved_action_if_any"
    PERSIST_AUDIT = "persist_audit_record"
    FAILED = "failed"
    COMPLETE = "complete"


class WorkflowState(BaseModel):
    """Shared mutable state passed between all workflow nodes.

    Fields are grouped by the node that primarily populates them, in
    pipeline order. Every field after `request` is Optional because it does
    not exist until its producing node has run -- nodes must defensively
    check for None on any upstream field they depend on and route to an
    error/clarification path rather than assume presence.
    """

    # --- intake_and_classify ---
    request: UserRequest
    use_case_name: Optional[str] = None
    entity_hint: Optional[str] = None

    # --- resolve_entity ---
    resolved_entity: Optional[ResolvedEntity] = None

    # --- check_policy_and_tool_eligibility ---
    policy_decision: Optional[PolicyDecision] = None

    # --- retrieve_primary_context / enrich_with_mcp_tools ---
    context_pack: Optional[ContextPack] = None
    tool_invocations: list[ToolInvocation] = Field(default_factory=list)

    # --- score_root_cause_candidates ---
    root_cause_candidates: list[RootCauseCandidate] = Field(default_factory=list)

    # --- generate_user_explanation ---
    user_explanation: Optional[str] = None

    # --- request_approval_if_needed ---
    proposed_action: Optional[ActionPlan] = None
    approval_request: Optional[ApprovalRequest] = None

    # --- execute_approved_action_if_any ---
    action_executed: bool = False
    action_outcome: Optional[str] = None

    # --- control / bookkeeping (read and written across most nodes) ---
    current_stage: str = "intake_and_classify"
    requires_clarification: bool = False
    clarification_message: Optional[str] = None
    errors: list[str] = Field(default_factory=list)
    fallback_paths_taken: list[str] = Field(default_factory=list)
    started_ts: datetime = Field(default_factory=datetime.utcnow)
    completed_ts: Optional[datetime] = None

    # Escape hatch for node-specific scratch data that doesn't warrant a
    # first-class field yet. Nodes should migrate frequently-used keys here
    # into named fields during review rather than letting this grow unbounded.
    scratch: dict[str, Any] = Field(default_factory=dict)

    class Config:
        arbitrary_types_allowed = True

    def add_error(self, message: str) -> None:
        """Append an error without raising; nodes use this plus their own
        return value to signal a soft-fail that still allows
        persist_audit_record to run."""
        self.errors.append(message)

    def mark_stage(self, stage: "WorkflowStage") -> None:
        """Update current_stage using the WorkflowStage enum value."""
        self.current_stage = stage.value
