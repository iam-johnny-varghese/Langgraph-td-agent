"""
ops_copilot_graph.py

Wires the 10 workflow nodes (app/workflows/nodes/*.py) into a single
runnable sequence over WorkflowState.

Orchestration style chosen: a plain Python function (`run_workflow`) that
calls each node's `run()` in fixed order, threading the same WorkflowState
instance through via in-place mutation, rather than a full LangGraph
StateGraph object. This keeps the scaffold runnable without a hard
dependency on the `langgraph` package while preserving the same node
boundaries, state shape, and error-handling contracts a LangGraph
StateGraph would have.

TODO (LangGraph migration path): if/when migrating to an actual
`langgraph.graph.StateGraph`, each node's `run(state, **deps)` function can
be wrapped almost as-is as a graph node function (LangGraph nodes are also
just `state -> state` callables). The main changes needed would be:
  1. Define conditional edges for requires_clarification short-circuiting
     (currently each node just checks the flag itself and no-ops rather
     than the graph skipping the node entirely -- functionally equivalent
     but LangGraph's conditional-edge mechanism would make the skip
     explicit in the graph definition rather than implicit in node logic).
  2. Replace the dependency-injection parameters below (repos, mcp_client,
     audit_repo) with a LangGraph-style config/context object or a
     dependency-injection wrapper, since LangGraph node functions typically
     take only `state` (and optionally `config`).
  3. Add LangGraph's built-in retry/checkpoint features if persistence
     across process restarts mid-workflow becomes a requirement (not
     needed for this scaffold's synchronous request/response shape).

This module does NOT itself construct repository/MCP client instances --
those are expected to be created and injected by the API layer
(app/api/routes.py) or a small composition-root function in
app/main.py, per "use dependency injection where helpful."
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Optional

from app.models.domain import UserRequest
from app.models.policy import AgentToolRegistryEntry
from app.models.workflow import WorkflowStage, WorkflowState
from app.repositories.audit_repo import AuditRepo
from app.repositories.teradata_context_repo import TeradataContextRepo
from app.repositories.teradata_ops_repo import TeradataOpsRepo
from app.repositories.teradata_security_repo import TeradataSecurityRepo
from app.workflows.nodes import (
    audit_result,
    enrich_with_mcp,
    execute_action,
    generate_response,
    intake,
    policy_check,
    request_approval,
    resolve_entity,
    retrieve_context,
    score_root_cause,
)

logger = logging.getLogger(__name__)


@dataclass
class WorkflowDependencies:
    """Bundles every external dependency the graph's nodes need.

    Constructed once per process (or per request, depending on connection
    lifecycle preferences) by the API layer / composition root, then
    passed into run_workflow. Bundling into a single dataclass keeps
    run_workflow's signature stable as new nodes acquire new dependencies,
    rather than run_workflow accumulating an ever-growing parameter list.
    """

    context_repo: TeradataContextRepo
    ops_repo: TeradataOpsRepo
    security_repo: TeradataSecurityRepo
    audit_repo: AuditRepo
    tool_registry_entries: list[AgentToolRegistryEntry]
    mcp_client: Optional[Any] = None  # TODO: tighten to mcp.client.MCPClient once Phase 4 lands


# Each entry: (WorkflowStage this step is associated with, callable).
# Kept as an explicit ordered list (rather than e.g. a dict keyed by stage)
# so the literal sequence in the spec's WORKFLOW REQUIREMENTS section is
# visually obvious here and in code review.
_NODE_SEQUENCE = [
    WorkflowStage.INTAKE,
    WorkflowStage.RESOLVE_ENTITY,
    WorkflowStage.POLICY_CHECK,
    WorkflowStage.RETRIEVE_CONTEXT,
    WorkflowStage.ENRICH_MCP,
    WorkflowStage.SCORE_ROOT_CAUSE,
    WorkflowStage.GENERATE_EXPLANATION,
    WorkflowStage.REQUEST_APPROVAL,
    WorkflowStage.EXECUTE_ACTION,
    WorkflowStage.PERSIST_AUDIT,
]


def run_workflow(request: UserRequest, deps: WorkflowDependencies) -> WorkflowState:
    """Run the full 10-node Ops Copilot workflow for a single UserRequest.

    This function always returns a WorkflowState (never raises) --
    persist_audit_record (the final node) is designed to run even on a
    failure path, so by the time this function returns, an audit attempt
    has always been made. Callers (e.g. api/routes.py) should inspect
    state.current_stage and state.errors to determine the outcome, not
    rely on exception handling here.
    """
    state = WorkflowState(request=request)

    try:
        state = intake.run(state)
        if state.current_stage == WorkflowStage.FAILED.value:
            return _finalize_with_audit(state, deps)

        state = resolve_entity.run(state, context_repo=deps.context_repo)

        state = policy_check.run(
            state,
            tool_registry_entries=deps.tool_registry_entries,
            security_repo=deps.security_repo,
        )

        state = retrieve_context.run(
            state, context_repo=deps.context_repo, ops_repo=deps.ops_repo
        )

        state = enrich_with_mcp.run(state, mcp_client=deps.mcp_client)

        state = score_root_cause.run(state)

        state = generate_response.run(state)

        state = request_approval.run(state)

        state = execute_action.run(state)

        return _finalize_with_audit(state, deps)

    except Exception as exc:  # noqa: BLE001 -- absolute last-resort safety net
        # No individual node in this graph is expected to raise (each has
        # its own internal try/except per its docstring's "Error handling"
        # section), so reaching this branch indicates a bug in the graph
        # wiring itself, not normal node-level failure handling. Still,
        # the workflow must not crash its caller -- record and finalize.
        logger.exception(
            "run_workflow: unexpected error outside node-level handling for request_id=%s",
            request.request_id,
        )
        state.add_error(f"run_workflow unexpected error: {exc}")
        state.mark_stage(WorkflowStage.FAILED)
        return _finalize_with_audit(state, deps)


def _finalize_with_audit(state: WorkflowState, deps: WorkflowDependencies) -> WorkflowState:
    """Always run persist_audit_record as the true last step, whether the
    workflow reached EXECUTE_ACTION normally or failed earlier."""
    return audit_result.run(state, audit_repo=deps.audit_repo)
