"""
Node 4: retrieve_primary_context

Reads:
    state.resolved_entity  (Optional[ResolvedEntity])
    state.policy_decision  (Optional[PolicyDecision]) -- consulted only to
                            decide whether it's worth retrieving context at
                            all (BLOCKED + no clarification need => still
                            retrieve, since diagnostic context is useful
                            even when no action is possible) -- this node
                            does NOT gate on policy_decision.status, only
                            enrich_with_mcp_tools does.

Writes:
    state.context_pack     (ContextPack)
    state.current_stage    -> WorkflowStage.ENRICH_MCP

Error handling:
    This node retrieves from FOUR independent sources (data product,
    pipeline health, dependencies, workload signals where applicable).
    Each source is wrapped in its own try/except so a single source's
    failure (e.g. dependency chain query times out) does not blank out the
    entire ContextPack -- it is recorded in missing_data_flags instead and
    the remaining sources are still attempted. This node only hard-fails
    (routes to FAILED) if resolved_entity is missing AND
    requires_clarification was somehow not set upstream (a defensive
    check; should be unreachable given resolve_entity's contract).

Missing data behavior:
    If resolved_entity.clarification_required is True, this node still
    attempts a best-effort context retrieval using any candidates present
    (e.g. the top candidate, clearly marked as tentative) ONLY for display
    purposes in a clarification prompt -- it does NOT treat that candidate
    as confirmed. If no canonical_id is available at all (zero candidates),
    an empty ContextPack is returned with missing_data_flags noting why.

Deterministic output:
    No LLM calls in this node. All data comes from repository methods
    that return typed Pydantic models directly.
"""

from __future__ import annotations

import logging
from typing import Optional

from app.models.domain import ContextPack, DataProductSummary, ResolvedEntity
from app.models.workflow import WorkflowStage, WorkflowState
from app.repositories.teradata_context_repo import TeradataContextRepo
from app.repositories.teradata_ops_repo import TeradataOpsRepo

logger = logging.getLogger(__name__)

# Depth bound for dependency chain retrieval at this stage. Kept shallow
# here since this is "primary" context for an initial explanation, not a
# full blast-radius analysis -- score_root_cause_candidates or a follow-up
# question can request a deeper chain via enrich_with_mcp_tools / a
# dedicated tool if needed.
# TODO: confirm 3 is the right default depth for typical finance-dashboard-
# style dependency graphs; make configurable via core/config.py if not.
_DEFAULT_DEPENDENCY_DEPTH = 3


def _resolve_target_id(entity: Optional[ResolvedEntity]) -> Optional[str]:
    """Pick the canonical_id to retrieve context for, including the
    best-effort tentative case (clarification_required=True but a top
    candidate exists)."""
    if entity is None:
        return None
    if entity.canonical_id:
        return entity.canonical_id
    if entity.candidates:
        return entity.candidates[0].canonical_id
    return None


def run(
    state: WorkflowState,
    context_repo: TeradataContextRepo,
    ops_repo: TeradataOpsRepo,
) -> WorkflowState:
    """Execute the retrieve_primary_context node."""
    entity = state.resolved_entity
    target_id = _resolve_target_id(entity)

    if target_id is None:
        # No resolvable entity at all -- not a hard failure (resolve_entity
        # already flagged clarification_required upstream); just produce an
        # empty pack so generate_user_explanation has something to read.
        state.context_pack = ContextPack(
            primary_entity=entity or ResolvedEntity(clarification_required=True),
            missing_data_flags=["no_resolvable_entity_id"],
        )
        state.mark_stage(WorkflowStage.ENRICH_MCP)
        return state

    missing_flags: list[str] = []
    data_product: Optional[DataProductSummary] = None
    pipeline_health = []
    dependencies = []

    try:
        data_product = context_repo.get_data_product(target_id)
        if data_product is None:
            missing_flags.append("no_data_product_catalog_row_found")
    except Exception as exc:  # noqa: BLE001
        logger.exception("retrieve_primary_context: get_data_product failed for %s", target_id)
        missing_flags.append("data_product_lookup_error")
        state.add_error(f"retrieve_primary_context.get_data_product failed: {exc}")

    try:
        pipeline_health = ops_repo.get_latest_pipeline_status(data_product_id=target_id)
        if not pipeline_health:
            missing_flags.append("no_pipeline_health_rows_found")
    except Exception as exc:  # noqa: BLE001
        logger.exception(
            "retrieve_primary_context: get_latest_pipeline_status failed for %s", target_id
        )
        missing_flags.append("pipeline_health_lookup_error")
        state.add_error(f"retrieve_primary_context.get_latest_pipeline_status failed: {exc}")

    try:
        dependencies = context_repo.get_dependency_chain(
            target_id, max_depth=_DEFAULT_DEPENDENCY_DEPTH
        )
        if not dependencies:
            missing_flags.append("no_dependency_edges_found")
    except Exception as exc:  # noqa: BLE001
        logger.exception("retrieve_primary_context: get_dependency_chain failed for %s", target_id)
        missing_flags.append("dependency_chain_lookup_error")
        state.add_error(f"retrieve_primary_context.get_dependency_chain failed: {exc}")

    # workload_signals intentionally left empty here -- workload_id is not
    # the same identifier space as data_product_id/pipeline_id, and this
    # node has no reliable mapping from a resolved data-product entity to a
    # TASM/TIWM workload_id yet.
    # TODO: once a workload_id <-> data_product_id/pipeline_id mapping
    # exists (likely via a join through context.workload_signal.
    # related_data_product_id), populate workload_signals here for
    # workload_analysis use cases rather than leaving it for
    # score_root_cause_candidates to fetch on demand.

    state.context_pack = ContextPack(
        primary_entity=entity,
        data_product=data_product,
        pipeline_health=pipeline_health,
        dependencies=dependencies,
        workload_signals=[],
        missing_data_flags=missing_flags,
    )
    state.mark_stage(WorkflowStage.ENRICH_MCP)
    return state
