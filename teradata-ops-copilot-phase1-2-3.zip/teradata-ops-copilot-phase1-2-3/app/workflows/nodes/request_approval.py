"""
Node 8: request_approval_if_needed

Reads:
    state.policy_decision         (PolicyDecision)
    state.root_cause_candidates    (list[RootCauseCandidate])
    state.requires_clarification   (bool) -- if True, no action is proposed
                                    at all; this node short-circuits.
    state.resolved_entity          (ResolvedEntity) -- for target_object

Writes:
    state.proposed_action     (Optional[ActionPlan])
    state.approval_request    (Optional[ApprovalRequest])
    state.current_stage       -> WorkflowStage.EXECUTE_ACTION

Error handling:
    This node NEVER executes an action -- per spec: "Do not perform the
    action here." It only constructs ActionPlan / ApprovalRequest objects.
    Any error in deriving an action proposal (e.g. an unmapped root-cause
    category) results in proposed_action=None rather than a guessed
    action, and the workflow simply proceeds with no action recommended.

Missing data behavior:
    - If requires_clarification is True, or no root_cause_candidates exist,
      or the top candidate's confidence is below _MIN_ACTION_CONFIDENCE:
      no action is proposed at all (proposed_action=None,
      approval_request=None). This node does not propose a low-confidence
      action just to have something to suggest.
    - If an action IS proposed but policy_decision.status is BLOCKED:
      the ActionPlan is still recorded (for audit/explanation purposes --
      "here's what I'd suggest, but it's blocked") but NO ApprovalRequest
      is created, since approval is moot when the action is blocked
      outright.

Approval matrix (per spec):
    requires_approval=True : rerun_pipeline, grant_or_revoke_access,
                              run_admin_macro / execute_macro,
                              execute_fix_script
    requires_approval=False: notify_owner, create_incident_summary,
                              gather_additional_diagnostics
    This matrix is centralized in _ACTIONS_REQUIRING_APPROVAL below rather
    than left to each ActionPlan's requires_approval field on construction,
    so the policy is auditable in one place and not dependent on every
    caller setting the flag correctly themselves.
"""

from __future__ import annotations

import logging
import uuid

from app.models.domain import (
    ActionPlan,
    ActionType,
    ApprovalRequest,
    ApprovalStatus,
    PolicyDecisionStatus,
    RootCauseCandidate,
    RootCauseCategory,
)
from app.models.workflow import WorkflowStage, WorkflowState

logger = logging.getLogger(__name__)

# Centralized approval matrix -- see module docstring.
_ACTIONS_REQUIRING_APPROVAL: set[ActionType] = {
    ActionType.RERUN_PIPELINE,
    ActionType.GRANT_OR_REVOKE_ACCESS,
    ActionType.EXECUTE_MACRO,
}
# NOTE: spec also lists 'run_admin_macro' and 'execute_fix_script' as
# requiring approval. ActionType (models/domain.py) currently has
# EXECUTE_MACRO covering 'run admin macro' semantics; a distinct
# EXECUTE_FIX_SCRIPT value does not yet exist in ActionType.
# TODO: add ActionType.EXECUTE_FIX_SCRIPT to models/domain.py if rerun vs.
# fix-script vs. admin-macro need to be tracked as genuinely distinct
# action types rather than collapsed into EXECUTE_MACRO. Flagging here
# rather than silently conflating them.

# Below this confidence, do not propose an action at all -- propose
# gathering more diagnostics instead, which is itself a safe (no-approval)
# action.
_MIN_ACTION_CONFIDENCE = 0.6

# Maps root cause category -> the action this node would propose.
# TODO: this is a simple 1:1 mapping; real remediation logic will likely
# need additional inputs (e.g. "has this pipeline already been retried
# twice today") before proposing rerun_pipeline. Left as the practical
# default per spec's "choose practical defaults" guidance.
_CATEGORY_TO_ACTION: dict[RootCauseCategory, ActionType] = {
    RootCauseCategory.FAILED_ETL_JOB: ActionType.RERUN_PIPELINE,
    RootCauseCategory.UPSTREAM_DATA_DELAY: ActionType.NOTIFY_OWNER,
    RootCauseCategory.WORKLOAD_SATURATION: ActionType.CREATE_TICKET,
    RootCauseCategory.SECURITY_REGRESSION: ActionType.INVESTIGATE_PERMISSIONS,
    RootCauseCategory.SCHEMA_DRIFT: ActionType.CREATE_TICKET,
    RootCauseCategory.DASHBOARD_REFRESH_FAILURE: ActionType.CREATE_TICKET,
    RootCauseCategory.UNKNOWN: ActionType.GATHER_ADDITIONAL_DIAGNOSTICS,
}


def _derive_action_plan(
    top_candidate: RootCauseCandidate, target_object: str
) -> ActionPlan:
    action_type = _CATEGORY_TO_ACTION.get(
        top_candidate.category, ActionType.GATHER_ADDITIONAL_DIAGNOSTICS
    )
    requires_approval = action_type in _ACTIONS_REQUIRING_APPROVAL
    return ActionPlan(
        action_type=action_type,
        target_object=target_object,
        payload={"root_cause_category": top_candidate.category.value},
        rationale=top_candidate.evidence_summary,
        requires_approval=requires_approval,
    )


def run(state: WorkflowState) -> WorkflowState:
    """Execute the request_approval_if_needed node."""
    if state.requires_clarification:
        state.proposed_action = None
        state.approval_request = None
        state.mark_stage(WorkflowStage.EXECUTE_ACTION)
        return state

    candidates = state.root_cause_candidates
    entity = state.resolved_entity

    if not candidates or not entity or not entity.canonical_id:
        state.proposed_action = None
        state.approval_request = None
        state.mark_stage(WorkflowStage.EXECUTE_ACTION)
        return state

    top = candidates[0]
    if top.confidence < _MIN_ACTION_CONFIDENCE:
        # Low confidence -- propose gathering more diagnostics, which is a
        # safe action and itself does not require approval.
        plan = ActionPlan(
            action_type=ActionType.GATHER_ADDITIONAL_DIAGNOSTICS,
            target_object=entity.canonical_id,
            payload={"reason": "top_root_cause_confidence_below_threshold"},
            rationale=(
                f"Top candidate ({top.category.value}) confidence "
                f"{top.confidence:.2f} is below the action threshold "
                f"({_MIN_ACTION_CONFIDENCE})."
            ),
            requires_approval=False,
        )
        state.proposed_action = plan
        state.approval_request = None
        state.mark_stage(WorkflowStage.EXECUTE_ACTION)
        return state

    plan = _derive_action_plan(top, entity.canonical_id)
    state.proposed_action = plan

    policy = state.policy_decision
    if policy is not None and policy.status == PolicyDecisionStatus.BLOCKED:
        # Record the plan for visibility but do not create an approval
        # request -- approval is moot when execution is blocked outright.
        state.approval_request = None
        state.fallback_paths_taken.append("action_proposed_but_policy_blocked")
        state.mark_stage(WorkflowStage.EXECUTE_ACTION)
        return state

    if plan.requires_approval:
        state.approval_request = ApprovalRequest(
            approval_id=str(uuid.uuid4()),
            requested_by=state.request.requesting_user,
            action_type=plan.action_type,
            target_object=plan.target_object,
            requested_payload=plan.payload,
            status=ApprovalStatus.PENDING,
        )
    else:
        # Safe action -- no approval needed, but we still record a
        # NOT_REQUIRED approval status for audit consistency (every
        # proposed action gets a determinable approval_status downstream).
        state.approval_request = ApprovalRequest(
            approval_id=str(uuid.uuid4()),
            requested_by=state.request.requesting_user,
            action_type=plan.action_type,
            target_object=plan.target_object,
            requested_payload=plan.payload,
            status=ApprovalStatus.NOT_REQUIRED,
        )

    state.mark_stage(WorkflowStage.EXECUTE_ACTION)
    return state
