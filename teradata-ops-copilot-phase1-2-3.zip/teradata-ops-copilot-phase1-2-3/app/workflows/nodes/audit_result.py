"""
Node 10: persist_audit_record

Reads:
    Nearly all of WorkflowState -- this is the terminal node that
    summarizes the entire run into an AuditRecord.

Writes:
    state.completed_ts    (datetime)
    state.current_stage   -> WorkflowStage.COMPLETE (or remains FAILED if
                              it was already FAILED on entry -- this node
                              does not clear a prior FAILED stage, it just
                              also ensures an audit row gets written)

Error handling:
    This is the LAST node in the graph and must run regardless of whether
    earlier nodes recorded errors -- a failed workflow still needs an
    audit trail explaining what was attempted and what went wrong. This
    node's own failure mode (the audit_repo write itself failing) is
    logged but deliberately does NOT raise back into the graph caller,
    since by this point there is no further node to route to; ops_copilot_graph.py
    (the graph driver) is responsible for surfacing this as a
    distinct "audit_write_failed" condition to its own caller (e.g. the
    API layer) if it wants to alert on it, separate from the workflow's
    own success/failure.

Missing data behavior:
    Every AuditRecord field has a defined fallback when the corresponding
    WorkflowState field is None/empty (see _build_audit_record), so this
    node never raises a validation error when constructing the
    AuditRecord even for a workflow that failed very early (e.g. before
    use_case_name was even set).

Replay hook (TODO):
    Per the spec's "Add hooks for future replay and evaluation" --
    this node currently persists only the AuditRecord (audit.py), not a
    full WorkflowState snapshot. TODO: if/when replay support is built,
    serialize state.model_dump(mode="json") into a separate object
    store/blob column keyed by request_id, called from this node
    immediately before or after the AuditRecord insert.
"""

from __future__ import annotations

import logging
from datetime import datetime

from app.models.audit import AuditRecord, RootCauseAuditEntry, ToolInvocationAuditEntry
from app.models.workflow import WorkflowStage, WorkflowState
from app.repositories.audit_repo import AuditRepo

logger = logging.getLogger(__name__)


def _build_audit_record(state: WorkflowState) -> AuditRecord:
    """Construct an AuditRecord from the final WorkflowState.

    Every field has an explicit fallback so this never raises on a
    partially-populated state (e.g. a workflow that failed at intake).
    """
    completed_ts = state.completed_ts or datetime.utcnow()
    elapsed_ms = None
    if state.started_ts:
        elapsed_ms = (completed_ts - state.started_ts).total_seconds() * 1000

    tool_sequence = [
        ToolInvocationAuditEntry(
            tool_name=inv.tool_name,
            category=inv.category,
            status=inv.status,
            latency_ms=inv.latency_ms,
            invoked_ts=inv.invoked_ts,
        )
        for inv in state.tool_invocations
    ]

    top_root_causes = [
        RootCauseAuditEntry(category=c.category, confidence=c.confidence)
        for c in state.root_cause_candidates[:5]  # cap to top 5 for audit row size
    ]

    return AuditRecord(
        request_id=state.request.request_id,
        user_name=state.request.requesting_user,
        use_case_name=state.use_case_name or "unknown",
        resolved_entity_id=(state.resolved_entity.canonical_id if state.resolved_entity else None),
        resolved_entity_type=(
            state.resolved_entity.entity_type.value if state.resolved_entity else None
        ),
        clarification_required=state.requires_clarification,
        policy_decision_status=(state.policy_decision.status if state.policy_decision else None),
        policy_reason=(state.policy_decision.policy_reason if state.policy_decision else None),
        tool_sequence=tool_sequence,
        top_root_causes=top_root_causes,
        action_recommended=(state.proposed_action.action_type if state.proposed_action else None),
        approval_status=(state.approval_request.status if state.approval_request else None),
        action_outcome=state.action_outcome,
        started_ts=state.started_ts,
        completed_ts=completed_ts,
        elapsed_ms=elapsed_ms,
        errors=list(state.errors),
        fallback_paths_taken=list(state.fallback_paths_taken),
        extra={},
    )


def run(state: WorkflowState, audit_repo: AuditRepo) -> WorkflowState:
    """Execute the persist_audit_record node -- the final node in the graph."""
    state.completed_ts = state.completed_ts or datetime.utcnow()

    try:
        record = _build_audit_record(state)
    except Exception as exc:  # noqa: BLE001 -- must not prevent stage finalization
        logger.exception(
            "persist_audit_record: failed to BUILD audit record for request_id=%s",
            state.request.request_id,
        )
        state.add_error(f"persist_audit_record build_audit_record failed: {exc}")
        if state.current_stage != WorkflowStage.FAILED.value:
            state.mark_stage(WorkflowStage.COMPLETE)
        return state

    try:
        audit_repo.insert_audit_record(record)
    except Exception as exc:  # noqa: BLE001 -- do not crash the graph on audit-write failure
        logger.exception(
            "persist_audit_record: failed to WRITE audit record for request_id=%s",
            state.request.request_id,
        )
        state.add_error(f"persist_audit_record insert_audit_record failed: {exc}")
        state.fallback_paths_taken.append("audit_write_failed")
        # Deliberately still mark COMPLETE (unless already FAILED) -- the
        # workflow's own outcome is independent of whether we successfully
        # logged it. The graph driver (ops_copilot_graph.py) should inspect
        # 'audit_write_failed' in fallback_paths_taken if it wants to alert
        # on this specifically.

    if state.current_stage != WorkflowStage.FAILED.value:
        state.mark_stage(WorkflowStage.COMPLETE)
    return state
