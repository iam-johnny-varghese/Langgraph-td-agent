"""
Node 1: intake_and_classify

Reads:
    state.request (UserRequest) -- the only field guaranteed populated on
    entry to this node, since it's the workflow's starting input.

Writes:
    state.use_case_name        (str)  -- one of UseCaseName values
    state.entity_hint           (Optional[str]) -- extracted entity text,
                                 or None if nothing usable was found
    state.current_stage         -> WorkflowStage.RESOLVE_ENTITY (on success)
                                    or WorkflowStage.FAILED (on hard failure)

Error handling:
    This node should never raise. Classification ambiguity is not an
    error -- it is recorded as use_case_name = UseCaseName.UNKNOWN and the
    graph routes to a clarification/fallback path further downstream
    (resolve_entity / generate_user_explanation), not here. Only a missing
    or unparseable request.raw_text (already validated non-empty by the
    UserRequest model itself) would be a hard failure, and that case is
    unreachable given Pydantic validation already ran at construction time.

Missing data behavior:
    If no entity hint can be extracted at all (e.g. a pure greeting or
    out-of-scope question), entity_hint is left None. This node does NOT
    guess or fabricate an entity hint just to populate the field -- per the
    spec's "extract entity hints without over-inference" requirement,
    resolve_entity must be able to detect "no hint provided" as a distinct
    case from "hint provided but unresolvable".

Deterministic output:
    Classification logic here is intentionally rule/keyword-based first
    (TODO: see classify_use_case), with an LLM-based classifier as an
    optional enhancement -- not a requirement -- so that node behavior
    stays deterministic and testable without a live LLM call in the
    critical path.
"""

from __future__ import annotations

import logging
import re

from app.models.domain import UseCaseName
from app.models.workflow import WorkflowStage, WorkflowState

logger = logging.getLogger(__name__)


# Keyword heuristics used by classify_use_case. Kept as simple substring
# matches (case-insensitive) rather than regex/NLP for transparency and
# easy unit testing -- see tests/test_workflow_diagnosis.py.
#
# TODO: tune/expand these keyword sets against real historical request
# logs once available. Order matters: first matching use case wins, so
# more specific use cases are listed before more general ones.
_USE_CASE_KEYWORDS: dict[UseCaseName, list[str]] = {
    UseCaseName.REMEDIATION_REQUEST: [
        "rerun", "re-run", "retry", "fix", "remediate", "prepare a rerun",
    ],
    UseCaseName.ACCESS_REVIEW: [
        "still have access", "elevated access", "permission", "access to",
        "revoke", "grant",
    ],
    UseCaseName.SECURITY_AUDIT: [
        "security", "audit", "unauthorized", "role review", "who can access",
    ],
    UseCaseName.WORKLOAD_ANALYSIS: [
        "spool", "workload", "cpu", "skew", "blocked session", "saturation",
    ],
    UseCaseName.PIPELINE_INCIDENT_DIAGNOSIS: [
        "sla", "failed", "pipeline", "missed", "didn't run", "did not run",
        "dashboard", "job failed",
    ],
}

# Very lightweight entity-hint extraction: quoted phrases, or capitalized
# multi-word spans, or text following common trigger phrases. This is
# intentionally conservative -- it is better to return None than to guess
# wrong and have resolve_entity silently chase the wrong entity.
#
# TODO: replace/augment with a proper NER pass or LLM-based extraction if
# this proves too brittle for real phrasing variety. Keep the "do not
# over-infer" contract regardless of implementation.
_QUOTED_PHRASE_RE = re.compile(r"[\"']([^\"']{2,80})[\"']")
_TRIGGER_PHRASE_RE = re.compile(
    r"(?:for|of|on)\s+(?:the\s+)?([A-Za-z][A-Za-z0-9 _\-]{2,60}?)(?:\s+(?:pipeline|dashboard|job|feed|workload))?(?:[.?!]|$)",
    re.IGNORECASE,
)


def classify_use_case(raw_text: str) -> UseCaseName:
    """Classify request text into a UseCaseName using keyword heuristics.

    Returns UseCaseName.UNKNOWN if no keyword set matches -- callers must
    treat UNKNOWN as a legitimate outcome requiring graceful handling
    downstream, not as an error.
    """
    lowered = raw_text.lower()
    for use_case, keywords in _USE_CASE_KEYWORDS.items():
        if any(kw in lowered for kw in keywords):
            return use_case
    return UseCaseName.UNKNOWN


def extract_entity_hint(raw_text: str) -> str | None:
    """Best-effort, conservative extraction of an entity-referring text span.

    Tries, in order:
        1. A quoted phrase (highest confidence the user meant this exact span).
        2. Text following a trigger phrase like "for the X pipeline".
    Returns None if neither pattern matches -- this node does not fall back
    to "just grab the longest noun phrase" or similar guesswork.
    """
    quoted = _QUOTED_PHRASE_RE.search(raw_text)
    if quoted:
        return quoted.group(1).strip()

    triggered = _TRIGGER_PHRASE_RE.search(raw_text)
    if triggered:
        return triggered.group(1).strip()

    return None


def run(state: WorkflowState) -> WorkflowState:
    """Execute the intake_and_classify node.

    This function is the node's entry point as wired into
    ops_copilot_graph.py. It mutates and returns the same WorkflowState
    instance (in-place mutation, matching the orchestration style chosen
    in ops_copilot_graph.py -- see TODO there if a copy-on-write style is
    preferred instead).
    """
    try:
        use_case = classify_use_case(state.request.raw_text)
        hint = extract_entity_hint(state.request.raw_text)

        state.use_case_name = use_case.value
        state.entity_hint = hint

        if use_case is UseCaseName.UNKNOWN:
            # Not a hard failure -- record it for downstream nodes/audit so
            # the explanation step can tell the user their request type
            # wasn't recognized rather than silently proceeding.
            state.fallback_paths_taken.append("use_case_classification_unknown")
            logger.info(
                "intake_and_classify: could not classify request_id=%s into a known use case",
                state.request.request_id,
            )

        if hint is None:
            logger.info(
                "intake_and_classify: no entity hint extracted for request_id=%s",
                state.request.request_id,
            )

        state.mark_stage(WorkflowStage.RESOLVE_ENTITY)
        return state

    except Exception as exc:  # noqa: BLE001 -- top-level node boundary
        # Defensive catch-all: this node's own logic should never raise
        # given the heuristics above are pure string operations, but any
        # workflow node boundary should fail soft into FAILED rather than
        # propagate an unhandled exception out of the graph.
        logger.exception(
            "intake_and_classify: unexpected error for request_id=%s", state.request.request_id
        )
        state.add_error(f"intake_and_classify failed: {exc}")
        state.mark_stage(WorkflowStage.FAILED)
        return state
