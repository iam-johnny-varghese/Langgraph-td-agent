"""
Node 2: resolve_entity

Reads:
    state.entity_hint   (Optional[str]) -- from intake_and_classify
    state.use_case_name  (Optional[str]) -- informational only; this node
                          does not branch logic on use case today

Writes:
    state.resolved_entity         (ResolvedEntity)
    state.requires_clarification  (bool) -- mirrors resolved_entity.clarification_required
    state.clarification_message   (Optional[str]) -- set when clarification is required
    state.current_stage           -> WorkflowStage.POLICY_CHECK (always advances;
                                      clarification_required does not halt the
                                      graph, it changes how generate_user_explanation
                                      and request_approval_if_needed behave)

Error handling:
    Repository errors (e.g. connection failure) are caught and converted
    into a ResolvedEntity with clarification_required=True and a
    clarification_reason explaining the lookup failed, rather than
    propagating -- a downstream service outage should degrade to "ask the
    user" rather than crash the whole workflow.

Missing data behavior:
    - entity_hint is None: resolved_entity is set to an empty/unknown
      ResolvedEntity with clarification_required=True. This node does NOT
      ask the alias repo to search for an empty string (the repo itself
      would raise ValueError on that -- see teradata_context_repo.py).
    - entity_hint produces zero candidates: clarification_required=True,
      reason='no_matching_entity'.
    - entity_hint produces multiple candidates with comparable top
      confidence (within _AMBIGUITY_MARGIN of each other): clarification_required=True,
      reason='ambiguous_candidates'. This node does NOT guess by picking
      the highest-confidence candidate when candidates are close -- per
      spec: "Do not guess when multiple candidates exist."
    - entity_hint produces exactly one clear top candidate (confidence
      above _MIN_AUTO_RESOLVE_CONFIDENCE and not ambiguous): resolved
      automatically, clarification_required=False.

Deterministic output:
    Thresholds (_MIN_AUTO_RESOLVE_CONFIDENCE, _AMBIGUITY_MARGIN) are module
    constants so resolution behavior is reproducible and unit-testable
    without depending on any LLM call.
"""

from __future__ import annotations

import logging

from app.models.domain import ResolvedEntity
from app.models.workflow import WorkflowStage, WorkflowState
from app.repositories.teradata_context_repo import TeradataContextRepo

logger = logging.getLogger(__name__)

# A candidate must clear this confidence bar to be auto-resolved at all.
# TODO: tune against real alias data; 0.85 is a practical starting default.
_MIN_AUTO_RESOLVE_CONFIDENCE = 0.85

# If the top two candidates' confidence scores are within this margin of
# each other, treat the match as ambiguous rather than auto-resolving to
# the top candidate. Guards against "two products with very similar alias
# text" silently resolving to the wrong one.
_AMBIGUITY_MARGIN = 0.05


def run(state: WorkflowState, context_repo: TeradataContextRepo) -> WorkflowState:
    """Execute the resolve_entity node.

    Args:
        state: shared workflow state.
        context_repo: injected repository for alias/catalog lookups.
            TODO: once a DI container or FastAPI dependency wiring is
            settled in app/core/, this explicit parameter may be replaced
            by a constructor-injected service object
            (services/entity_resolver.py) that wraps this repo call plus
            the thresholding logic below. Keeping the logic directly in
            the node for now per "explicit over clever".
    """
    hint = state.entity_hint

    if not hint:
        state.resolved_entity = ResolvedEntity(
            clarification_required=True,
            clarification_reason="no_entity_hint_extracted",
            raw_entity_hint=None,
        )
        state.requires_clarification = True
        state.clarification_message = (
            "I couldn't identify which data product, pipeline, or workload you're "
            "asking about. Could you tell me its name?"
        )
        state.mark_stage(WorkflowStage.POLICY_CHECK)
        return state

    try:
        candidates = context_repo.get_alias_matches(hint)
    except Exception as exc:  # noqa: BLE001 -- repo/connection failure
        logger.exception("resolve_entity: alias lookup failed for hint=%r", hint)
        state.add_error(f"resolve_entity alias lookup failed: {exc}")
        state.fallback_paths_taken.append("alias_lookup_failed_fallback_to_clarification")
        state.resolved_entity = ResolvedEntity(
            clarification_required=True,
            clarification_reason="alias_lookup_error",
            raw_entity_hint=hint,
        )
        state.requires_clarification = True
        state.clarification_message = (
            "I ran into a problem looking that up. Could you confirm the exact "
            "name of the data product or pipeline you mean?"
        )
        state.mark_stage(WorkflowStage.POLICY_CHECK)
        return state

    if not candidates:
        state.resolved_entity = ResolvedEntity(
            candidates=[],
            clarification_required=True,
            clarification_reason="no_matching_entity",
            raw_entity_hint=hint,
        )
        state.requires_clarification = True
        state.clarification_message = (
            f"I couldn't find anything matching \"{hint}\". Could you double-check "
            "the name?"
        )
        state.mark_stage(WorkflowStage.POLICY_CHECK)
        return state

    candidates_sorted = sorted(candidates, key=lambda c: c.confidence, reverse=True)
    top = candidates_sorted[0]
    is_ambiguous = (
        len(candidates_sorted) > 1
        and (top.confidence - candidates_sorted[1].confidence) < _AMBIGUITY_MARGIN
    )

    if is_ambiguous or top.confidence < _MIN_AUTO_RESOLVE_CONFIDENCE:
        reason = "ambiguous_candidates" if is_ambiguous else "low_confidence_match"
        state.resolved_entity = ResolvedEntity(
            candidates=candidates_sorted,
            confidence=top.confidence,
            clarification_required=True,
            clarification_reason=reason,
            raw_entity_hint=hint,
        )
        state.requires_clarification = True
        names = ", ".join(c.display_name for c in candidates_sorted[:5])
        state.clarification_message = (
            f"I found a few possible matches for \"{hint}\": {names}. "
            "Which one did you mean?"
        )
        state.mark_stage(WorkflowStage.POLICY_CHECK)
        return state

    # Clear, unambiguous top candidate.
    state.resolved_entity = ResolvedEntity(
        canonical_id=top.canonical_id,
        entity_type=top.entity_type,
        display_name=top.display_name,
        confidence=top.confidence,
        candidates=candidates_sorted,
        clarification_required=False,
        raw_entity_hint=hint,
    )
    state.requires_clarification = False
    state.mark_stage(WorkflowStage.POLICY_CHECK)
    return state
