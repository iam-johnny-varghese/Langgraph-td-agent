"""
Node 6: score_root_cause_candidates

Reads:
    state.context_pack          (ContextPack) -- the sole evidence source
    state.tool_invocations       (list[ToolInvocation]) -- for evidence_refs

Writes:
    state.root_cause_candidates (list[RootCauseCandidate], sorted by
                                  confidence descending)
    state.current_stage         -> WorkflowStage.GENERATE_EXPLANATION

Error handling:
    Each scoring rule (_score_failed_etl_job, _score_workload_saturation,
    etc.) is independently wrapped; a single rule raising does not prevent
    other rules from contributing candidates. If ALL rules fail or produce
    nothing, this node still advances with an empty
    root_cause_candidates list plus a RootCauseCandidate(category=UNKNOWN,
    confidence=0.0, missing_evidence=[...]) so generate_user_explanation
    has something explicit to report ("insufficient evidence") rather than
    an empty list it has to interpret on its own.

Missing data behavior:
    Candidates explicitly track missing_evidence -- e.g. a
    failed_etl_job candidate with no failure_reason populated should have
    a lower confidence AND list "failure_reason" in missing_evidence,
    rather than silently omitting that gap.

Deterministic output (per spec: "deterministic scoring logic first, then
optionally LLM summarization second"):
    All scoring in this node is rule-based arithmetic over ContextPack
    fields. No LLM call happens in this node. An LLM-based re-ranking or
    narrative summarization step, if added later, belongs in
    services/root_cause_service.py or generate_response.py -- NOT here --
    so this node's output stays independently testable
    (see tests/test_workflow_diagnosis.py).
"""

from __future__ import annotations

import logging

from app.models.domain import ContextPack, RootCauseCandidate, RootCauseCategory
from app.models.workflow import WorkflowStage, WorkflowState

logger = logging.getLogger(__name__)


def _score_failed_etl_job(pack: ContextPack) -> RootCauseCandidate | None:
    """Looks for an explicit failure_reason on the most recent pipeline run."""
    failed_runs = [p for p in pack.pipeline_health if p.status == "failed"]
    if not failed_runs:
        return None
    most_recent = failed_runs[0]
    missing = []
    confidence = 0.6
    if most_recent.failure_reason:
        confidence = 0.9
    else:
        missing.append("failure_reason")
    return RootCauseCandidate(
        category=RootCauseCategory.FAILED_ETL_JOB,
        confidence=confidence,
        evidence_summary=(
            f"Pipeline {most_recent.pipeline_id} run {most_recent.run_id or 'unknown'} "
            f"has status=failed"
            + (f" ({most_recent.failure_reason})" if most_recent.failure_reason else "")
        ),
        evidence_refs=["pipeline_health[failed].failure_reason", "pipeline_health[failed].status"],
        missing_evidence=missing,
    )


def _score_upstream_data_delay(pack: ContextPack) -> RootCauseCandidate | None:
    """Looks for SLA misses where dependency edges exist (suggests an
    upstream feeder may be the actual cause rather than this pipeline itself)."""
    sla_missed = [p for p in pack.pipeline_health if p.sla_met is False]
    if not sla_missed or not pack.dependencies:
        return None
    missing = []
    confidence = 0.5
    upstream_edges = [d for d in pack.dependencies if d.downstream_id == pack.primary_entity.canonical_id]
    if upstream_edges:
        confidence = 0.7
    else:
        missing.append("upstream_dependency_health_for_this_entity")
    return RootCauseCandidate(
        category=RootCauseCategory.UPSTREAM_DATA_DELAY,
        confidence=confidence,
        evidence_summary=(
            f"SLA was missed and {len(pack.dependencies)} dependency edge(s) exist; "
            "an upstream delay is plausible but upstream pipeline health was not "
            "independently confirmed in this pass."
        ),
        evidence_refs=["pipeline_health[].sla_met", "dependencies"],
        missing_evidence=missing,
    )


def _score_workload_saturation(pack: ContextPack) -> RootCauseCandidate | None:
    """Looks for breached workload signals."""
    breached = [w for w in pack.workload_signals if w.threshold_breached]
    if not breached:
        return None
    return RootCauseCandidate(
        category=RootCauseCategory.WORKLOAD_SATURATION,
        confidence=0.8,
        evidence_summary=(
            f"{len(breached)} workload signal(s) breached threshold, e.g. "
            f"{breached[0].metric_name}={breached[0].metric_value}"
        ),
        evidence_refs=["workload_signals[threshold_breached]"],
        missing_evidence=[],
    )


def _score_dashboard_refresh_failure(pack: ContextPack) -> RootCauseCandidate | None:
    """Looks for a successful upstream pipeline but a still-missed SLA on
    the entity itself -- suggestive of a refresh-layer problem rather than
    a data-pipeline problem."""
    sla_missed = any(p.sla_met is False for p in pack.pipeline_health)
    all_upstream_ok = pack.pipeline_health and all(
        p.status == "success" for p in pack.pipeline_health
    )
    if not (sla_missed and all_upstream_ok):
        return None
    return RootCauseCandidate(
        category=RootCauseCategory.DASHBOARD_REFRESH_FAILURE,
        confidence=0.55,
        evidence_summary=(
            "Underlying pipeline(s) completed successfully but the SLA was still "
            "missed, which is consistent with a downstream refresh/rendering issue "
            "rather than a data pipeline failure."
        ),
        evidence_refs=["pipeline_health[].status", "pipeline_health[].sla_met"],
        missing_evidence=["dashboard_refresh_telemetry"],
    )


_RULES = [
    _score_failed_etl_job,
    _score_upstream_data_delay,
    _score_workload_saturation,
    _score_dashboard_refresh_failure,
]
# NOTE: security_regression and schema_drift categories (from
# RootCauseCategory) have no scoring rule yet -- they depend on MCP
# security-tool enrichment (sec_userDbPermissions/sec_userRoles deltas) and
# schema-comparison evidence respectively, neither of which is populated by
# retrieve_primary_context. TODO: add _score_security_regression and
# _score_schema_drift once enrich_with_mcp_tools reliably populates
# mcp_enrichment with the relevant tool outputs for those use cases.


def run(state: WorkflowState) -> WorkflowState:
    """Execute the score_root_cause_candidates node."""
    pack = state.context_pack
    if pack is None:
        state.add_error("score_root_cause_candidates: context_pack missing on entry")
        state.root_cause_candidates = [
            RootCauseCandidate(
                category=RootCauseCategory.UNKNOWN,
                confidence=0.0,
                evidence_summary="No context was available to evaluate.",
                missing_evidence=["context_pack"],
            )
        ]
        state.mark_stage(WorkflowStage.GENERATE_EXPLANATION)
        return state

    candidates: list[RootCauseCandidate] = []
    for rule in _RULES:
        try:
            result = rule(pack)
            if result is not None:
                candidates.append(result)
        except Exception as exc:  # noqa: BLE001 -- one bad rule must not block others
            logger.exception("score_root_cause_candidates: rule %s failed", rule.__name__)
            state.add_error(f"root_cause_rule_{rule.__name__}_failed: {exc}")

    if not candidates:
        candidates.append(
            RootCauseCandidate(
                category=RootCauseCategory.UNKNOWN,
                confidence=0.0,
                evidence_summary=(
                    "No deterministic root-cause pattern matched the available context."
                ),
                missing_evidence=list(pack.missing_data_flags) or ["no_specific_gap_identified"],
            )
        )

    candidates.sort(key=lambda c: c.confidence, reverse=True)
    state.root_cause_candidates = candidates
    state.mark_stage(WorkflowStage.GENERATE_EXPLANATION)
    return state
