"""
Node 3: check_policy_and_tool_eligibility

Reads:
    state.use_case_name      (Optional[str])
    state.resolved_entity     (Optional[ResolvedEntity])
    state.requires_clarification (bool) -- if True, this node still runs
                              (a policy decision is computed regardless,
                              since even a clarification response needs a
                              PolicyDecision.status for the audit record)
                              but the resulting status will typically be
                              READ_ONLY or BLOCKED since no concrete action
                              can be eligible for an unresolved entity.

Writes:
    state.policy_decision   (PolicyDecision)
    state.current_stage     -> WorkflowStage.RETRIEVE_CONTEXT (always advances;
                                a BLOCKED decision does not skip context
                                retrieval entirely -- read-only diagnostic
                                context may still be gatherable and useful
                                for the explanation -- but it DOES prevent
                                enrich_with_mcp_tools from invoking any
                                tool, and execute_approved_action_if_any
                                from running at all)

Error handling:
    Registry/policy repository errors fail CLOSED: any exception while
    reading context.agent_tool_registry or context.access_policy results
    in PolicyDecision.status = BLOCKED with allowed_tools = [] and an
    explanatory policy_reason. This node never fails open -- an inability
    to determine eligibility must never be treated as "everything is
    allowed".

Missing data behavior:
    - use_case_name is None or 'unknown': status = READ_ONLY at most;
      no tools are eligible since use_case-to-tool mapping has nothing to
      key off. (Read-only diagnostic context retrieval from
      retrieve_primary_context is still permitted since it does not go
      through agent_tool_registry at all -- it is direct repository access,
      not an MCP tool call.)
    - resolved_entity is None or clarification_required=True: status capped
      at READ_ONLY; approval-required or approved-for-safe-action statuses
      are never granted for an unresolved entity, since there is no
      well-defined target_object for an action yet.

Deterministic output:
    Tool eligibility is computed by exact use_case_name membership in each
    registry entry's use_case_allowlist -- no fuzzy or partial matching.
"""

from __future__ import annotations

import logging

from app.models.domain import PolicyDecision, PolicyDecisionStatus
from app.models.policy import AgentToolRegistryEntry
from app.models.workflow import WorkflowStage, WorkflowState
from app.repositories.teradata_security_repo import TeradataSecurityRepo

logger = logging.getLogger(__name__)


def _is_tool_eligible(entry: AgentToolRegistryEntry, use_case_name: str) -> bool:
    """Exact-match eligibility check: use_case_name must appear verbatim
    in the registry entry's use_case_allowlist. No partial/fuzzy matching."""
    return entry.is_enabled and use_case_name in entry.use_case_allowlist


def run(
    state: WorkflowState,
    tool_registry_entries: list[AgentToolRegistryEntry],
    security_repo: TeradataSecurityRepo,
) -> WorkflowState:
    """Execute the check_policy_and_tool_eligibility node.

    Args:
        state: shared workflow state.
        tool_registry_entries: the current contents of
            context.vw_enabled_tool_registry, pre-fetched by the caller
            (ops_copilot_graph.py) once per run rather than re-queried by
            every node that might need it.
            TODO: consider moving this fetch into a small
            services/policy_service.py so this node doesn't need the raw
            registry passed in -- left as a direct parameter for now per
            "explicit over clever" and to avoid a service layer that just
            forwards one repo call.
        security_repo: injected repository for access_policy lookups, used
            only when resolved_entity.entity_type implies a business
            object whose access policy is relevant (TODO: wire this in
            once entity_type -> object_name mapping is defined; currently
            unused in the body below, see inline TODO).
    """
    try:
        use_case = state.use_case_name or "unknown"
        entity = state.resolved_entity

        # Determine the ceiling on execution mode based on entity resolution
        # state. This is a ceiling, not a guarantee -- tool eligibility
        # filtering below can still reduce allowed_tools to an empty list
        # even if the ceiling permits APPROVED_FOR_SAFE_ACTION.
        if entity is None or entity.clarification_required:
            status_ceiling = PolicyDecisionStatus.READ_ONLY
        else:
            status_ceiling = PolicyDecisionStatus.APPROVED_FOR_SAFE_ACTION

        allowed_tools: list[str] = []
        denied_tools: list[str] = []
        requires_approval_for: list[str] = []

        for entry in tool_registry_entries:
            if _is_tool_eligible(entry, use_case):
                allowed_tools.append(entry.tool_name)
                if entry.requires_approval:
                    requires_approval_for.append(entry.tool_name)
            else:
                denied_tools.append(entry.tool_name)

        if use_case == "unknown":
            status = PolicyDecisionStatus.READ_ONLY
            reason = "use_case_unrecognized_defaulting_to_read_only"
            allowed_tools = []  # no use-case key to match against; least privilege
        elif not allowed_tools:
            status = PolicyDecisionStatus.READ_ONLY
            reason = f"no_tools_eligible_for_use_case={use_case}"
        elif requires_approval_for:
            # If any eligible tool requires approval, cap status at
            # APPROVAL_REQUIRED rather than APPROVED_FOR_SAFE_ACTION, unless
            # the entity-resolution ceiling already capped it lower (e.g.
            # READ_ONLY for an unresolved entity).
            status = (
                PolicyDecisionStatus.APPROVAL_REQUIRED
                if status_ceiling == PolicyDecisionStatus.APPROVED_FOR_SAFE_ACTION
                else status_ceiling
            )
            reason = f"tools_eligible_but_require_approval_for_use_case={use_case}"
        else:
            status = status_ceiling
            reason = f"tools_eligible_for_use_case={use_case}"

        # TODO: incorporate security_repo.get_access_policy(...) here once
        # resolved_entity carries (or can be mapped to) a concrete
        # object_name for business-object-level sensitivity checks (e.g.
        # PCI Secure Zone objects requiring an elevated required_role this
        # node has no way to verify the *requesting user* actually holds --
        # that verification itself happens via the security tools MCP
        # adapter in enrich_with_mcp_tools, not here). For now this node
        # only governs *tool* eligibility, not object-level access.

        state.policy_decision = PolicyDecision(
            status=status,
            allowed_tools=allowed_tools,
            denied_tools=denied_tools,
            policy_reason=reason,
            requires_approval_for_actions=requires_approval_for,
        )
        state.mark_stage(WorkflowStage.RETRIEVE_CONTEXT)
        return state

    except Exception as exc:  # noqa: BLE001 -- fail CLOSED on any error
        logger.exception(
            "check_policy_and_tool_eligibility: failing closed for request_id=%s",
            state.request.request_id,
        )
        state.add_error(f"check_policy_and_tool_eligibility failed: {exc}")
        state.fallback_paths_taken.append("policy_check_failed_fail_closed")
        state.policy_decision = PolicyDecision(
            status=PolicyDecisionStatus.BLOCKED,
            allowed_tools=[],
            denied_tools=[],
            policy_reason=f"policy_evaluation_error: {exc}",
            requires_approval_for_actions=[],
        )
        state.mark_stage(WorkflowStage.RETRIEVE_CONTEXT)
        return state
