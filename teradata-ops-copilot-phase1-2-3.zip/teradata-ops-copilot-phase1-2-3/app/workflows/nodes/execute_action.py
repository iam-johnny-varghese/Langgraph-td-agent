"""
Node 9: execute_approved_action_if_any

Reads:
    state.proposed_action    (Optional[ActionPlan])
    state.approval_request    (Optional[ApprovalRequest])
    state.policy_decision     (PolicyDecision)

Writes:
    state.action_executed   (bool)
    state.action_outcome    (Optional[str])
    state.current_stage     -> WorkflowStage.PERSIST_AUDIT

Error handling:
    This node executes ONLY when ALL of the following hold:
        1. proposed_action is not None.
        2. approval_request.status is APPROVED, or NOT_REQUIRED (a safe
           action that never needed approval in the first place).
        3. policy_decision.status is not BLOCKED.
    Any other combination results in action_executed=False with an
    explanatory action_outcome ('skipped_not_approved',
    'skipped_no_action_proposed', 'skipped_policy_blocked') -- this node
    never executes "just in case" or treats a PENDING/REJECTED/EXPIRED
    approval as good enough.

    Execution itself is routed through _ACTION_EXECUTORS, a small registry
    of narrow per-action-type functions -- per spec: "Route through a
    narrow adapter or stored procedure path, not arbitrary SQL
    generation." There is no code path in this node that constructs or
    runs free-form SQL from action payload data.

    If the chosen executor raises, action_executed=False and
    action_outcome='failed: <error>' -- a failed execution attempt is
    still recorded distinctly from a skipped one, since they have
    different audit/follow-up implications.

Missing data behavior:
    If an action_type has no registered executor yet (most don't, in this
    scaffold -- see _ACTION_EXECUTORS below), the node treats this the
    same as "execution not yet implemented" rather than silently
    succeeding: action_outcome='not_implemented:<action_type>'.

Approval re-validation note:
    This node re-checks approval_request.status itself rather than
    trusting that request_approval_if_needed's decision is still valid --
    in a real deployment, approval may be granted asynchronously (e.g. a
    human clicks "approve" in a separate UI/ticket flow) well after this
    node's WorkflowState was first constructed, so the approval_request
    object passed in here should reflect the LATEST status, not a stale
    snapshot. TODO: wire actual approval-status refresh (e.g. a lookup
    against approval_service.get_approval_status(approval_id)) before this
    node runs, rather than assuming state.approval_request is current.
"""

from __future__ import annotations

import logging
from typing import Callable, Optional

from app.models.domain import ActionPlan, ActionType, ApprovalStatus, PolicyDecisionStatus
from app.models.workflow import WorkflowStage, WorkflowState

logger = logging.getLogger(__name__)


def _execute_notify_owner(plan: ActionPlan) -> str:
    """Safe action: notify the data product owner. Routed through a narrow
    notification adapter, never arbitrary code execution.

    TODO: wire to an actual notification channel (e.g. Teams webhook via
    M365 tooling, or an internal notification service) -- this is a stub
    that records intent only.
    """
    logger.info("STUB: would notify owner of target=%s", plan.target_object)
    return "notification_stub_logged"


def _execute_create_incident_summary(plan: ActionPlan) -> str:
    """Safe action: create an incident summary record (e.g. ServiceNow).

    TODO: wire to ServiceNow incident creation (consistent with prior
    platform automation patterns) -- this is a stub.
    """
    logger.info("STUB: would create incident summary for target=%s", plan.target_object)
    return "incident_summary_stub_created"


def _execute_gather_additional_diagnostics(plan: ActionPlan) -> str:
    """Safe action: trigger additional diagnostic collection.

    TODO: wire to a deeper diagnostic repository call (e.g. a wider
    dependency chain depth, or additional MCP DBA tool calls) -- this is a
    stub that records intent only. Notably this does NOT re-enter the
    workflow graph from here; if deeper diagnostics are needed, the
    correct pattern is to raise requires_clarification or loop the graph,
    not to have this execution node silently do more retrieval work.
    """
    logger.info("STUB: would gather additional diagnostics for target=%s", plan.target_object)
    return "additional_diagnostics_stub_triggered"


# Approval-required actions intentionally have NO executor wired in this
# scaffold -- rerun_pipeline, grant_or_revoke_access, and execute_macro all
# touch production systems and must be implemented as explicit, reviewed,
# narrow stored-procedure-backed adapters before being enabled. Leaving
# them absent from this registry means _ACTION_EXECUTORS.get() naturally
# falls through to 'not_implemented' for them, rather than needing a
# separate guard.
# TODO: implement narrow adapters for these three action types (likely in
# a new app/services/remediation_service.py or directly as stored
# procedure calls in repositories/teradata_ops_repo.py) before enabling
# them here. Each implementation MUST validate target_object against
# context.access_policy / agent_tool_registry again immediately before
# executing, not rely solely on the upstream policy_decision snapshot.
_ACTION_EXECUTORS: dict[ActionType, Callable[[ActionPlan], str]] = {
    ActionType.NOTIFY_OWNER: _execute_notify_owner,
    ActionType.CREATE_INCIDENT_SUMMARY: _execute_create_incident_summary,
    ActionType.GATHER_ADDITIONAL_DIAGNOSTICS: _execute_gather_additional_diagnostics,
}


def run(state: WorkflowState) -> WorkflowState:
    """Execute the execute_approved_action_if_any node."""
    plan = state.proposed_action
    approval = state.approval_request
    policy = state.policy_decision

    if plan is None:
        state.action_executed = False
        state.action_outcome = "skipped_no_action_proposed"
        state.mark_stage(WorkflowStage.PERSIST_AUDIT)
        return state

    if policy is not None and policy.status == PolicyDecisionStatus.BLOCKED:
        state.action_executed = False
        state.action_outcome = "skipped_policy_blocked"
        state.mark_stage(WorkflowStage.PERSIST_AUDIT)
        return state

    is_approved = approval is not None and approval.status in (
        ApprovalStatus.APPROVED,
        ApprovalStatus.NOT_REQUIRED,
    )
    if not is_approved:
        state.action_executed = False
        state.action_outcome = "skipped_not_approved"
        state.mark_stage(WorkflowStage.PERSIST_AUDIT)
        return state

    executor: Optional[Callable[[ActionPlan], str]] = _ACTION_EXECUTORS.get(plan.action_type)
    if executor is None:
        state.action_executed = False
        state.action_outcome = f"not_implemented:{plan.action_type.value}"
        state.mark_stage(WorkflowStage.PERSIST_AUDIT)
        return state

    try:
        outcome = executor(plan)
        state.action_executed = True
        state.action_outcome = outcome
    except Exception as exc:  # noqa: BLE001 -- execution failure must not crash the graph
        logger.exception(
            "execute_approved_action_if_any: executor failed for action_type=%s",
            plan.action_type,
        )
        state.add_error(f"execute_approved_action_if_any failed: {exc}")
        state.action_executed = False
        state.action_outcome = f"failed: {exc}"

    state.mark_stage(WorkflowStage.PERSIST_AUDIT)
    return state
