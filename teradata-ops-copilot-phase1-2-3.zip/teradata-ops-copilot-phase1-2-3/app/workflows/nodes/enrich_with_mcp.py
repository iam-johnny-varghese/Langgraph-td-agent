"""
Node 5: enrich_with_mcp_tools

Reads:
    state.policy_decision   (PolicyDecision) -- allowed_tools is the
                             authoritative source of truth for which tools
                             this node may call; nothing else (use case,
                             entity type, etc.) overrides it here.
    state.context_pack      (ContextPack) -- mutated in place to add
                             mcp_enrichment / runbook_snippets
    state.resolved_entity    (ResolvedEntity) -- used to build tool
                             parameters (e.g. user_name, object_name)

Writes:
    state.context_pack.mcp_enrichment    (dict[str, Any], keyed by tool name)
    state.context_pack.runbook_snippets  (list[str], from vector tool calls)
    state.tool_invocations               (list[ToolInvocation], appended to)
    state.current_stage                  -> WorkflowStage.SCORE_ROOT_CAUSE

Error handling:
    - If policy_decision.status is BLOCKED, this node calls ZERO tools and
      advances immediately -- it does not attempt any call "just to see".
    - Each individual tool call is wrapped independently; one tool's
      failure/timeout does not prevent other approved tools from being
      tried. Failures are recorded as ToolInvocation(status="error") in
      state.tool_invocations for audit, and as a missing_data_flag on the
      ContextPack so generate_user_explanation knows evidence is
      incomplete rather than silently absent.
    - Any tool call whose name is not in policy_decision.allowed_tools is
      REJECTED before being sent to the MCP client at all -- this is a
      defense-in-depth check; the adapters themselves (Phase 4) also
      enforce this, but the node-level gate is the first line of defense
      and is what gets logged as "rejected" here specifically.

Missing data behavior:
    This node decides WHICH tools to call based on what's actually missing
    or ambiguous in context_pack (e.g. only call sec_userDbPermissions if
    use_case is access_review/security_audit AND a concrete user identity
    is known) -- it does not call every allowed tool unconditionally. See
    _plan_tool_calls below for the (currently simple, rule-based) planning
    logic.

Deterministic output:
    Tool selection is rule-based on (use_case_name, available identifiers),
    not LLM-driven, so this node's behavior is reproducible given the same
    state input.

TODO (Phase 4 integration point):
    This node currently references adapter classes
    (DBAToolsAdapter/SecurityToolsAdapter/VectorToolsAdapter/BaseToolsAdapter)
    that are defined in mcp/adapters/*.py. The actual call signatures here
    are written against the interfaces those Phase 4 files expose; if the
    Phase 4 adapter interface changes during implementation, this node's
    _plan_tool_calls / _execute_tool_calls bodies will need matching updates.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Optional

from app.models.domain import ToolInvocation
from app.models.mcp import MCPToolCategory, MCPToolResultStatus
from app.models.workflow import WorkflowStage, WorkflowState

logger = logging.getLogger(__name__)


@dataclass
class PlannedToolCall:
    """A single tool call this node intends to make, before policy
    re-validation and actual invocation."""

    tool_name: str
    category: MCPToolCategory
    parameters: dict[str, Any]


def _plan_tool_calls(state: WorkflowState) -> list[PlannedToolCall]:
    """Decide which tools to call based on use case and known identifiers.

    Conservative by design: only plans a call when the parameters it would
    need are actually available on state -- never plans a call with a
    placeholder/guessed parameter value. Per spec: "do not pass empty or
    null values" and "extract only parameters explicitly mentioned or
    clearly implied."
    """
    planned: list[PlannedToolCall] = []
    use_case = state.use_case_name or "unknown"
    entity = state.resolved_entity

    if use_case in ("access_review", "security_audit") and entity and entity.canonical_id:
        # NOTE: entity.canonical_id here is a data_product/pipeline id, not
        # necessarily a user_name. Security tools need an actual user
        # identity. TODO: once UserRequest/entity hint parsing can extract
        # a target *user* identity distinct from a data-product entity
        # (e.g. "does user X still have access to Y"), wire that through
        # here instead of state.request.requesting_user as a placeholder.
        # Using requesting_user as a conservative default ONLY when the
        # request is plausibly self-referential; otherwise this should
        # remain unplanned rather than guess whose access to check.
        pass  # TODO: intentionally not planning sec_* calls until target
        # user identity extraction exists -- see node docstring's "do not
        # guess missing identifiers" contract. Left as a TODO rather than
        # calling with a guessed user_name.

    if use_case == "workload_analysis" and entity and entity.canonical_id:
        planned.append(
            PlannedToolCall(
                tool_name="dba_workloadHealth",  # TODO: confirm exact MCP tool name
                category=MCPToolCategory.DBA,
                parameters={"workload_id": entity.canonical_id},
            )
        )

    if state.context_pack and state.context_pack.missing_data_flags:
        # If primary context retrieval came back thin, try a runbook/SOP
        # lookup to give generate_user_explanation something procedural to
        # ground "safe next steps" in, even when hard evidence is sparse.
        if entity and entity.display_name:
            planned.append(
                PlannedToolCall(
                    tool_name="vector_runbookSearch",  # TODO: confirm exact MCP tool name
                    category=MCPToolCategory.VECTOR,
                    parameters={"query": entity.display_name, "top_k": 3},
                )
            )

    return planned


def _filter_to_allowed(
    planned: list[PlannedToolCall], allowed_tools: list[str]
) -> tuple[list[PlannedToolCall], list[PlannedToolCall]]:
    """Split planned calls into (allowed, rejected) based on the
    policy_decision allow-list. Defense-in-depth -- adapters re-check too."""
    allowed: list[PlannedToolCall] = []
    rejected: list[PlannedToolCall] = []
    allowed_set = set(allowed_tools)
    for call in planned:
        (allowed if call.tool_name in allowed_set else rejected).append(call)
    return allowed, rejected


def run(state: WorkflowState, mcp_client: Optional[Any] = None) -> WorkflowState:
    """Execute the enrich_with_mcp_tools node.

    Args:
        state: shared workflow state.
        mcp_client: injected MCPClient (see mcp/client.py, Phase 4). Typed
            as Optional[Any] here rather than importing MCPClient directly
            to avoid a hard import-time dependency from the workflow layer
            on the mcp package before Phase 4 lands; tighten this type hint
            once mcp/client.py is finalized.
            TODO: replace `Optional[Any]` with `MCPClient` once Phase 4 is
            complete and circular-import risk (if any) is confirmed absent.
    """
    if state.context_pack is None:
        # Defensive: should be unreachable since retrieve_primary_context
        # always sets a (possibly empty) ContextPack before this node runs.
        state.add_error("enrich_with_mcp_tools: context_pack missing on entry")
        state.mark_stage(WorkflowStage.SCORE_ROOT_CAUSE)
        return state

    policy = state.policy_decision
    if policy is None or policy.status.value == "blocked":
        logger.info(
            "enrich_with_mcp_tools: skipping all tool calls (status=%s) for request_id=%s",
            policy.status if policy else None,
            state.request.request_id,
        )
        state.mark_stage(WorkflowStage.SCORE_ROOT_CAUSE)
        return state

    planned = _plan_tool_calls(state)
    allowed_calls, rejected_calls = _filter_to_allowed(planned, policy.allowed_tools)

    for call in rejected_calls:
        logger.warning(
            "enrich_with_mcp_tools: rejected tool call %s (not in allowed_tools) for request_id=%s",
            call.tool_name,
            state.request.request_id,
        )
        state.tool_invocations.append(
            ToolInvocation(
                tool_name=call.tool_name,
                category=call.category.value,
                parameters=call.parameters,
                status="rejected",
                error_message="tool_not_in_policy_allowed_tools",
            )
        )

    for call in allowed_calls:
        started = time.monotonic()
        try:
            if mcp_client is None:
                raise RuntimeError("mcp_client not configured")
            # TODO: this call signature (mcp_client.call_tool(name, params))
            # is the assumed Phase 4 MCPClient interface -- confirm against
            # mcp/client.py once written.
            result = mcp_client.call_tool(call.tool_name, call.parameters)
            latency_ms = (time.monotonic() - started) * 1000

            status = (
                "success"
                if getattr(result, "status", None) == MCPToolResultStatus.SUCCESS
                else "error"
            )
            summary = getattr(result, "result_summary", None)

            state.tool_invocations.append(
                ToolInvocation(
                    tool_name=call.tool_name,
                    category=call.category.value,
                    parameters=call.parameters,
                    status=status,
                    latency_ms=latency_ms,
                    result_summary=summary,
                    error_message=getattr(result, "error_message", None),
                )
            )

            if status == "success":
                state.context_pack.mcp_enrichment[call.tool_name] = summary
                if call.category == MCPToolCategory.VECTOR and summary:
                    state.context_pack.runbook_snippets.append(summary)
            else:
                state.context_pack.missing_data_flags.append(f"mcp_tool_failed:{call.tool_name}")

        except Exception as exc:  # noqa: BLE001 -- one tool failure must not block others
            latency_ms = (time.monotonic() - started) * 1000
            logger.exception(
                "enrich_with_mcp_tools: tool call failed tool=%s request_id=%s",
                call.tool_name,
                state.request.request_id,
            )
            state.tool_invocations.append(
                ToolInvocation(
                    tool_name=call.tool_name,
                    category=call.category.value,
                    parameters=call.parameters,
                    status="error",
                    latency_ms=latency_ms,
                    error_message=str(exc),
                )
            )
            state.context_pack.missing_data_flags.append(f"mcp_tool_error:{call.tool_name}")

    state.mark_stage(WorkflowStage.SCORE_ROOT_CAUSE)
    return state
