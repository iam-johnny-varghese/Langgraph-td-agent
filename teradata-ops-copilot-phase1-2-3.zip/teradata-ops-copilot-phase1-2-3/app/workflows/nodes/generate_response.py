"""
Node 7: generate_user_explanation

Reads:
    state.context_pack            (ContextPack)
    state.root_cause_candidates    (list[RootCauseCandidate])
    state.requires_clarification   (bool)
    state.clarification_message    (Optional[str])

Writes:
    state.user_explanation   (str)
    state.current_stage      -> WorkflowStage.REQUEST_APPROVAL

Error handling:
    This node has two modes:
      1. clarification mode (requires_clarification=True): returns
         clarification_message verbatim-ish (lightly wrapped), does NOT
         attempt root-cause narration at all, since there's no confirmed
         entity to narrate about yet.
      2. explanation mode: builds a grounded explanation strictly from
         context_pack and root_cause_candidates fields. If an optional LLM
         summarizer is wired in (see _llm_summarize TODO) and it fails or
         is unavailable, this node falls back to the deterministic
         template-based explanation rather than failing the node -- the
         LLM path is a presentation enhancement, never a hard dependency.

Missing data behavior:
    The explanation template explicitly surfaces missing_evidence and
    missing_data_flags as a "what we don't know yet" section rather than
    omitting them, so the user can tell the difference between "we
    diagnosed this with confidence" and "this is our best guess, here's
    what's missing."

Grounding guarantee (per spec: "Do not fabricate evidence"):
    Every sentence in the deterministic template path is built directly
    from a ContextPack or RootCauseCandidate field via simple string
    formatting -- there is no free-text generation step that could
    introduce facts not present in the inputs. If an LLM summarization
    pass is added later (services/prompt_service.py +
    prompts/root_cause_prompt.txt), its prompt MUST instruct the model to
    use only the supplied evidence and must not be the sole source of any
    factual claim -- see prompts/root_cause_prompt.txt (Phase 5) for the
    explicit grounding instructions that prompt will carry.
"""

from __future__ import annotations

import logging
from typing import Optional

from app.models.domain import ContextPack, RootCauseCandidate
from app.models.workflow import WorkflowStage, WorkflowState

logger = logging.getLogger(__name__)


def _format_business_impact(pack: ContextPack) -> str:
    if pack.data_product is None:
        return ""
    crit = pack.data_product.business_criticality or "unspecified criticality"
    return (
        f"This affects **{pack.data_product.name}** (owned by {pack.data_product.owner}, "
        f"{crit})."
    )


def _format_top_cause(candidate: RootCauseCandidate) -> str:
    pct = round(candidate.confidence * 100)
    line = f"**Most likely cause ({pct}% confidence):** {candidate.category.value.replace('_', ' ')}. {candidate.evidence_summary}"
    if candidate.missing_evidence:
        line += f" (Note: {', '.join(candidate.missing_evidence)} could not be confirmed.)"
    return line


def _format_other_causes(candidates: list[RootCauseCandidate]) -> str:
    if len(candidates) <= 1:
        return ""
    lines = ["**Other possibilities considered:**"]
    for c in candidates[1:4]:  # cap at 3 alternates to keep the explanation readable
        pct = round(c.confidence * 100)
        lines.append(f"- {c.category.value.replace('_', ' ')} ({pct}%): {c.evidence_summary}")
    return "\n".join(lines)


def _format_missing_data(pack: ContextPack) -> str:
    if not pack.missing_data_flags:
        return ""
    return "**Data gaps:** " + ", ".join(pack.missing_data_flags)


def _format_safe_next_steps(candidates: list[RootCauseCandidate]) -> str:
    if not candidates:
        return ""
    top = candidates[0]
    steps = {
        "failed_etl_job": "Consider preparing a rerun request for the failed pipeline.",
        "upstream_data_delay": "Check the upstream feeder's own SLA status before rerunning downstream.",
        "workload_saturation": "Review workload allocation/TASM rules for the affected workload.",
        "dashboard_refresh_failure": "Check the dashboard refresh/caching layer rather than the data pipeline.",
        "security_regression": "Review recent role/permission changes for the affected object.",
        "schema_drift": "Compare current schema against the last known-good version.",
        "unknown": "Gather additional diagnostics before proposing a fix.",
    }
    return "**Suggested next step:** " + steps.get(top.category.value, steps["unknown"])


def _build_deterministic_explanation(
    pack: ContextPack, candidates: list[RootCauseCandidate]
) -> str:
    sections = [
        _format_business_impact(pack),
        _format_top_cause(candidates[0]) if candidates else "No root-cause hypothesis could be formed.",
        _format_other_causes(candidates),
        _format_missing_data(pack),
        _format_safe_next_steps(candidates),
    ]
    return "\n\n".join(s for s in sections if s)


def _llm_summarize(pack: ContextPack, candidates: list[RootCauseCandidate]) -> Optional[str]:
    """Optional LLM-based narrative polish over the deterministic explanation.

    TODO: wire to services/prompt_service.py using
    prompts/root_cause_prompt.txt (Phase 5), which must instruct the model
    to rephrase/organize ONLY the supplied evidence -- not introduce new
    claims. Returns None (meaning: caller should use the deterministic
    template) until that integration exists, so this node is fully
    functional without any LLM dependency.
    """
    return None


def run(state: WorkflowState) -> WorkflowState:
    """Execute the generate_user_explanation node."""
    if state.requires_clarification:
        message = state.clarification_message or (
            "I need a bit more information before I can help with this."
        )
        state.user_explanation = message
        state.mark_stage(WorkflowStage.REQUEST_APPROVAL)
        return state

    pack = state.context_pack
    candidates = state.root_cause_candidates

    if pack is None:
        state.user_explanation = (
            "I wasn't able to gather enough context to explain what happened. "
            "Please try again or provide more detail."
        )
        state.add_error("generate_user_explanation: context_pack missing on entry")
        state.mark_stage(WorkflowStage.REQUEST_APPROVAL)
        return state

    try:
        explanation = _llm_summarize(pack, candidates)
        if explanation is None:
            explanation = _build_deterministic_explanation(pack, candidates)
    except Exception as exc:  # noqa: BLE001 -- LLM path must never break this node
        logger.exception("generate_user_explanation: LLM summarization failed, using template")
        state.add_error(f"generate_user_explanation llm_summarize failed: {exc}")
        state.fallback_paths_taken.append("llm_summarize_failed_used_deterministic_template")
        explanation = _build_deterministic_explanation(pack, candidates)

    state.user_explanation = explanation
    state.mark_stage(WorkflowStage.REQUEST_APPROVAL)
    return state
