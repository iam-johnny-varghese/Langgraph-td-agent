"""
Teradata Context Repository.

Owns all SQL access to the "core context" objects used primarily by entity
resolution and primary context retrieval:
    - context.data_product_catalog / vw_data_product_with_owner
    - context.data_product_alias
    - context.data_dependency / vw_active_dependency_edges

No other layer should issue SQL against these objects directly. Services
(entity_resolver.py, context_engine.py) call into this repository and work
with the typed Pydantic models it returns, never raw cursor rows.

Connection management: this repository is written against a generic
synchronous DB-API-style connection (teradatasql convention, matching prior
platform tooling) injected via constructor. TODO: confirm final driver
choice (teradatasql vs teradataml) and whether pooling is handled here or
by a shared connection-pool module in core/config.py.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional, Protocol

from app.models.domain import DataProductSummary, DependencyEdge, EntityCandidate, EntityType

logger = logging.getLogger(__name__)

_SQL_DIR = Path(__file__).resolve().parent.parent / "sql" / "queries"


class TeradataConnection(Protocol):
    """Minimal structural type for the DB-API connection this repo needs.

    Defined as a Protocol rather than importing a concrete driver type so
    this module stays importable/testable without a Teradata driver
    installed (e.g. in CI). The real connection object (teradatasql.Connection
    or similar) satisfies this Protocol structurally.
    """

    def cursor(self) -> Any: ...


class TeradataContextRepo:
    """Repository for data product catalog, alias, and dependency data.

    All public methods:
      - accept already-validated, non-empty identifiers (callers must not
        pass None/empty strings -- see "do not guess missing identifiers"
        constraint from the spec; this repo does not silently default).
      - return typed Pydantic models or lists thereof, never raw tuples.
      - raise on connection/driver errors; callers (services layer) are
        responsible for catching and translating into WorkflowState errors.
    """

    def __init__(self, connection: TeradataConnection) -> None:
        self._conn = connection

    @staticmethod
    def _load_sql(filename: str) -> str:
        """Loads a .sql template file from app/sql/queries/.

        TODO: add simple in-process caching (e.g. functools.lru_cache) once
        the query set stabilizes -- file reads are cheap but unnecessary on
        a hot path.
        """
        path = _SQL_DIR / filename
        return path.read_text(encoding="utf-8")

    def get_data_product(self, data_product_id: str) -> Optional[DataProductSummary]:
        """Fetch a single data product by canonical ID.

        Maps to sql/queries/get_data_product.sql.

        Returns None if no active data product matches data_product_id --
        callers should treat this as "not found", not as an error.
        """
        # TODO: execute self._load_sql("get_data_product.sql") with
        # {"data_product_id": data_product_id} bound, fetch one row, and
        # map into DataProductSummary. Returning None as a placeholder
        # until the driver/binding convention is finalized.
        logger.debug("get_data_product called for data_product_id=%s (STUB)", data_product_id)
        return None

    def get_alias_matches(self, entity_hint: str) -> list[EntityCandidate]:
        """Resolve a free-text hint to candidate data products via alias matching.

        Maps to sql/queries/get_alias_matches.sql. Returns ALL matches above
        the SQL's minimal relevance bar, ordered by match_confidence
        descending -- this repo does NOT decide ambiguity; that judgment
        belongs to services/entity_resolver.py, which inspects the returned
        candidate list (e.g. checking for multiple high-confidence ties)
        and sets ResolvedEntity.clarification_required accordingly.

        Raises:
            ValueError: if entity_hint is empty/whitespace-only -- this repo
            will not silently query with an empty hint, since that could
            return an unbounded/meaningless result set.
        """
        if not entity_hint or not entity_hint.strip():
            raise ValueError("entity_hint must not be empty")
        # TODO: execute self._load_sql("get_alias_matches.sql") with
        # {"entity_hint": entity_hint.strip()} bound, map each row into an
        # EntityCandidate(entity_type=EntityType.DATA_PRODUCT, ...).
        logger.debug("get_alias_matches called for entity_hint=%r (STUB)", entity_hint)
        return []

    def get_dependency_chain(self, root_id: str, max_depth: int = 5) -> list[DependencyEdge]:
        """Walk the dependency graph downstream from root_id, bounded by max_depth.

        Maps to sql/queries/get_dependency_chain.sql (recursive CTE,
        upstream -> downstream direction / impact analysis).

        Args:
            root_id: canonical data_product_id or pipeline_id to start from.
            max_depth: recursion depth bound; defaults to 5 to keep impact
                analysis focused on near-term dependents. TODO: consider
                making this configurable via core/config.py rather than a
                hardcoded default if deep chains turn out to be common.
        """
        if not root_id or not root_id.strip():
            raise ValueError("root_id must not be empty")
        if max_depth < 1:
            raise ValueError("max_depth must be >= 1")
        # TODO: execute self._load_sql("get_dependency_chain.sql") with
        # {"root_id": root_id.strip(), "max_depth": max_depth} bound, map
        # each row into a DependencyEdge.
        logger.debug(
            "get_dependency_chain called for root_id=%s, max_depth=%s (STUB)", root_id, max_depth
        )
        return []
