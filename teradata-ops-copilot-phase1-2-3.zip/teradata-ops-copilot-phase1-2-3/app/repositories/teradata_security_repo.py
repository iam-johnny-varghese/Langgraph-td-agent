"""
Teradata Security Repository.

Owns SQL access to context.access_policy -- business-object access policy
rules (required role, sensitivity level, action class per object pattern).

IMPORTANT distinction: this repository does NOT check actual current user
permissions/roles/grants against Teradata's DBC security tables. That is
the job of mcp/adapters/security_tools.py, which goes through Teradata
Enterprise MCP tools such as sec_userDbPermissions and sec_userRoles. This
repository only answers "what access policy SHOULD apply to this object",
which is then compared against the MCP-sourced "what access DOES this user
actually have" to detect regressions (e.g. "does user X still have
elevated access to production finance objects?").
"""

from __future__ import annotations

import logging
from pathlib import Path

from app.models.policy import AccessPolicyRule
from app.repositories.teradata_context_repo import TeradataConnection

logger = logging.getLogger(__name__)

_SQL_DIR = Path(__file__).resolve().parent.parent / "sql" / "queries"


class TeradataSecurityRepo:
    """Repository for business-object access policy rules.

    See module docstring for the important distinction between this
    repository (policy *should-be* state) and the MCP security tools
    adapter (actual *current* grants/roles).
    """

    def __init__(self, connection: TeradataConnection) -> None:
        self._conn = connection

    @staticmethod
    def _load_sql(filename: str) -> str:
        path = _SQL_DIR / filename
        return path.read_text(encoding="utf-8")

    def get_access_policy(self, object_name: str) -> list[AccessPolicyRule]:
        """Fetch active access policy rules matching a canonical object name.

        Maps to sql/queries/get_access_policy.sql. Returns rules ordered
        most-specific-pattern-first (see SQL comments); callers that need
        a single "winning" rule should take the first element but remain
        aware that overlapping patterns are a data quality signal worth
        surfacing, not silently resolving.

        Raises:
            ValueError: if object_name is empty.
        """
        if not object_name or not object_name.strip():
            raise ValueError("object_name must not be empty")
        # TODO: execute self._load_sql("get_access_policy.sql") with
        # {"object_name": object_name.strip()} bound, map rows into
        # AccessPolicyRule list.
        logger.debug("get_access_policy called for object_name=%s (STUB)", object_name)
        return []
