"""
Teradata Operations Repository.

Owns all SQL access to operational/health objects:
    - context.pipeline_health / vw_latest_pipeline_status
    - context.workload_signal / vw_breached_workload_signals

Used by retrieve_primary_context (latest pipeline status) and
score_root_cause_candidates (workload signal evidence for
workload_saturation hypotheses) via services/context_engine.py and
services/root_cause_service.py respectively.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from app.models.domain import PipelineHealthSnapshot, WorkloadSignal
from app.repositories.teradata_context_repo import TeradataConnection

logger = logging.getLogger(__name__)

_SQL_DIR = Path(__file__).resolve().parent.parent / "sql" / "queries"


class TeradataOpsRepo:
    """Repository for pipeline health and workload signal data.

    Mirrors TeradataContextRepo's conventions: typed return values, no raw
    cursor rows escape this module, empty/invalid identifiers raise rather
    than silently returning unbounded results.
    """

    def __init__(self, connection: TeradataConnection) -> None:
        self._conn = connection

    @staticmethod
    def _load_sql(filename: str) -> str:
        path = _SQL_DIR / filename
        return path.read_text(encoding="utf-8")

    def get_latest_pipeline_status(
        self,
        pipeline_id: Optional[str] = None,
        data_product_id: Optional[str] = None,
    ) -> list[PipelineHealthSnapshot]:
        """Fetch the latest run status for a pipeline or for all pipelines
        feeding a data product.

        Maps to sql/queries/get_latest_pipeline_status.sql.

        Exactly one of pipeline_id / data_product_id should be supplied.
        Per the spec's "omit null or empty parameters" rule, callers must
        not pass both as None -- this is enforced here rather than left to
        produce a confusing empty result set.

        Raises:
            ValueError: if neither pipeline_id nor data_product_id is provided.
        """
        if not pipeline_id and not data_product_id:
            raise ValueError("one of pipeline_id or data_product_id is required")
        # TODO: execute self._load_sql("get_latest_pipeline_status.sql") with
        # {"pipeline_id": pipeline_id, "data_product_id": data_product_id}
        # bound (driver should bind None as SQL NULL), map rows into
        # PipelineHealthSnapshot list.
        logger.debug(
            "get_latest_pipeline_status called pipeline_id=%s data_product_id=%s (STUB)",
            pipeline_id,
            data_product_id,
        )
        return []

    def get_workload_signals(self, workload_id: str, top_n: int = 50) -> list[WorkloadSignal]:
        """Fetch recent breached workload signals for a given workload_id.

        Maps to sql/queries/get_workload_signals.sql. Returns at most top_n
        rows (Teradata TOP n, not LIMIT), most recent first.

        Raises:
            ValueError: if workload_id is empty or top_n is non-positive.
        """
        if not workload_id or not workload_id.strip():
            raise ValueError("workload_id must not be empty")
        if top_n <= 0:
            raise ValueError("top_n must be positive")
        # TODO: execute self._load_sql("get_workload_signals.sql") with
        # {"workload_id": workload_id.strip(), "top_n": top_n} bound, map
        # rows into WorkloadSignal list.
        logger.debug(
            "get_workload_signals called workload_id=%s top_n=%s (STUB)", workload_id, top_n
        )
        return []
