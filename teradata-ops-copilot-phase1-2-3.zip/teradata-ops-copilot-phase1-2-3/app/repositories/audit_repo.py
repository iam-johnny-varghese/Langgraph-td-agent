"""
Audit Repository.

Owns SQL access to context.context_audit -- the append-only persisted log
of workflow executions. This is the only repository that WRITES (the
others are read-only by design); persist_audit_record (workflow node) is
the only caller.

Serialization convention: context.context_audit stores tool_sequence,
top_root_causes, errors, fallback_paths, and extra as JSON text columns
(see sql/context/create_context_tables.sql comments on denormalization
rationale). This module owns the AuditRecord <-> JSON-text mapping so that
choice doesn't leak into the workflow node itself.
"""

from __future__ import annotations

import json
import logging
from typing import Optional

from app.models.audit import AuditRecord
from app.repositories.teradata_context_repo import TeradataConnection

logger = logging.getLogger(__name__)

_INSERT_SQL = """
INSERT INTO context.context_audit (
    request_id, user_name, use_case_name,
    resolved_entity_id, resolved_entity_type, clarification_required,
    policy_decision_status, policy_reason,
    tool_sequence_json, top_root_causes_json,
    action_recommended, approval_status, action_outcome,
    started_ts, completed_ts, elapsed_ms,
    errors_json, fallback_paths_json, extra_json
) VALUES (
    :request_id, :user_name, :use_case_name,
    :resolved_entity_id, :resolved_entity_type, :clarification_required,
    :policy_decision_status, :policy_reason,
    :tool_sequence_json, :top_root_causes_json,
    :action_recommended, :approval_status, :action_outcome,
    :started_ts, :completed_ts, :elapsed_ms,
    :errors_json, :fallback_paths_json, :extra_json
)
"""
# TODO: this INSERT is inlined here rather than in sql/queries/ because it's
# a write (not a read query the spec's sql/queries/ list enumerates) and is
# tightly coupled to AuditRecord's exact shape. Revisit if a SQL-file-per-
# statement convention is preferred for consistency / DBA review purposes.

_SELECT_BY_REQUEST_ID_SQL = """
SELECT
    request_id, user_name, use_case_name,
    resolved_entity_id, resolved_entity_type, clarification_required,
    policy_decision_status, policy_reason,
    tool_sequence_json, top_root_causes_json,
    action_recommended, approval_status, action_outcome,
    started_ts, completed_ts, elapsed_ms,
    errors_json, fallback_paths_json, extra_json
FROM context.context_audit
WHERE request_id = :request_id
"""


class AuditRepo:
    """Repository for persisting and retrieving AuditRecord rows.

    All public methods accept/return AuditRecord (or Optional[AuditRecord]);
    JSON encoding/decoding of the list-valued fields is handled internally.
    """

    def __init__(self, connection: TeradataConnection) -> None:
        self._conn = connection

    def insert_audit_record(self, record: AuditRecord) -> None:
        """Persist a single AuditRecord as one row in context.context_audit.

        This should be called exactly once per workflow execution, from
        the persist_audit_record node, after all other nodes have run (or
        failed) -- including failure paths, so every request_id has exactly
        one audit row regardless of outcome.

        Raises:
            Exception: propagates any underlying driver/connection error.
            Per the spec, persist_audit_record (the calling node) is
            responsible for deciding whether an audit-write failure should
            itself be swallowed (to avoid masking the original workflow
            outcome) or surfaced -- this repo does not make that call.
        """
        params = {
            "request_id": record.request_id,
            "user_name": record.user_name,
            "use_case_name": record.use_case_name,
            "resolved_entity_id": record.resolved_entity_id,
            "resolved_entity_type": record.resolved_entity_type,
            "clarification_required": int(record.clarification_required),
            "policy_decision_status": (
                record.policy_decision_status.value if record.policy_decision_status else None
            ),
            "policy_reason": record.policy_reason,
            "tool_sequence_json": json.dumps(
                [entry.model_dump(mode="json") for entry in record.tool_sequence]
            ),
            "top_root_causes_json": json.dumps(
                [entry.model_dump(mode="json") for entry in record.top_root_causes]
            ),
            "action_recommended": record.action_recommended.value if record.action_recommended else None,
            "approval_status": record.approval_status.value if record.approval_status else None,
            "action_outcome": record.action_outcome,
            "started_ts": record.started_ts,
            "completed_ts": record.completed_ts,
            "elapsed_ms": record.elapsed_ms,
            "errors_json": json.dumps(record.errors),
            "fallback_paths_json": json.dumps(record.fallback_paths_taken),
            "extra_json": json.dumps(record.extra),
        }
        # TODO: execute _INSERT_SQL with params bound via the chosen driver
        # convention (teradatasql cursor.execute with qmark or named params
        # depending on paramstyle configuration).
        logger.debug("insert_audit_record called for request_id=%s (STUB)", record.request_id)

    def get_audit_record(self, request_id: str) -> Optional[AuditRecord]:
        """Fetch a single persisted AuditRecord by request_id, for replay
        or support investigation purposes.

        Returns None if no row exists for request_id.

        Raises:
            ValueError: if request_id is empty.
        """
        if not request_id or not request_id.strip():
            raise ValueError("request_id must not be empty")
        # TODO: execute _SELECT_BY_REQUEST_ID_SQL with {"request_id":
        # request_id.strip()} bound, deserialize JSON columns back into
        # ToolInvocationAuditEntry / RootCauseAuditEntry lists, and
        # reconstruct an AuditRecord. Returning None as a placeholder.
        logger.debug("get_audit_record called for request_id=%s (STUB)", request_id)
        return None
