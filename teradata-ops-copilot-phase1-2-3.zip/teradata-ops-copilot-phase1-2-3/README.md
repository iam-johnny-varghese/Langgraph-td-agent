# Teradata Ops Copilot

A production-oriented scaffold for a context-driven agent that uses **Teradata
as the governed semantic backbone** and **Teradata Enterprise MCP** as the
secure tool interface, for diagnosing and remediating operational incidents
(missed SLAs, failed pipelines, workload saturation, permission regressions,
stale data).

> **Status:** Architectural scaffold. Method signatures, models, SQL DDL,
> and workflow wiring are in place; several integration points are
> deliberately stubbed (see "Placeholders vs Production-Ready" below, added
> in later phases). This is meant to be cloned and completed incrementally,
> not run as-is against a live Teradata system.

---

## Architecture Overview

The system is organized into ten layers, each with a single responsibility.
Requests flow top-to-bottom; only the workflow orchestration layer is
allowed to call across multiple layers in sequence.

```
                         ┌─────────────────────┐
                         │   API / App Layer    │  FastAPI routes, request/response models
                         └──────────┬───────────┘
                                    │
                         ┌──────────▼───────────┐
                         │ Workflow Orchestration│  LangGraph-style state machine
                         │       Layer            │  (10 nodes, see below)
                         └──────────┬───────────┘
                  ┌─────────────────┼─────────────────┐
                  │                 │                 │
        ┌─────────▼───────┐ ┌───────▼────────┐ ┌──────▼───────┐
        │  Context Engine  │ │ Policy/Approval│ │  MCP Tool     │
        │      Layer        │ │     Layer       │ │  Adapter Layer│
        └─────────┬───────┘ └───────┬────────┘ └──────┬───────┘
                  │                 │                 │
        ┌─────────▼─────────────────▼───────┐ ┌───────▼───────┐
        │   Teradata Repository Layer        │ │  Teradata      │
        │ (context_repo, ops_repo,            │ │  Enterprise    │
        │  security_repo, audit_repo)         │ │  MCP Server    │
        └─────────────────┬───────────────────┘ └───────────────┘
                           │
                  ┌────────▼─────────┐
                  │  Teradata Vantage  │  context.* schema (curated views)
                  │  (curated context) │
                  └───────────────────┘

        Cross-cutting: Configuration Layer, Audit/Observability Layer,
        Prompt/Template Layer, Test Suite
```

### Layer responsibilities

| Layer | Location | Responsibility |
|---|---|---|
| API / App | `app/main.py`, `app/api/` | HTTP entrypoint; translates HTTP requests into a `UserRequest` and invokes the workflow graph. |
| Workflow Orchestration | `app/workflows/` | Owns the 10-node state machine and `WorkflowState`. The only layer permitted to call Context Engine, Policy, and MCP layers in sequence. |
| Context Engine | `app/services/context_engine.py`, `entity_resolver.py`, `root_cause_service.py` | Builds and enriches the `ContextPack`; the only consumer of repositories and MCP adapters for *retrieval*. |
| Policy & Approval | `app/services/policy_service.py`, `approval_service.py` | Decides tool eligibility and execution mode; gates any action behind human approval where required. |
| MCP Tool Adapter | `app/mcp/` | Wraps Teradata Enterprise MCP tool calls with exact-name/param validation, least-privilege enforcement, and logging. |
| Teradata Repository | `app/repositories/` | All raw SQL against `context.*` schema objects. Nothing outside this layer issues SQL directly. |
| Audit & Observability | `app/repositories/audit_repo.py`, `app/models/audit.py` | Persists `AuditRecord` rows; provides hooks for future replay/evaluation. |
| Configuration | `app/core/config.py` | Centralized settings (env-driven), kept separate from business logic. |
| Prompt/Template | `app/prompts/` | All LLM-facing prompt text, versioned as plain text files, not inlined in Python. |
| Test Suite | `app/tests/` | Unit tests for entity resolution, policy decisions, root-cause ranking, approval gating, and audit persistence. |

### Why Teradata is the semantic backbone

Rather than letting the LLM/agent runtime query raw production tables, all
grounding data is exposed through a **curated `context` schema**
(`context.data_product_catalog`, `context.pipeline_health`,
`context.data_dependency`, `context.workload_signal`, `context.access_policy`,
`context.agent_tool_registry`, `context.context_audit`, plus the
`context.vw_latest_pipeline_status` view). This gives three guarantees:

1. **Governed surface area** — the agent only ever sees what curators have
   explicitly exposed in `context.*`, never raw PCI/Secure Zone tables.
2. **Stable contract** — repository code and SQL queries target view/table
   shapes that are versioned independently of underlying production schema
   churn.
3. **Auditable grounding** — every fact in a `ContextPack` is traceable back
   to a named `context.*` object, which is what `generate_user_explanation`
   relies on to avoid fabricating evidence.

### How MCP tools are scoped

Teradata Enterprise MCP tools (e.g. `sec_userDbPermissions`,
`sec_userRoles`, DBA health tools, vector/runbook lookup tools) are never
called directly by workflow nodes. They are accessed through
category-specific adapters (`BaseToolsAdapter`, `DBAToolsAdapter`,
`SecurityToolsAdapter`, `VectorToolsAdapter`), each of which is constrained
by:

- `context.agent_tool_registry` — which tools exist, which use cases they're
  allowed for, whether they require approval.
- `PolicyDecision.allowed_tools` — the per-request least-privilege allow-list
  computed by `policy_service` before `enrich_with_mcp_tools` runs.

This two-layer gate (static registry + per-request policy decision) is
detailed further in the Phase 4 README section.

### How the workflow operates (preview)

The orchestration layer runs a fixed 10-node sequence per request:
`intake_and_classify → resolve_entity → check_policy_and_tool_eligibility →
retrieve_primary_context → enrich_with_mcp_tools →
score_root_cause_candidates → generate_user_explanation →
request_approval_if_needed → execute_approved_action_if_any →
persist_audit_record`. Full node-by-node behavior, state mutations, and
error handling are documented in the Phase 3 README section once
`app/workflows/` is generated.

### Approval and audit (preview)

Actions are split into **approval-required** (`rerun_pipeline`,
`grant_or_revoke_access`, `run_admin_macro` / `execute_macro`,
`execute_fix_script`) and **safe-without-approval**
(`notify_owner`, `create_incident_summary`,
`gather_additional_diagnostics`). Every execution — regardless of whether
an action was proposed — is persisted as an `AuditRecord` in
`context.context_audit`. Full detail lands in the Phase 4 README section.

---

## Project Structure

```
app/
  main.py                          # FastAPI app entrypoint
  api/
    routes.py                     # HTTP routes -> workflow invocation
  core/
    config.py                     # Settings (env-driven)
    logging.py                    # Structured logging setup
    security.py                   # AuthN/authz helpers for the API layer
  models/
    domain.py                     # UserRequest, ResolvedEntity, ContextPack, RootCauseCandidate, ActionPlan, ApprovalRequest, ...
    workflow.py                   # WorkflowState (shared state across graph nodes)
    audit.py                      # AuditRecord and audit-facing projections
    policy.py                     # AgentToolRegistryEntry, AccessPolicyRule (row-shape models)
    mcp.py                        # MCPToolDefinition, MCPToolRequest, MCPToolResult
  workflows/
    ops_copilot_graph.py          # Graph wiring / state machine definition
    nodes/
      intake.py
      resolve_entity.py
      policy_check.py
      retrieve_context.py
      enrich_with_mcp.py
      score_root_cause.py
      generate_response.py
      request_approval.py
      execute_action.py
      audit_result.py
  services/
    context_engine.py
    entity_resolver.py
    policy_service.py
    approval_service.py
    root_cause_service.py
    prompt_service.py
  repositories/
    teradata_context_repo.py
    teradata_ops_repo.py
    teradata_security_repo.py
    audit_repo.py
  mcp/
    client.py
    tool_registry.py
    adapters/
      base_tools.py
      dba_tools.py
      security_tools.py
      vector_tools.py
  prompts/
    system_prompt.txt
    ops_diagnosis_prompt.txt
    security_audit_prompt.txt
    root_cause_prompt.txt
  sql/
    context/
      create_context_tables.sql
      create_context_views.sql
    queries/
      get_data_product.sql
      get_alias_matches.sql
      get_latest_pipeline_status.sql
      get_dependency_chain.sql
      get_workload_signals.sql
      get_access_policy.sql
  tests/
    test_entity_resolution.py
    test_policy_check.py
    test_workflow_diagnosis.py
    test_approval_logic.py
    test_audit_logging.py
README.md
```

---

## Domain Models (Phase 1)

All contracts live in `app/models/`. Summary:

| Model | File | Purpose |
|---|---|---|
| `UserRequest` | `domain.py` | Raw inbound request, captured at intake before classification. |
| `ResolvedEntity` | `domain.py` | Output of entity resolution; carries `clarification_required` for ambiguous matches. |
| `PolicyDecision` | `domain.py` | Execution mode (`blocked` / `read_only` / `approval_required` / `approved_for_safe_action`) plus the per-request tool allow-list. |
| `ContextPack` | `domain.py` | Normalized, curated context assembled for the LLM; the single source of grounding truth for downstream nodes. |
| `ToolInvocation` | `domain.py` | Audit-facing record of a single MCP (or internal) tool call. |
| `RootCauseCandidate` | `domain.py` | A ranked root-cause hypothesis with confidence, evidence, and missing-evidence flags. |
| `ApprovalRequest` | `domain.py` | Human-in-the-loop approval record for a proposed `ActionPlan`. |
| `ActionPlan` | `domain.py` | A proposed (not-yet-executed) remediation action. |
| `AuditRecord` | `audit.py` | Durable, query-friendly persisted record of one workflow execution. |
| `WorkflowState` | `workflow.py` | Shared state object threaded through every workflow node. |

Two supporting models are also included since the policy and MCP layers
need typed row/request shapes distinct from the decision/record models
above:

- `AgentToolRegistryEntry`, `AccessPolicyRule` (`policy.py`) — typed
  projections of `context.agent_tool_registry` and `context.access_policy`
  rows.
- `MCPToolDefinition`, `MCPToolRequest`, `MCPToolResult` (`mcp.py`) — the
  request/response contract used internally by `mcp/client.py` and the
  category adapters, including parameter validation (exact names, no
  null/empty values, whitespace trimming) at construction time.

**Assumptions made in Phase 1:**
- `WorkflowState` aggregates all domain objects as `Optional` fields filled
  in progressively, rather than each node having a bespoke
  input/output type, consistent with typical LangGraph state-graph design.
- `ToolInvocation` (domain.py, rich) and `ToolInvocationAuditEntry`
  (audit.py, lightweight) are kept distinct so audit rows don't balloon
  with full raw tool payloads.
- Confidence scores are bounded `[0.0, 1.0]` via Pydantic field constraints
  to fail fast rather than silently propagate bad scores into ranking logic.

**Placeholders / TODOs introduced in Phase 1:**
- `WorkflowState.scratch: dict[str, Any]` is an explicit escape hatch for
  node-specific data that hasn't earned a first-class field yet; the
  docstring flags that frequently-used keys should graduate to named fields.
- Replay/evaluation support is noted as a TODO in `audit.py` — full state
  snapshotting alongside `AuditRecord` is left for a later phase.

---

## Teradata Schema & Repository Layer (Phase 2)

### Schema objects

All DDL lives in `app/sql/context/`. Run order: `create_context_tables.sql`
then `create_context_views.sql`.

| Object | Type | Purpose |
|---|---|---|
| `context.data_product_catalog` | table | Canonical registry of business data products (PI: `data_product_id`). |
| `context.data_product_alias` | table | Business-language synonyms mapped to canonical products (PI: `data_product_id`, colocated with parent for join efficiency). |
| `context.pipeline_health` | table | Per-run ETL/pipeline status history (PI: `pipeline_id`). |
| `context.data_dependency` | table | Directed upstream→downstream edges (PI: `upstream_id`, favors downstream-impact traversal). |
| `context.workload_signal` | table | Curated TASM/TIWM workload pressure signals (PI: `workload_id`). |
| `context.access_policy` | table | Required-role/sensitivity rules per object pattern — **not** the tool registry. |
| `context.agent_tool_registry` | table | Static MCP tool eligibility registry — category, approval flag, use-case allowlist. |
| `context.context_audit` | table | Append-only audit log, one row per `request_id`; JSON text columns hold tool sequence/root causes/errors. |
| `context.vw_latest_pipeline_status` | view | One row per pipeline = most recent run (`QUALIFY ROW_NUMBER()...=1`). |
| `context.vw_data_product_with_owner` | view | Active-only catalog projection in `DataProductSummary`-aligned shape. |
| `context.vw_active_dependency_edges` | view | Active-only dependency edges; base relation for chain traversal. |
| `context.vw_breached_workload_signals` | view | Threshold-breached signals, last 24h — default root-cause evidence source. |
| `context.vw_enabled_tool_registry` | view | Enabled-only tool registry projection for policy_service. |

**Teradata-specific conventions followed:** `PRIMARY INDEX` (never `PRIMARY
KEY`), `QUALIFY` for the latest-row-per-partition pattern, `TOP n` instead
of `LIMIT` in `get_workload_signals.sql`, `WITH RECURSIVE` for dependency
chain traversal with an explicit depth counter (not relying on cycle
detection alone, since dependency data could contain a misconfigured
cycle).

### Starter queries (`app/sql/queries/`)

Six parameterized SQL templates, each loaded and bound by its corresponding
repository method: `get_data_product.sql`, `get_alias_matches.sql`,
`get_latest_pipeline_status.sql`, `get_dependency_chain.sql`,
`get_workload_signals.sql`, `get_access_policy.sql`. Bind-parameter style
(`:name`) is shown for clarity; actual binding should match whichever
driver paramstyle is finalized (see TODOs in each repository file).

### Repository layer (`app/repositories/`)

| File | Wraps | Key methods |
|---|---|---|
| `teradata_context_repo.py` | catalog, alias, dependency | `get_data_product`, `get_alias_matches`, `get_dependency_chain` |
| `teradata_ops_repo.py` | pipeline health, workload signals | `get_latest_pipeline_status`, `get_workload_signals` |
| `teradata_security_repo.py` | access policy (should-be state) | `get_access_policy` |
| `audit_repo.py` | context_audit (write + read-back) | `insert_audit_record`, `get_audit_record` |

A shared `TeradataConnection` `Protocol` (defined in
`teradata_context_repo.py`, reused by the other three) gives a structural
type for the injected DB-API connection without requiring a Teradata
driver to be installed just to import or test this layer.

**Important distinction surfaced in this phase:** `teradata_security_repo.py`
answers "what access policy *should* apply to object X" from
`context.access_policy`. It does **not** check actual current grants —
that's `mcp/adapters/security_tools.py` (Phase 4), which calls
`sec_userDbPermissions` / `sec_userRoles` through MCP. The two are combined
by `policy_service`/`root_cause_service` to detect regressions (e.g. "does
user X still have elevated access...").

**Assumptions made in Phase 2:**
- All repository methods validate required identifiers (raise `ValueError`
  on empty/whitespace strings or invalid bounds) rather than silently
  querying with bad input — consistent with the spec's "do not guess
  missing identifiers" rule, enforced here at the data-access boundary too.
- `get_latest_pipeline_status` requires exactly one of `pipeline_id` /
  `data_product_id`; the underlying SQL handles either via an OR predicate,
  flagged as a candidate to split into two query files if it becomes a
  hot path (see TODO in the SQL file).
- `context.context_audit` is intentionally denormalized (JSON text columns
  for tool sequence / root causes / errors) to keep `audit_repo.py` writes
  a single-row INSERT; normalization into child tables is deferred until
  reporting needs justify the join complexity.
- Dependency chain traversal direction is upstream→downstream (impact
  analysis) by default; the reverse direction (root-cause walk) is
  documented as a TODO variant rather than built speculatively.

**Placeholders / TODOs introduced in Phase 2:**
- Every repository method body is a stub (`# TODO: execute ... `) — SQL
  loading, parameter binding, and row→model mapping are not yet wired to a
  real driver. Method signatures, validation, and return types are final;
  only the execution body needs completing once the driver/paramstyle
  decision is made.
- `audit_repo.py`'s INSERT is inlined as a Python string constant rather
  than a `.sql` file, flagged as a possible inconsistency to resolve if a
  strict "all SQL lives in `sql/`" convention is preferred.
- SQL file caching (`functools.lru_cache` on `_load_sql`) is noted but not
  implemented, since the query set may still change during review.

Verified in this phase: all four repository modules import cleanly and
their validation guards (empty identifiers, missing required params,
invalid depth bounds) behave correctly under a fake connection stub — see
inline smoke test run during generation.


---

## Workflow Orchestration Layer (Phase 3)

### Graph wiring (`app/workflows/ops_copilot_graph.py`)

`run_workflow(request, deps)` sequences the 10 nodes over a single shared
`WorkflowState` instance via in-place mutation. Orchestration is a plain
Python function rather than an actual `langgraph.graph.StateGraph` object,
so the scaffold runs without a hard dependency on the `langgraph` package
— but every node is written as a `state -> state` callable, so migrating
to a real `StateGraph` later is close to a drop-in (see the TODO block at
the top of the file for the specific migration steps: conditional edges
for clarification short-circuiting, DI wrapper for repo/MCP dependencies,
and optional checkpoint/retry support).

`WorkflowDependencies` is a single dataclass bundling every repository,
the tool registry snapshot, and the MCP client, so `run_workflow`'s
signature stays stable as nodes acquire new dependencies. It is
constructed by the API layer / a composition root in `app/main.py` — the
graph module itself never constructs a connection or repository.

`persist_audit_record` always runs as the true last step — via
`_finalize_with_audit` — whether the workflow completed normally or
failed at any earlier node, so every `request_id` gets exactly one audit
row.

### Node-by-node summary

| # | Node file | Reads (key fields) | Writes | Notes |
|---|---|---|---|---|
| 1 | `nodes/intake.py` | `request.raw_text` | `use_case_name`, `entity_hint` | Keyword-based classification + conservative quoted/trigger-phrase entity extraction. Never guesses a hint — returns `None` rather than a weak guess. |
| 2 | `nodes/resolve_entity.py` | `entity_hint` | `resolved_entity`, `requires_clarification`, `clarification_message` | Auto-resolves only above `_MIN_AUTO_RESOLVE_CONFIDENCE` (0.85) **and** outside `_AMBIGUITY_MARGIN` (0.05) of the runner-up. Repo errors fail into clarification, not a crash. |
| 3 | `nodes/policy_check.py` | `use_case_name`, `resolved_entity` | `policy_decision` | Exact use-case-allowlist matching against the tool registry. **Fails closed** (`BLOCKED`) on any registry-read error. |
| 4 | `nodes/retrieve_context.py` | `resolved_entity` | `context_pack` | Each of 3 data sources (data product, pipeline health, dependencies) is independently try/excepted — one failing doesn't blank the others; gaps recorded in `missing_data_flags`. |
| 5 | `nodes/enrich_with_mcp.py` | `policy_decision.allowed_tools` | `context_pack.mcp_enrichment`, `tool_invocations` | Zero calls if `BLOCKED`. Plans calls conservatively (only when needed params are actually known). Re-validates every planned call against `allowed_tools` before invoking — verified in smoke test rejecting an out-of-policy vector tool call. |
| 6 | `nodes/score_root_cause.py` | `context_pack` | `root_cause_candidates` | 4 deterministic scoring rules (failed ETL, upstream delay, workload saturation, dashboard refresh). No LLM call in this node — verified in smoke test producing a 90%-confidence `failed_etl_job` candidate grounded in `failure_reason`. |
| 7 | `nodes/generate_response.py` | `context_pack`, `root_cause_candidates` | `user_explanation` | Deterministic template builds the explanation directly from typed fields — no free-text generation step. Optional LLM polish (`_llm_summarize`) is a no-op stub today; template is the only active path. |
| 8 | `nodes/request_approval.py` | `root_cause_candidates`, `policy_decision` | `proposed_action`, `approval_request` | Centralized approval matrix (`_ACTIONS_REQUIRING_APPROVAL`). Below `_MIN_ACTION_CONFIDENCE` (0.6), proposes `gather_additional_diagnostics` instead of guessing a fix. Never executes anything itself. |
| 9 | `nodes/execute_action.py` | `proposed_action`, `approval_request` | `action_executed`, `action_outcome` | Executes only on `APPROVED`/`NOT_REQUIRED` status. Three safe-action stubs wired (`notify_owner`, `create_incident_summary`, `gather_additional_diagnostics`); the three approval-required action types have **no executor at all** in this scaffold by design — verified in smoke test correctly skipping a pending `rerun_pipeline` approval. |
| 10 | `nodes/audit_result.py` | (most of `WorkflowState`) | `completed_ts`, persisted `AuditRecord` | Always runs, even on failure paths. Audit-write failure is logged but does not crash the graph; recorded as `fallback_paths_taken: ["audit_write_failed"]` instead. |

### Verified behavior (end-to-end smoke tests)

Two full graph runs were executed against stubbed repositories during
generation:

1. **Clarification path** — an unresolvable entity hint ("finance
   dashboard" with no alias data available) correctly produced
   `requires_clarification=True`, a user-facing clarification message,
   `READ_ONLY` policy status, and `complete` terminal stage with zero
   proposed action.
2. **Happy path with simulated data** — a high-confidence resolved entity
   plus a failed pipeline run correctly produced: `APPROVED_FOR_SAFE_ACTION`
   policy status; an out-of-policy MCP tool call correctly **rejected**
   (defense-in-depth allow-list check); a 90%-confidence `failed_etl_job`
   root cause grounded in the actual `failure_reason` string; a grounded
   explanation; a `rerun_pipeline` action plan correctly flagged
   `requires_approval=True`; a `PENDING` `ApprovalRequest`; and execution
   correctly **skipped** (`action_outcome: skipped_not_approved`) since
   approval had not yet been granted.

**Key assumptions made in Phase 3:**
- In-place `WorkflowState` mutation (not copy-on-write) is used throughout,
  matching the "explicit over clever" preference; each node returns the
  same instance it received.
- `requires_clarification` short-circuits node *logic* (e.g.
  `enrich_with_mcp_tools` calls zero tools, `request_approval_if_needed`
  proposes nothing) but does not skip *nodes* — every node still runs and
  defensively checks the flag, so the linear sequence stays simple and
  every node's contract stays uniform.
- `score_root_cause_candidates` rules are pure functions over `ContextPack`
  with no shared mutable state, making them independently unit-testable
  (see Phase 5 test suite).
- The approval matrix is centralized in one set
  (`_ACTIONS_REQUIRING_APPROVAL`) rather than trusted to each `ActionPlan`
  constructor call, so the policy is auditable in a single place.

**Marked placeholders/TODOs introduced in Phase 3:**
- `enrich_with_mcp.py`'s tool names (`dba_workloadHealth`,
  `vector_runbookSearch`) are placeholders pending confirmation of exact
  Teradata Enterprise MCP tool names (Phase 4).
- `enrich_with_mcp.py` deliberately does **not** plan any `sec_*` calls yet
  — target-user-identity extraction (distinct from a data-product entity)
  doesn't exist yet; calling a security tool with a guessed `user_name`
  would violate the "do not guess missing identifiers" rule, so it's left
  as an explicit TODO rather than implemented incorrectly.
- `score_root_cause.py` has no scoring rule yet for `security_regression`
  or `schema_drift` — both depend on MCP security-tool/schema-comparison
  evidence that isn't populated by `retrieve_primary_context` alone.
- `execute_action.py`'s three approval-required action types
  (`rerun_pipeline`, `grant_or_revoke_access`, `execute_macro`) have **no
  executor implementation** — by design, until narrow stored-procedure-
  backed adapters exist and have been reviewed.
- `request_approval.py` flags that `ActionType` (models/domain.py) doesn't
  yet distinguish `execute_fix_script` from `execute_macro` — both spec
  terms currently collapse onto `ActionType.EXECUTE_MACRO`.
- `execute_action.py`'s approval re-check is a TODO: it trusts
  `state.approval_request.status` as current rather than re-querying
  `approval_service` for the latest status, which matters once approval
  can be granted asynchronously by a human after the `WorkflowState` was
  first built.
- Replay/evaluation snapshotting (full `WorkflowState` persistence, not
  just the `AuditRecord` projection) remains a TODO in `audit_result.py`,
  consistent with the Phase 1/2 note in `audit.py`.
